# Documentation Utilisateurs Archetype

## 1. Objectif

Cette documentation explique comment utiliser le depot pour construire les artefacts et generer un projet Spring Boot.

Le depot produit trois artefacts :

- `springboot-enterprise-archetype-1.0.0`
- `archetype-config-maven-plugin-1.0.0`
- `archetype-config-generator-1.0.0`

## 2. Prerequis

- JDK 21
- Maven 3.9+
- Docker si vous voulez executer le build conteneur du projet genere

Sous PowerShell, utilisez `--%` dans les commandes Maven qui contiennent beaucoup de `-D...`.

## 3. Commande Unique De Build

Depuis la racine du depot :

```powershell
mvn -B clean install
```

Cette commande unique :

- construit l'archetype Maven
- construit le plugin Maven de generation
- construit le helper jar de generation
- installe les trois artefacts dans le repository Maven local

Artefacts produits :

- `springboot-enterprise-archetype\target\springboot-enterprise-archetype-1.0.0.jar`
- `archetype-config-maven-plugin\target\archetype-config-maven-plugin-1.0.0.jar`
- `maven-config-generator\target\archetype-config-generator-1.0.0.jar`

## 4. Mode 1: Appel Maven Standard

Ce mode utilise directement `mvn archetype:generate`.

Limite :

- pas de `-DconfigFile`
- `gitRepositoryUrl` et `gitBranch` doivent etre fournis ensemble si vous voulez publier le projet genere sur Git

Exemple :

```powershell
mvn --% -B archetype:generate -DarchetypeCatalog=local -DarchetypeGroupId=com.company.archetype -DarchetypeArtifactId=springboot-enterprise-archetype -DarchetypeVersion=1.0.0 -DgroupId=com.company.demo -DartifactId=enterprise-app-h2 -Dversion=1.0.0-SNAPSHOT -Dpackage=com.company.demo -DwebStack=webmvc -DdatabaseType=h2 -DdatabaseName=enterprise_h2 -DdatabaseSchema=app_schema -DinteractiveMode=false
```

Exemple avec publication Git :

```powershell
mvn --% -B archetype:generate -DarchetypeCatalog=local -DarchetypeGroupId=com.company.archetype -DarchetypeArtifactId=springboot-enterprise-archetype -DarchetypeVersion=1.0.0 -DgroupId=com.company.demo -DartifactId=enterprise-app-h2 -Dversion=1.0.0-SNAPSHOT -Dpackage=com.company.demo -DwebStack=webmvc -DdatabaseType=h2 -DdatabaseName=enterprise_h2 -DdatabaseSchema=app_schema -DinteractiveMode=false -DgitRepositoryUrl=https://github.com/hbhassen/TestDockerPython.git -DgitBranch=test1
```

## 5. Mode 2: Plugin Maven Avec `-DconfigFile`

Ce mode est le plus proche d'une commande Maven native enrichie.

Exemple avec un fichier `.properties` :

```powershell
mvn --% -B com.company.archetype:archetype-config-maven-plugin:1.0.0:generate -DconfigFile=.\examples\generation-h2.properties -DoutputDirectory=.\generated
```

Exemple avec un fichier `.yml` :

```powershell
mvn --% -B com.company.archetype:archetype-config-maven-plugin:1.0.0:generate -DconfigFile=.\examples\generation-postgresql.yml -DoutputDirectory=.\generated
```

Exemple avec toutes les proprietes inline :

```powershell
mvn --% -B com.company.archetype:archetype-config-maven-plugin:1.0.0:generate -DgroupId=com.company.demo -DartifactId=enterprise-app-postgresql -Dversion=1.0.0-SNAPSHOT -Dpackage=com.company.demo -DwebStack=webflux -DdatabaseType=postgresql -DdatabaseName=enterprise_db -DdatabaseSchema=app_schema -DdatabaseHost=localhost -DdatabasePort=5432 -DdatabaseUsername=postgres -DdatabasePassword=postgres -DoutputDirectory=.\generated
```

Exemple mixte fichier + override :

```powershell
mvn --% -B com.company.archetype:archetype-config-maven-plugin:1.0.0:generate -DconfigFile=.\examples\generation-postgresql.yml -DwebStack=webmvc -DoutputDirectory=.\generated
```

Dans ce mode :

- les valeurs du fichier servent de base
- les valeurs inline `-D...` ecrasent les valeurs du fichier

## 6. Mode 3: Helper `java -jar`

Ce mode repose sur le jar produit par le build unique.

Exemple avec un fichier `.properties` :

```powershell
java -jar .\maven-config-generator\target\archetype-config-generator-1.0.0.jar --configFile=.\examples\generation-h2.properties --outputDirectory=.\generated
```

Exemple avec un fichier `.yml` :

```powershell
java -jar .\maven-config-generator\target\archetype-config-generator-1.0.0.jar --configFile=.\examples\generation-postgresql.yml --outputDirectory=.\generated
```

Exemple avec toutes les proprietes inline :

```powershell
java -jar .\maven-config-generator\target\archetype-config-generator-1.0.0.jar --groupId=com.company.demo --artifactId=enterprise-app-postgresql --version=1.0.0-SNAPSHOT --package=com.company.demo --webStack=webflux --databaseType=postgresql --databaseName=enterprise_db --databaseSchema=app_schema --databaseHost=localhost --databasePort=5432 --databaseUsername=postgres --databasePassword=postgres --outputDirectory=.\generated
```

## 7. Parametres De Generation

### Parametres obligatoires

- `groupId`
- `artifactId`
- `version`
- `package`
- `databaseName`
- `databaseSchema`

### Parametres optionnels

- `webStack`
- `databaseType`
- `databaseHost`
- `databasePort`
- `databaseUsername`
- `databasePassword`
- `gitRepositoryUrl`
- `gitBranch`

### Valeurs par defaut

- `webStack=webmvc`
- `databaseType=h2`
- `databaseHost=localhost`
- `databasePort=5432`
- `databaseUsername=postgres`
- `databasePassword=postgres`

### Valeurs supportees

Pour `webStack` :

- `webmvc`
- `webflux`

Pour `databaseType` :

- `h2`
- `postgresql`
- `postgres`

`postgres` est normalise en `postgresql`.

## 8. Fichiers De Configuration Supportes

### `.properties`

Exemple :

```properties
groupId=com.company.demo
artifactId=enterprise-app-h2
version=1.0.0-SNAPSHOT
package=com.company.demo
webStack=webmvc
databaseType=h2
databaseName=enterprise_h2
databaseSchema=app_schema
```

### `.yml`

Exemple :

```yaml
groupId: com.company.demo
artifactId: enterprise-app-postgresql
version: 1.0.0-SNAPSHOT
package: com.company.demo
webStack: webflux
databaseType: postgresql
databaseName: enterprise_db
databaseSchema: app_schema
databaseHost: localhost
databasePort: 5432
databaseUsername: postgres
databasePassword: postgres
```

Limite :

- YAML plat uniquement

## 9. Choix De La Pile Web

### `webmvc`

Le projet genere utilise :

- `spring-boot-starter-webmvc`
- `SecurityFilterChain`
- `MockMvc` pour les tests

### `webflux`

Le projet genere utilise :

- `spring-boot-starter-webflux`
- `SecurityWebFilterChain`
- `WebTestClient` pour les tests

Important :

- la persistence reste en JPA
- le controller WebFlux genere delegue les appels bloquants sur `Schedulers.boundedElastic()`

## 10. Choix De La Base De Donnees

### `h2`

Le projet genere est autonome pour un demarrage local rapide.

### `postgresql`

Le projet genere attend une base PostgreSQL disponible au runtime.

Important :

- les tests du projet genere restent sur H2

## 11. Lancement Du Projet Genere

Depuis le projet genere :

```powershell
mvn -B spring-boot:run
```

Swagger UI :

```text
http://localhost:8080/swagger-ui.html
```

Health :

```text
http://localhost:8080/actuator/health
```

## 12. Tests Du Projet Genere

```powershell
mvn -B test
```

## 13. Docker

```powershell
docker build -t enterprise-app:latest .
docker run --rm -p 8080:8080 enterprise-app:latest
```

## 14. Quel Mode Choisir

Choisissez `mvn archetype:generate` si :

- vous n'avez pas besoin de fichier de configuration

Choisissez le plugin Maven si :

- vous voulez une commande Maven native
- vous voulez `-DconfigFile`

Choisissez le helper jar si :

- vous voulez un outil autonome en `java -jar`

## 15. Conclusion

Le point cle du depot est maintenant simple :

1. un seul `mvn -B clean install` construit tout
2. vous choisissez ensuite le mode d'appel :
   - Maven standard
   - plugin Maven
   - helper jar

Si votre besoin principal est de charger un fichier de configuration via une commande Maven, le mode recommande est :

```powershell
mvn --% -B com.company.archetype:archetype-config-maven-plugin:1.0.0:generate -DconfigFile=.\examples\generation-h2.properties -DoutputDirectory=.\generated
```
