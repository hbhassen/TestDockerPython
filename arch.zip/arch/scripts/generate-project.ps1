[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$ConfigFile,

    [string]$ArchetypeGroupId = "com.company.archetype",
    [string]$ArchetypeArtifactId = "springboot-enterprise-archetype",
    [string]$ArchetypeVersion = "1.0.0",
    [string]$ArchetypeCatalog = "local",
    [string]$OutputDirectory = "."
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Remove-Quotes {
    param([string]$Value)

    if ($null -eq $Value) {
        return $Value
    }

    $trimmed = $Value.Trim()
    if ($trimmed.Length -ge 2) {
        if (($trimmed.StartsWith('"') -and $trimmed.EndsWith('"')) -or
            ($trimmed.StartsWith("'") -and $trimmed.EndsWith("'"))) {
            return $trimmed.Substring(1, $trimmed.Length - 2)
        }
    }

    return $trimmed
}

function Read-PropertiesFile {
    param([string]$Path)

    $values = [ordered]@{}
    foreach ($line in Get-Content -Path $Path) {
        $trimmed = $line.Trim()
        if (-not $trimmed -or $trimmed.StartsWith("#") -or $trimmed.StartsWith("!")) {
            continue
        }

        $parts = $trimmed -split "=", 2
        if ($parts.Count -ne 2) {
            throw "Ligne properties invalide : $line"
        }

        $key = $parts[0].Trim()
        $value = Remove-Quotes $parts[1]
        $values[$key] = $value
    }

    return $values
}

function Read-YamlFile {
    param([string]$Path)

    $values = [ordered]@{}
    foreach ($line in Get-Content -Path $Path) {
        $trimmed = $line.Trim()
        if (-not $trimmed -or $trimmed.StartsWith("#")) {
            continue
        }

        $parts = $trimmed -split ":", 2
        if ($parts.Count -ne 2) {
            throw "Seules les paires cle/valeur YAML a plat sont supportees. Ligne invalide : $line"
        }

        $key = $parts[0].Trim()
        $value = Remove-Quotes $parts[1]
        $values[$key] = $value
    }

    return $values
}

function Read-Configuration {
    param([string]$Path)

    $resolvedPath = (Resolve-Path $Path).Path
    $extension = [System.IO.Path]::GetExtension($resolvedPath).ToLowerInvariant()

    switch ($extension) {
        ".properties" { return Read-PropertiesFile -Path $resolvedPath }
        ".yml" { return Read-YamlFile -Path $resolvedPath }
        ".yaml" { return Read-YamlFile -Path $resolvedPath }
        default { throw "Format de fichier de configuration non supporte : $extension" }
    }
}

function Require-Value {
    param(
        [hashtable]$Values,
        [string]$Key
    )

    if (-not $Values.Contains($Key) -or [string]::IsNullOrWhiteSpace([string]$Values[$Key])) {
        throw "Cle obligatoire manquante '$Key' dans le fichier de configuration."
    }
}

function Validate-GitConfiguration {
    param([hashtable]$Values)

    $hasRepository = $Values.Contains("gitRepositoryUrl") -and -not [string]::IsNullOrWhiteSpace([string]$Values["gitRepositoryUrl"])
    $hasBranch = $Values.Contains("gitBranch") -and -not [string]::IsNullOrWhiteSpace([string]$Values["gitBranch"])
    if ($hasRepository -ne $hasBranch) {
        throw "Les parametres Git 'gitRepositoryUrl' et 'gitBranch' doivent etre renseignes ensemble."
    }
}

$values = Read-Configuration -Path $ConfigFile
Validate-GitConfiguration -Values $values

foreach ($requiredKey in @(
    "groupId",
    "artifactId",
    "version",
    "package",
    "databaseName",
    "databaseSchema"
)) {
    Require-Value -Values $values -Key $requiredKey
}

$webStack = "webmvc"
if ($values.Contains("webStack") -and -not [string]::IsNullOrWhiteSpace([string]$values["webStack"])) {
    $webStack = ([string]$values["webStack"]).Trim().ToLowerInvariant()
}
if ($webStack -ne "webmvc" -and $webStack -ne "webflux") {
    throw "webStack doit valoir 'webmvc' ou 'webflux'."
}
$values["webStack"] = $webStack

if (-not $values.Contains("databaseHost")) { $values["databaseHost"] = "localhost" }
if (-not $values.Contains("databasePort")) { $values["databasePort"] = "5432" }
if (-not $values.Contains("databaseUsername")) { $values["databaseUsername"] = "postgres" }
if (-not $values.Contains("databasePassword")) { $values["databasePassword"] = "postgres" }
if (-not $values.Contains("databaseType")) { $values["databaseType"] = "h2" }

$databaseType = ([string]$values["databaseType"]).Trim().ToLowerInvariant()
if ($databaseType -eq "postgres") {
    $databaseType = "postgresql"
    $values["databaseType"] = $databaseType
}

if ($databaseType -ne "h2" -and $databaseType -ne "postgresql") {
    throw "databaseType doit valoir 'h2' ou 'postgresql'."
}

$mavenArguments = @(
    "-B",
    "archetype:generate",
    "-DarchetypeCatalog=$ArchetypeCatalog",
    "-DarchetypeGroupId=$ArchetypeGroupId",
    "-DarchetypeArtifactId=$ArchetypeArtifactId",
    "-DarchetypeVersion=$ArchetypeVersion",
    "-DinteractiveMode=false",
    "-DoutputDirectory=$OutputDirectory"
)

foreach ($entry in $values.GetEnumerator()) {
    $mavenArguments += "-D$($entry.Key)=$($entry.Value)"
}

Write-Host "Generation du projet a partir du fichier de configuration '$ConfigFile'..."
Write-Host "Pile web : $webStack"
Write-Host "Type de base de donnees : $databaseType"

& mvn @mavenArguments
if ($LASTEXITCODE -ne 0) {
    exit $LASTEXITCODE
}
