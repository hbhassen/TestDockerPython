# Guide D Utilisation

## 1. Objectif

Ce document recense les differentes facons supportees d appeler l archetype entreprise.

Le depot construit maintenant trois artefacts avec une seule commande Maven :

- `springboot-enterprise-archetype-1.0.0`
- `archetype-config-maven-plugin-1.0.0`
- `archetype-config-generator-1.0.0`

## 2. Une Commande Pour Tout Construire

Executez cette commande depuis la racine du depot :

```powershell
mvn -B clean install
```

Cette commande unique :

- construit le module archetype
- construit le module plugin Maven
- construit le module helper jar
- installe les trois artefacts dans le repository Maven local

Artefacts produits :

- `springboot-enterprise-archetype\target\springboot-enterprise-archetype-1.0.0.jar`
- `archetype-config-maven-plugin\target\archetype-config-maven-plugin-1.0.0.jar`
- `maven-config-generator\target\archetype-config-generator-1.0.0.jar`

## 3. Modes D Appel Supportes

| Mode | Style de commande | Support de `configFile` | A privilegier quand |
|---|---|---|---|
| Archetype Maven standard | `mvn archetype:generate` | Non | vous voulez le flux natif de Maven, avec publication Git optionnelle |
| Plugin Maven | `mvn com.company.archetype:archetype-config-maven-plugin:1.0.0:generate` | Oui | vous voulez une commande Maven pilotee par fichier, avec publication Git optionnelle |
| Helper jar | `java -jar archetype-config-generator-1.0.0.jar` | Oui | vous voulez un executable autonome, avec publication Git optionnelle |
| Scripts | PowerShell / Python | Oui | vous voulez un outillage local de confort, avec publication Git optionnelle |

## 4. Appel Maven Standard De L Archetype

Ce mode utilise l archetype Maven natif.

Il ne supporte pas `-DconfigFile`.

Exemple :

```powershell
mvn --% -B archetype:generate -DarchetypeCatalog=local -DarchetypeGroupId=com.company.archetype -DarchetypeArtifactId=springboot-enterprise-archetype -DarchetypeVersion=1.0.0 -DgroupId=com.company.demo -DartifactId=enterprise-app-h2 -Dversion=1.0.0-SNAPSHOT -Dpackage=com.company.demo -DwebStack=webmvc -DdatabaseType=h2 -DdatabaseName=enterprise_h2 -DdatabaseSchema=app_schema -DinteractiveMode=false
```

Utilisez ce mode si :

- vous n avez pas besoin d un fichier de configuration
- vous acceptez de passer toutes les proprietes inline

Publication Git optionnelle :

- renseignez `gitRepositoryUrl` et `gitBranch` ensemble
- si les deux sont presents, le projet genere est committe puis pousse sur la branche cible
- si un seul des deux est fourni, la commande echoue apres la generation

## 5. Appel Via Le Plugin Maven

Ce mode est le plus proche d une commande Maven native tout en supportant `-DconfigFile`.

Exemple avec un fichier `.properties` :

```powershell
mvn --% -B com.company.archetype:archetype-config-maven-plugin:1.0.0:generate -DconfigFile=.\examples\generation-h2.properties -DoutputDirectory=.\generated
```

Exemple avec un fichier `.yml` :

```powershell
mvn --% -B com.company.archetype:archetype-config-maven-plugin:1.0.0:generate -DconfigFile=.\examples\generation-postgresql.yml -DoutputDirectory=.\generated
```

Exemple avec des proprietes inline :

```powershell
mvn --% -B com.company.archetype:archetype-config-maven-plugin:1.0.0:generate -DgroupId=com.company.demo -DartifactId=enterprise-app-postgresql -Dversion=1.0.0-SNAPSHOT -Dpackage=com.company.demo -DwebStack=webflux -DdatabaseType=postgresql -DdatabaseName=enterprise_db -DdatabaseSchema=app_schema -DdatabaseHost=localhost -DdatabasePort=5432 -DdatabaseUsername=postgres -DdatabasePassword=postgres -DoutputDirectory=.\generated
```

Exemple avec fichier de configuration et overrides :

```powershell
mvn --% -B com.company.archetype:archetype-config-maven-plugin:1.0.0:generate -DconfigFile=.\examples\generation-postgresql.yml -DwebStack=webmvc -DoutputDirectory=.\generated
```

Regle de priorite :

- les valeurs du fichier sont chargees en premier
- les valeurs inline `-D...` ecrasent les valeurs du fichier

Publication Git optionnelle :

- renseignez `gitRepositoryUrl` et `gitBranch` ensemble
- si les deux sont presents, le projet genere est committe puis pousse sur la branche cible
- si un seul des deux est fourni, la commande echoue avant la generation

## 6. Appel Via Le Helper Jar

Ce mode utilise le jar executable construit par le depot.

Exemple avec un fichier `.properties` :

```powershell
java -jar .\maven-config-generator\target\archetype-config-generator-1.0.0.jar --configFile=.\examples\generation-h2.properties --outputDirectory=.\generated
```

Exemple avec un fichier `.yml` :

```powershell
java -jar .\maven-config-generator\target\archetype-config-generator-1.0.0.jar --configFile=.\examples\generation-postgresql.yml --outputDirectory=.\generated
```

Exemple avec des parametres inline :

```powershell
java -jar .\maven-config-generator\target\archetype-config-generator-1.0.0.jar --groupId=com.company.demo --artifactId=enterprise-app-postgresql --version=1.0.0-SNAPSHOT --package=com.company.demo --webStack=webflux --databaseType=postgresql --databaseName=enterprise_db --databaseSchema=app_schema --databaseHost=localhost --databasePort=5432 --databaseUsername=postgres --databasePassword=postgres --outputDirectory=.\generated
```

Exemple avec fichier de configuration et overrides :

```powershell
java -jar .\maven-config-generator\target\archetype-config-generator-1.0.0.jar --configFile=.\examples\generation-postgresql.yml --webStack=webmvc --outputDirectory=.\generated
```

Regle de priorite :

- les valeurs du fichier sont chargees en premier
- les valeurs `-D...` ecrasent les valeurs du fichier
- les arguments `--key=value` ecrasent l ensemble

Publication Git optionnelle :

- renseignez `gitRepositoryUrl` et `gitBranch` ensemble
- si les deux sont presents, le projet genere est committe puis pousse sur la branche cible
- si un seul des deux est fourni, la commande echoue avant la generation

## 7. Appels Par Scripts

Des helpers secondaires restent disponibles :

- `scripts/generate-project.ps1`
- `scripts/generate-project.py`

Ces scripts sont facultatifs et servent surtout de confort local.

## 8. Parametres De Generation

### Obligatoires

- `groupId`
- `artifactId`
- `version`
- `package`
- `databaseName`
- `databaseSchema`

### Optionnels

- `webStack`
- `databaseType`
- `databaseHost`
- `databasePort`
- `databaseUsername`
- `databasePassword`
- `gitRepositoryUrl`
- `gitBranch`

### Valeurs Par Defaut

- `webStack=webmvc`
- `databaseType=h2`
- `databaseHost=localhost`
- `databasePort=5432`
- `databaseUsername=postgres`
- `databasePassword=postgres`
- publication Git desactivee tant que `gitRepositoryUrl` et `gitBranch` ne sont pas fournis ensemble

## 9. Valeurs Supportees

### `webStack`

- `webmvc`
- `webflux`

### `databaseType`

- `h2`
- `postgresql`
- `postgres`

`postgres` est normalise en `postgresql`.

## 10. Formats De Fichier De Configuration Supportes

### `.properties`

```properties
groupId=com.company.demo
artifactId=enterprise-app-h2
version=1.0.0-SNAPSHOT
package=com.company.demo
webStack=webmvc
databaseType=h2
databaseName=enterprise_h2
databaseSchema=app_schema
# gitRepositoryUrl=https://git.example.com/team/generated-enterprise-app-h2.git
# gitBranch=generated/enterprise-app-h2
```

### `.yml`

```yaml
groupId: com.company.demo
artifactId: enterprise-app-postgresql
version: 1.0.0-SNAPSHOT
package: com.company.demo
webStack: webflux
databaseType: postgresql
databaseName: enterprise_db
databaseSchema: app_schema
databaseHost: localhost
databasePort: 5432
databaseUsername: postgres
databasePassword: postgres
# gitRepositoryUrl: https://git.example.com/team/generated-enterprise-app-postgresql.git
# gitBranch: generated/enterprise-app-postgresql
```

Limite YAML :

- paires cle/valeur a plat uniquement

## 11. Quel Mode Choisir

Choisissez `mvn archetype:generate` si :

- vous voulez le flux standard de l archetype Maven
- vous n avez pas besoin de `configFile`

Choisissez le plugin Maven si :

- vous voulez une commande Maven
- vous voulez `-DconfigFile`
- vous voulez l experience la plus proche de la generation native

Choisissez `java -jar` si :

- vous voulez un helper autonome
- vous ne voulez pas dependre d un goal Maven

Choisissez les scripts si :

- vous voulez une automatisation locale de confort

## 12. Commandes Recommandees A Conserver

### Construire Tout Le Depot

```powershell
mvn -B clean install
```

### Generer Avec Le Plugin Maven Et Un Fichier De Configuration

```powershell
mvn --% -B com.company.archetype:archetype-config-maven-plugin:1.0.0:generate -DconfigFile=.\examples\generation-h2.properties -DoutputDirectory=.\generated
```

### Generer Avec Le Helper Jar Et Un Fichier De Configuration

```powershell
java -jar .\maven-config-generator\target\archetype-config-generator-1.0.0.jar --configFile=.\examples\generation-h2.properties --outputDirectory=.\generated
```

## 13. Conclusion

Le depot suit maintenant un modele d utilisation simple :

1. lancer une seule commande Maven pour construire tout le depot
2. choisir ensuite le mode d appel le plus adapte

Si votre objectif est une commande Maven qui supporte `-DconfigFile`, l appel recommande est :

```powershell
mvn --% -B com.company.archetype:archetype-config-maven-plugin:1.0.0:generate -DconfigFile=.\examples\generation-h2.properties -DoutputDirectory=.\generated
```
