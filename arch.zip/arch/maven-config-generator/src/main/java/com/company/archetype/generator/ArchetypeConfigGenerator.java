package com.company.archetype.generator;

import org.apache.maven.shared.invoker.DefaultInvocationRequest;
import org.apache.maven.shared.invoker.DefaultInvoker;
import org.apache.maven.shared.invoker.InvocationRequest;
import org.apache.maven.shared.invoker.InvocationResult;
import org.apache.maven.shared.invoker.Invoker;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;

/**
 * Lance {@code archetype:generate} soit depuis {@code mvn exec:java}, soit
 * depuis un jar executable autonome.
 */
public final class ArchetypeConfigGenerator {

    private static final List<String> REQUIRED_KEYS = List.of(
            "groupId",
            "artifactId",
            "version",
            "package",
            "databaseName",
            "databaseSchema"
    );

    private static final List<String> SUPPORTED_KEYS = List.of(
            "groupId",
            "artifactId",
            "version",
            "package",
            "webStack",
            "databaseType",
            "databaseName",
            "databaseSchema",
            "databaseHost",
            "databasePort",
            "databaseUsername",
            "databasePassword",
            "gitRepositoryUrl",
            "gitBranch"
    );

    private static final List<String> SUPPORTED_HELPER_KEYS = List.of(
            "configFile",
            "outputDirectory",
            "archetypeCatalog",
            "archetypeGroupId",
            "archetypeArtifactId",
            "archetypeVersion",
            "mavenHome",
            "mavenExecutable"
    );

    private ArchetypeConfigGenerator() {
    }

    /**
     * Point d entree execute via {@code mvn exec:java} ou {@code java -jar}.
     *
     * @param args arguments de ligne de commande optionnels comme {@code --configFile=...}
     * @throws Exception si l entree est invalide ou si la generation echoue
     */
    public static void main(String[] args) throws Exception {
        Map<String, String> commandLineArguments = parseArguments(args);
        if (commandLineArguments.containsKey("help")) {
            printUsage();
            return;
        }

        Path workingDirectory = Paths.get(System.getProperty("user.dir")).toAbsolutePath().normalize();
        String configFileProperty = helperOption(commandLineArguments, "configFile", null);
        Path configFile = null;
        Map<String, String> values = new LinkedHashMap<>();

        if (hasText(configFileProperty)) {
            configFile = resolvePath(workingDirectory, configFileProperty);
            values.putAll(parseConfiguration(configFile));
        }

        applySystemProperties(values);
        applyCommandLineArguments(values, commandLineArguments);
        validateGitConfiguration(values);

        for (String requiredKey : REQUIRED_KEYS) {
            requireValue(values, requiredKey);
        }

        values.putIfAbsent("webStack", "webmvc");
        values.putIfAbsent("databaseHost", "localhost");
        values.putIfAbsent("databasePort", "5432");
        values.putIfAbsent("databaseUsername", "postgres");
        values.putIfAbsent("databasePassword", "postgres");

        String webStack = values.get("webStack").trim().toLowerCase();
        if (!"webmvc".equals(webStack) && !"webflux".equals(webStack)) {
            throw new IllegalArgumentException("webStack doit valoir 'webmvc' ou 'webflux'.");
        }
        values.put("webStack", webStack);

        values.putIfAbsent("databaseType", "h2");
        String databaseType = values.get("databaseType").trim().toLowerCase();
        if ("postgres".equals(databaseType)) {
            databaseType = "postgresql";
        }
        if (!"h2".equals(databaseType) && !"postgresql".equals(databaseType)) {
            throw new IllegalArgumentException("databaseType doit valoir 'h2' ou 'postgresql'.");
        }
        values.put("databaseType", databaseType);

        String archetypeCatalog = helperOption(commandLineArguments, "archetypeCatalog", "local");
        String archetypeGroupId = helperOption(commandLineArguments, "archetypeGroupId", "com.company.archetype");
        String archetypeArtifactId = helperOption(
                commandLineArguments,
                "archetypeArtifactId",
                "springboot-enterprise-archetype"
        );
        String archetypeVersion = helperOption(commandLineArguments, "archetypeVersion", "1.0.0");
        Path outputDirectory = resolvePath(
                workingDirectory,
                helperOption(commandLineArguments, "outputDirectory", workingDirectory.toString())
        );

        Properties requestProperties = new Properties();
        requestProperties.setProperty("archetypeCatalog", archetypeCatalog);
        requestProperties.setProperty("archetypeGroupId", archetypeGroupId);
        requestProperties.setProperty("archetypeArtifactId", archetypeArtifactId);
        requestProperties.setProperty("archetypeVersion", archetypeVersion);
        requestProperties.setProperty("interactiveMode", "false");
        requestProperties.setProperty("outputDirectory", outputDirectory.toString());

        for (Map.Entry<String, String> entry : values.entrySet()) {
            requestProperties.setProperty(entry.getKey(), entry.getValue());
        }

        InvocationRequest request = new DefaultInvocationRequest();
        request.setBatchMode(true);
        request.setBaseDirectory(workingDirectory.toFile());
        request.setProperties(requestProperties);
        request.addArg("archetype:generate");

        Invoker invoker = new DefaultInvoker();
        String mavenLocation = configureInvoker(invoker, commandLineArguments, workingDirectory);

        if (configFile != null) {
            System.out.println("Generation du projet a partir du fichier de configuration : " + configFile);
        } else {
            System.out.println("Generation du projet a partir de parametres inline.");
        }
        System.out.println("Pile web : " + webStack);
        System.out.println("Type de base de donnees : " + databaseType);
        System.out.println("Repertoire de sortie : " + outputDirectory);
        System.out.println("Runtime Maven : " + mavenLocation);

        InvocationResult result = invoker.execute(request);
        if (result.getExitCode() != 0) {
            Throwable executionException = result.getExecutionException();
            if (executionException != null) {
                throw new IllegalStateException("La generation de l archetype Maven a echoue.", executionException);
            }
            throw new IllegalStateException(
                    "La generation de l archetype Maven a echoue avec le code de sortie " + result.getExitCode() + "."
            );
        }

    }

    private static String configureInvoker(Invoker invoker, Map<String, String> arguments, Path workingDirectory) {
        String explicitMavenExecutable = helperOption(arguments, "mavenExecutable", null);
        if (hasText(explicitMavenExecutable)) {
            Path executable = resolveExistingFile(workingDirectory, explicitMavenExecutable, "mavenExecutable");
            invoker.setMavenExecutable(executable.toFile());
            return "executable " + executable;
        }

        String explicitMavenHome = helperOption(arguments, "mavenHome", null);
        if (hasText(explicitMavenHome)) {
            Path mavenHome = resolveExistingDirectory(workingDirectory, explicitMavenHome, "mavenHome");
            invoker.setMavenHome(mavenHome.toFile());
            return "home " + mavenHome;
        }

        String systemMavenHome = systemPropertyOrDefault("maven.home", null);
        if (hasText(systemMavenHome)) {
            Path mavenHome = resolveExistingDirectory(workingDirectory, systemMavenHome, "maven.home");
            invoker.setMavenHome(mavenHome.toFile());
            return "home " + mavenHome;
        }

        String envMavenHome = environmentOrDefault("MAVEN_HOME", environmentOrDefault("M2_HOME", null));
        if (hasText(envMavenHome)) {
            Path mavenHome = resolveExistingDirectory(workingDirectory, envMavenHome, "MAVEN_HOME");
            invoker.setMavenHome(mavenHome.toFile());
            return "home " + mavenHome;
        }

        Path mavenExecutable = findMavenExecutableOnPath();
        if (mavenExecutable != null) {
            invoker.setMavenExecutable(mavenExecutable.toFile());
            return "executable " + mavenExecutable;
        }

        throw new IllegalStateException(
                "Impossible de localiser Maven. Fournissez --mavenExecutable=..., --mavenHome=..., "
                        + "ou definissez MAVEN_HOME / M2_HOME."
        );
    }

    private static Map<String, String> parseArguments(String[] args) {
        Map<String, String> values = new LinkedHashMap<>();
        for (int index = 0; index < args.length; index++) {
            String rawArgument = Objects.requireNonNullElse(args[index], "").trim();
            if (rawArgument.isEmpty()) {
                continue;
            }

            if ("--help".equals(rawArgument) || "-h".equals(rawArgument)) {
                values.put("help", "true");
                continue;
            }

            if (rawArgument.startsWith("--")) {
                String argumentBody = rawArgument.substring(2);
                int separatorIndex = argumentBody.indexOf('=');
                if (separatorIndex >= 0) {
                    values.put(
                            argumentBody.substring(0, separatorIndex).trim(),
                            unquote(argumentBody.substring(separatorIndex + 1))
                    );
                    continue;
                }

                if (index + 1 >= args.length) {
                    throw new IllegalArgumentException("Valeur manquante apres l option de ligne de commande '" + rawArgument + "'.");
                }

                values.put(argumentBody.trim(), unquote(args[++index]));
                continue;
            }

            if (rawArgument.startsWith("-D")) {
                String argumentBody = rawArgument.substring(2);
                int separatorIndex = argumentBody.indexOf('=');
                if (separatorIndex < 0) {
                    throw new IllegalArgumentException(
                            "Argument de type systeme invalide '" + rawArgument + "'. Format attendu : -Dkey=value."
                    );
                }

                values.put(
                        argumentBody.substring(0, separatorIndex).trim(),
                        unquote(argumentBody.substring(separatorIndex + 1))
                );
                continue;
            }

            throw new IllegalArgumentException(
                    "Argument non supporte '" + rawArgument + "'. Utilisez --key=value, --key value ou -Dkey=value."
            );
        }
        return values;
    }

    private static Map<String, String> parseConfiguration(Path configFile) throws IOException {
        String fileName = configFile.getFileName().toString().toLowerCase();
        if (fileName.endsWith(".properties")) {
            return parseProperties(configFile);
        }
        if (fileName.endsWith(".yml") || fileName.endsWith(".yaml")) {
            return parseFlatYaml(configFile);
        }
        throw new IllegalArgumentException("Format de fichier de configuration non supporte : " + configFile);
    }

    private static void applySystemProperties(Map<String, String> values) {
        for (String key : SUPPORTED_KEYS) {
            String systemPropertyValue = System.getProperty(key);
            if (hasText(systemPropertyValue)) {
                values.put(key, systemPropertyValue.trim());
            }
        }
    }

    private static void applyCommandLineArguments(Map<String, String> values, Map<String, String> arguments) {
        for (String key : SUPPORTED_KEYS) {
            String argumentValue = arguments.get(key);
            if (hasText(argumentValue)) {
                values.put(key, argumentValue.trim());
            }
        }
    }

    private static String helperOption(Map<String, String> arguments, String key, String defaultValue) {
        String argumentValue = arguments.get(key);
        if (hasText(argumentValue)) {
            return argumentValue.trim();
        }

        String systemPropertyValue = System.getProperty(key);
        if (hasText(systemPropertyValue)) {
            return systemPropertyValue.trim();
        }

        return defaultValue;
    }

    private static Map<String, String> parseProperties(Path configFile) throws IOException {
        Properties properties = new Properties();
        try (Reader reader = Files.newBufferedReader(configFile, StandardCharsets.UTF_8)) {
            properties.load(reader);
        }

        Map<String, String> values = new LinkedHashMap<>();
        for (String propertyName : properties.stringPropertyNames()) {
            values.put(propertyName, unquote(properties.getProperty(propertyName)));
        }
        return values;
    }

    private static Map<String, String> parseFlatYaml(Path configFile) throws IOException {
        Map<String, String> values = new LinkedHashMap<>();
        for (String rawLine : Files.readAllLines(configFile, StandardCharsets.UTF_8)) {
            String line = rawLine.trim();
            if (line.isEmpty() || line.startsWith("#")) {
                continue;
            }

            int separatorIndex = line.indexOf(':');
            if (separatorIndex < 0) {
                throw new IllegalArgumentException(
                        "Seules les paires cle/valeur YAML a plat sont supportees. Ligne invalide : " + rawLine
                );
            }

            String key = line.substring(0, separatorIndex).trim();
            String value = line.substring(separatorIndex + 1).trim();
            values.put(key, unquote(value));
        }
        return values;
    }

    private static Path resolvePath(Path workingDirectory, String rawPath) {
        Path candidate = Paths.get(rawPath);
        if (candidate.isAbsolute()) {
            return candidate.normalize();
        }
        return workingDirectory.resolve(candidate).normalize();
    }

    private static Path resolveExistingFile(Path workingDirectory, String rawPath, String label) {
        Path resolvedPath = resolvePath(workingDirectory, rawPath);
        if (!Files.isRegularFile(resolvedPath)) {
            throw new IllegalArgumentException("Le chemin fourni pour '" + label + "' ne pointe pas vers un fichier : " + resolvedPath);
        }
        return resolvedPath;
    }

    private static Path resolveExistingDirectory(Path workingDirectory, String rawPath, String label) {
        Path resolvedPath = resolvePath(workingDirectory, rawPath);
        if (!Files.isDirectory(resolvedPath)) {
            throw new IllegalArgumentException(
                    "Le chemin fourni pour '" + label + "' ne pointe pas vers un repertoire : " + resolvedPath
            );
        }
        return resolvedPath;
    }

    private static Path findMavenExecutableOnPath() {
        String pathVariable = environmentOrDefault("PATH", "");
        if (!hasText(pathVariable)) {
            return null;
        }

        boolean windows = System.getProperty("os.name", "").toLowerCase().contains("win");
        List<String> executableNames = windows
                ? List.of("mvn.cmd", "mvn.bat", "mvn.exe", "mvn")
                : List.of("mvn");

        for (String pathEntry : pathVariable.split(java.io.File.pathSeparator)) {
            if (!hasText(pathEntry)) {
                continue;
            }

            Path directory = Paths.get(pathEntry.trim());
            for (String executableName : executableNames) {
                Path candidate = directory.resolve(executableName);
                if (Files.isRegularFile(candidate)) {
                    return candidate.normalize();
                }
            }
        }
        return null;
    }

    private static void requireValue(Map<String, String> values, String key) {
        String value = values.get(key);
        if (!hasText(value)) {
            throw new IllegalArgumentException(
                    "Cle obligatoire manquante '" + key + "'. Fournissez-la dans le fichier de configuration ou sur la ligne de commande."
            );
        }
    }

    private static void validateGitConfiguration(Map<String, String> values) {
        boolean hasRepository = hasText(values.get("gitRepositoryUrl"));
        boolean hasBranch = hasText(values.get("gitBranch"));
        if (hasRepository != hasBranch) {
            throw new IllegalArgumentException(
                    "Les parametres Git 'gitRepositoryUrl' et 'gitBranch' doivent etre renseignes ensemble."
            );
        }
    }

    private static String systemPropertyOrDefault(String key, String defaultValue) {
        String value = System.getProperty(key);
        if (!hasText(value)) {
            return defaultValue;
        }
        return value;
    }

    private static String environmentOrDefault(String key, String defaultValue) {
        String value = System.getenv(key);
        if (!hasText(value)) {
            return defaultValue;
        }
        return value;
    }

    private static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }

    private static String unquote(String value) {
        String trimmed = Objects.requireNonNullElse(value, "").trim();
        if (trimmed.length() >= 2) {
            if (trimmed.startsWith("\"") && trimmed.endsWith("\"")) {
                return trimmed.substring(1, trimmed.length() - 1);
            }
            if (trimmed.startsWith("'") && trimmed.endsWith("'")) {
                return trimmed.substring(1, trimmed.length() - 1);
            }
        }
        return trimmed;
    }

    private static void printUsage() {
        System.out.println("Utilisation :");
        System.out.println("  java -jar archetype-config-generator-1.0.0.jar --configFile=chemin --outputDirectory=chemin");
        System.out.println("  java -jar archetype-config-generator-1.0.0.jar --groupId=com.example --artifactId=my-app ...");
        System.out.println();
        System.out.println("Cles de generation supportees :");
        for (String key : SUPPORTED_KEYS) {
            System.out.println("  --" + key + "=...");
        }
        System.out.println();
        System.out.println("Cles helper supportees :");
        for (String key : SUPPORTED_HELPER_KEYS) {
            System.out.println("  --" + key + "=...");
        }
    }
}
