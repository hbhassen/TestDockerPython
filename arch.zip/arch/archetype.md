# Structure Du Depot Archetype

## 1. Objectif

Ce fichier explique le contenu de chaque dossier important de `PROJET_archetype` et le role de chaque zone principale du depot.

Le depot est un build Maven multi-modules.

Une seule commande :

```powershell
mvn -B clean install
```

construit ces trois artefacts :

- `springboot-enterprise-archetype-1.0.0`
- `archetype-config-maven-plugin-1.0.0`
- `archetype-config-generator-1.0.0`

## 2. Vue D Ensemble De La Racine

### `pom.xml`

Agregateur Maven racine.

Il :

- definit le build multi-modules
- centralise la version
- centralise le niveau Java
- permet de construire tout le depot avec une seule commande

### `.tools/`

Outillage technique local utilise pendant les validations.

Usage principal :

- JDK 21 local pour construire et tester

Ce dossier est une infrastructure de support, pas le coeur fonctionnel de l archetype.

### `springboot-enterprise-archetype/`

Module principal de l archetype.

C est le dossier le plus important du depot.

Il contient :

- la definition de l archetype Maven
- le template complet du projet copie lors de la generation

### `archetype-config-maven-plugin/`

Module du plugin Maven.

Il fournit une commande Maven qui supporte `-DconfigFile`.

### `maven-config-generator/`

Module du helper jar executable.

Il fournit la generation via `java -jar`.

### `examples/`

Fichiers d exemple de configuration pour la generation.

Utilises pour :

- la documentation
- les tests manuels rapides
- les scenarios de validation

### `scripts/`

Scripts helpers facultatifs.

Ces scripts sont des outils de confort, pas le chemin principal de generation.

### `target/`

Sorties de build Maven a la racine du depot.

Ce dossier est genere automatiquement et ne contient pas de code source.

## 3. Module `springboot-enterprise-archetype/`

### Fonction

Ce module produit l artefact :

- `springboot-enterprise-archetype-1.0.0.jar`

### Fichiers Principaux

- `springboot-enterprise-archetype/pom.xml`
- `springboot-enterprise-archetype/src/main/resources/META-INF/maven/archetype-metadata.xml`
- `springboot-enterprise-archetype/src/main/resources/archetype-resources/`

### `springboot-enterprise-archetype/pom.xml`

Ce POM :

- utilise le packaging `maven-archetype`
- active le packaging d archetype
- definit l artefact de l archetype lui-meme

### `springboot-enterprise-archetype/src/main/resources/META-INF/maven/`

Contient les metadonnees de l archetype.

Fichier principal :

- `archetype-metadata.xml`

Ce fichier definit :

- les proprietes de generation
- les valeurs par defaut
- les `fileSets`
- les ressources filtrees

### `springboot-enterprise-archetype/src/main/resources/archetype-resources/`

Il s agit du template du projet genere.

Tout ce qui se trouve dans ce dossier est copie et filtre lorsque l archetype genere une nouvelle application.

## 4. Racine Du Template Dans `archetype-resources/`

Fichiers importants :

- `springboot-enterprise-archetype/src/main/resources/archetype-resources/pom.xml`
- `springboot-enterprise-archetype/src/main/resources/archetype-resources/Dockerfile`
- `springboot-enterprise-archetype/src/main/resources/archetype-resources/Jenkinsfile`
- `springboot-enterprise-archetype/src/main/resources/archetype-resources/.dockerignore`
- `springboot-enterprise-archetype/src/main/resources/archetype-resources/README.md`

### Template `pom.xml`

Definit les dependances et plugins de l application generee.

Il contient des sections conditionnelles basees sur :

- `webStack`
- `databaseType`

### `Dockerfile`

Definit la construction multi-stage de l image Docker de l application generee.

### `Jenkinsfile`

Definit le pipeline Jenkins livre avec le projet genere.

### `.dockerignore`

Definit les fichiers exclus du contexte de build Docker.

### `README.md`

Documente les metadonnees et commandes de base du projet genere.

## 5. Arborescence Source De L Application Generee

Le code source du projet genere se trouve dans :

- `springboot-enterprise-archetype/src/main/resources/archetype-resources/src/main/java/`

Zones principales :

- `Application.java`
- `config/`
- `domaine/dto/`
- `domaine/entities/`
- `repositories/`
- `services/`
- `rest/`

### `Application.java`

Point d entree Spring Boot de l application generee.

### `config/`

Classes de configuration technique.

Responsabilites principales :

- securite
- OpenAPI
- proprietes de metadonnees
- initialisation des donnees de depart

Fichiers importants :

- `ApplicationMetadataProperties.java`
- `ApplicationMetadataInitializer.java`
- `OpenApiConfig.java`
- `SecurityConfig.java`

### `domaine/dto/`

Definitions des DTO sortants exposes par l API d exemple.

Fichier principal :

- `ApplicationVersionResponse.java`

### `domaine/entities/`

Entites JPA de l application d exemple generee.

Fichier principal :

- `ApplicationMetadataEntity.java`

### `repositories/`

Couche de persistance de l application generee.

Fichier principal :

- `ApplicationMetadataRepository.java`

Ce repository est un repository JPA et c est la seule abstraction de persistance utilisee dans l exemple genere.

### `services/`

Couche service applicative.

Fichiers principaux :

- `ApplicationInfoService.java`
- `ApplicationInfoServiceImpl.java`

Cette couche :

- lit les donnees via JPA
- transforme les entites en DTO
- garde les responsabilites HTTP hors de la couche metier

### `rest/`

Couche API REST.

Fichier principal :

- `ApplicationVersionController.java`

Ce controleur expose :

- `GET /api/application/version`

## 6. Ressources De L Application Generee

Les ressources d execution generees se trouvent dans :

- `springboot-enterprise-archetype/src/main/resources/archetype-resources/src/main/resources/`

Fichiers principaux :

- `application.yml`
- `schema.sql`

### `application.yml`

Configuration d execution generee.

Elle contient :

- le port serveur
- le type de pile web
- la configuration datasource
- la configuration JPA
- la configuration actuator
- la configuration Swagger
- les metadonnees applicatives

### `schema.sql`

Cree le schema de base configure avant que JPA ne gere les tables.

## 7. Arborescence Des Tests Generes

Les tests generes se trouvent dans :

- `springboot-enterprise-archetype/src/main/resources/archetype-resources/src/test/java/`
- `springboot-enterprise-archetype/src/main/resources/archetype-resources/src/test/resources/`

Fichiers de test principaux :

- `ApplicationContextTest.java`
- `ApplicationVersionControllerTest.java`
- `application.yml`

### `ApplicationContextTest.java`

Verifie que le contexte Spring demarre correctement.

### `ApplicationVersionControllerTest.java`

Verifie le endpoint REST d exemple.

Il utilise :

- `MockMvc` pour `webmvc`
- `WebTestClient` pour `webflux`

### `application.yml` De Test

Force H2 pour les tests afin que leur execution reste autonome et deterministe.

## 8. Module `archetype-config-maven-plugin/`

### Fonction

Ce module produit :

- `archetype-config-maven-plugin-1.0.0.jar`

### Contenu Principal

- `archetype-config-maven-plugin/pom.xml`
- `archetype-config-maven-plugin/src/main/java/com/company/archetype/plugin/ArchetypeConfigGenerateMojo.java`

### Utilite

Il ajoute le goal Maven :

- `com.company.archetype:archetype-config-maven-plugin:1.0.0:generate`

Ce goal supporte :

- `-DconfigFile=...`
- les valeurs inline `-D...`
- la publication Git optionnelle via `gitRepositoryUrl` et `gitBranch`

C est la meilleure option quand l utilisateur veut une commande Maven native avec un fichier d entree.

## 9. Module `maven-config-generator/`

### Fonction

Ce module produit :

- `archetype-config-generator-1.0.0.jar`

### Contenu Principal

- `maven-config-generator/pom.xml`
- `maven-config-generator/src/main/java/com/company/archetype/generator/ArchetypeConfigGenerator.java`

### Utilite

Il fournit un helper autonome executable via :

```powershell
java -jar .\maven-config-generator\target\archetype-config-generator-1.0.0.jar
```

Il supporte :

- `.properties`
- `.yml`
- `.yaml`
- les parametres inline
- la publication Git optionnelle via `gitRepositoryUrl` et `gitBranch`

## 10. Dossier `examples/`

### Fonction

Contient des entrees de generation pretes a l emploi.

Fichiers principaux :

- `examples/generation-h2.properties`
- `examples/generation-postgresql.yml`

### Utilite

Ces exemples montrent :

- une generation H2 + WebMVC
- une generation PostgreSQL + WebFlux

## 11. Dossier `scripts/`

### Fonction

Contient des scripts helpers locaux facultatifs.

Fichiers principaux :

- `scripts/generate-project.ps1`
- `scripts/generate-project.py`

### Utilite

Utile pour l automatisation locale, mais secondaire par rapport :

- au plugin Maven
- au helper jar

## 12. Dossier `target/`

### Fonction

Contient les sorties de build generees.

Ce dossier est :

- temporaire
- genere par Maven
- non destine a une maintenance manuelle

## 13. Ordre De Lecture Recommande

Si vous devez comprendre rapidement le depot, lisez dans cet ordre :

1. `pom.xml`
2. `springboot-enterprise-archetype/pom.xml`
3. `springboot-enterprise-archetype/src/main/resources/META-INF/maven/archetype-metadata.xml`
4. `springboot-enterprise-archetype/src/main/resources/archetype-resources/pom.xml`
5. `springboot-enterprise-archetype/src/main/resources/archetype-resources/src/main/resources/application.yml`
6. `archetype-config-maven-plugin/src/main/java/com/company/archetype/plugin/ArchetypeConfigGenerateMojo.java`
7. `maven-config-generator/src/main/java/com/company/archetype/generator/ArchetypeConfigGenerator.java`

## 14. Resume

Le depot est organise autour de trois modules de production principaux :

- `springboot-enterprise-archetype/`
- `archetype-config-maven-plugin/`
- `maven-config-generator/`

Le coeur fonctionnel reste :

- `springboot-enterprise-archetype/src/main/resources/META-INF/maven/archetype-metadata.xml`
- `springboot-enterprise-archetype/src/main/resources/archetype-resources/`

Ce sont les deux emplacements les plus importants a comprendre avant de faire evoluer le comportement de l archetype.
