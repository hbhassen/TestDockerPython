﻿# Documentation Utilisateur Final

Ce document sert de point d'entree vers les deux guides specialises de l'archetype.

## Guides Disponibles

- `DOCUMENTATION_UTILISATEURS_ARCHETYPE.md`
- `DOCUMENTATION_TECHNIQUE_ARCHETYPE.md`

## Quel Document Lire

Lisez `DOCUMENTATION_UTILISATEURS_ARCHETYPE.md` si vous voulez :

- installer l'archetype
- construire en une seule commande l'archetype, le plugin Maven et le helper jar
- generer un projet avec une commande Maven native basee sur `-DconfigFile`
- generer un projet avec un seul fichier `.properties`
- generer un projet avec un seul fichier `.yml` ou `.yaml`
- generer un projet en passant toutes les proprietes directement sur la commande `java -jar`
- choisir entre `webmvc` et `webflux`
- choisir entre H2 et PostgreSQL
- demarrer, tester et dockeriser le projet genere

Lisez `DOCUMENTATION_TECHNIQUE_ARCHETYPE.md` si vous voulez :

- maintenir l'archetype
- modifier le template genere
- comprendre les sections Velocity
- faire evoluer le helper Maven de generation
- faire evoluer le support `webmvc` / `webflux`
- faire evoluer le support H2 / PostgreSQL
- valider les changements avant livraison

