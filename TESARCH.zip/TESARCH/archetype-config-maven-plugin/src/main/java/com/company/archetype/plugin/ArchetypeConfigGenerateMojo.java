package com.company.archetype.plugin;

import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;
import org.apache.maven.shared.invoker.DefaultInvocationRequest;
import org.apache.maven.shared.invoker.DefaultInvoker;
import org.apache.maven.shared.invoker.InvocationRequest;
import org.apache.maven.shared.invoker.InvocationResult;
import org.apache.maven.shared.invoker.Invoker;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;

/**
 * Goal Maven qui genere un projet depuis l archetype entreprise en acceptant
 * soit un fichier de configuration a plat, soit des proprietes inline en -D.
 */
@Mojo(name = "generate", requiresProject = false, threadSafe = true)
public class ArchetypeConfigGenerateMojo extends AbstractMojo {

    private static final List<String> REQUIRED_KEYS = List.of(
            "groupId",
            "artifactId",
            "version",
            "package",
            "databaseName",
            "databaseSchema"
    );

    @Parameter(property = "configFile")
    private String configFile;

    @Parameter(property = "outputDirectory", defaultValue = "${user.dir}")
    private String outputDirectory;

    @Parameter(property = "archetypeCatalog", defaultValue = "local")
    private String archetypeCatalog;

    @Parameter(property = "archetypeGroupId", defaultValue = "com.company.archetype")
    private String archetypeGroupId;

    @Parameter(property = "archetypeArtifactId", defaultValue = "springboot-enterprise-archetype")
    private String archetypeArtifactId;

    @Parameter(property = "archetypeVersion", defaultValue = "1.0.0")
    private String archetypeVersion;

    @Parameter(property = "mavenHome")
    private String mavenHome;

    @Parameter(property = "mavenExecutable")
    private String mavenExecutable;

    @Parameter(property = "groupId")
    private String groupId;

    @Parameter(property = "artifactId")
    private String artifactId;

    @Parameter(property = "version")
    private String version;

    @Parameter(property = "package")
    private String packageName;

    @Parameter(property = "webStack")
    private String webStack;

    @Parameter(property = "databaseType")
    private String databaseType;

    @Parameter(property = "databaseName")
    private String databaseName;

    @Parameter(property = "databaseSchema")
    private String databaseSchema;

    @Parameter(property = "databaseHost")
    private String databaseHost;

    @Parameter(property = "databasePort")
    private String databasePort;

    @Parameter(property = "databaseUsername")
    private String databaseUsername;

    @Parameter(property = "databasePassword")
    private String databasePassword;

    @Override
    public void execute() throws MojoExecutionException, MojoFailureException {
        Path workingDirectory = Paths.get(System.getProperty("user.dir")).toAbsolutePath().normalize();
        Path resolvedConfigFile = null;
        Map<String, String> values = new LinkedHashMap<>();

        if (hasText(configFile)) {
            resolvedConfigFile = resolvePath(workingDirectory, configFile);
            try {
                values.putAll(parseConfiguration(resolvedConfigFile));
            } catch (IOException exception) {
                throw new MojoExecutionException(
                        "Impossible de lire le fichier de configuration '" + resolvedConfigFile + "'.",
                        exception
                );
            }
        }

        applyInlineValues(values);

        for (String requiredKey : REQUIRED_KEYS) {
            requireValue(values, requiredKey);
        }

        values.putIfAbsent("webStack", "webmvc");
        values.putIfAbsent("databaseType", "h2");
        values.putIfAbsent("databaseHost", "localhost");
        values.putIfAbsent("databasePort", "5432");
        values.putIfAbsent("databaseUsername", "postgres");
        values.putIfAbsent("databasePassword", "postgres");

        String normalizedWebStack = values.get("webStack").trim().toLowerCase();
        if (!"webmvc".equals(normalizedWebStack) && !"webflux".equals(normalizedWebStack)) {
            throw new MojoFailureException("webStack doit valoir 'webmvc' ou 'webflux'.");
        }
        values.put("webStack", normalizedWebStack);

        String normalizedDatabaseType = values.get("databaseType").trim().toLowerCase();
        if ("postgres".equals(normalizedDatabaseType)) {
            normalizedDatabaseType = "postgresql";
        }
        if (!"h2".equals(normalizedDatabaseType) && !"postgresql".equals(normalizedDatabaseType)) {
            throw new MojoFailureException("databaseType doit valoir 'h2' ou 'postgresql'.");
        }
        values.put("databaseType", normalizedDatabaseType);

        Path resolvedOutputDirectory = resolvePath(workingDirectory, outputDirectory);
        Properties requestProperties = new Properties();
        requestProperties.setProperty("archetypeCatalog", archetypeCatalog);
        requestProperties.setProperty("archetypeGroupId", archetypeGroupId);
        requestProperties.setProperty("archetypeArtifactId", archetypeArtifactId);
        requestProperties.setProperty("archetypeVersion", archetypeVersion);
        requestProperties.setProperty("interactiveMode", "false");
        requestProperties.setProperty("outputDirectory", resolvedOutputDirectory.toString());

        for (Map.Entry<String, String> entry : values.entrySet()) {
            requestProperties.setProperty(entry.getKey(), entry.getValue());
        }

        InvocationRequest request = new DefaultInvocationRequest();
        request.setBatchMode(true);
        request.setBaseDirectory(workingDirectory.toFile());
        request.setProperties(requestProperties);
        request.addArg("archetype:generate");

        Invoker invoker = new DefaultInvoker();
        String mavenRuntime = configureInvoker(invoker, workingDirectory);

        if (resolvedConfigFile != null) {
            getLog().info("Generation du projet a partir du fichier de configuration : " + resolvedConfigFile);
        } else {
            getLog().info("Generation du projet a partir de proprietes Maven inline.");
        }
        getLog().info("Pile web : " + normalizedWebStack);
        getLog().info("Type de base de donnees : " + normalizedDatabaseType);
        getLog().info("Repertoire de sortie : " + resolvedOutputDirectory);
        getLog().info("Runtime Maven : " + mavenRuntime);

        try {
            InvocationResult result = invoker.execute(request);
            if (result.getExitCode() != 0) {
                Throwable executionException = result.getExecutionException();
                if (executionException != null) {
                    throw new MojoExecutionException("La generation de l archetype Maven a echoue.", executionException);
                }
                throw new MojoFailureException(
                        "La generation de l archetype Maven a echoue avec le code de sortie " + result.getExitCode() + "."
                );
            }
        } catch (MojoFailureException exception) {
            throw exception;
        } catch (Exception exception) {
            throw new MojoExecutionException("Impossible d executer la generation de l archetype Maven.", exception);
        }
    }

    private void applyInlineValues(Map<String, String> values) {
        putIfHasText(values, "groupId", groupId);
        putIfHasText(values, "artifactId", artifactId);
        putIfHasText(values, "version", version);
        putIfHasText(values, "package", packageName);
        putIfHasText(values, "webStack", webStack);
        putIfHasText(values, "databaseType", databaseType);
        putIfHasText(values, "databaseName", databaseName);
        putIfHasText(values, "databaseSchema", databaseSchema);
        putIfHasText(values, "databaseHost", databaseHost);
        putIfHasText(values, "databasePort", databasePort);
        putIfHasText(values, "databaseUsername", databaseUsername);
        putIfHasText(values, "databasePassword", databasePassword);
    }

    private String configureInvoker(Invoker invoker, Path workingDirectory) throws MojoFailureException {
        if (hasText(mavenExecutable)) {
            Path resolvedExecutable = resolveExistingFile(workingDirectory, mavenExecutable, "mavenExecutable");
            invoker.setMavenExecutable(resolvedExecutable.toFile());
            return "executable " + resolvedExecutable;
        }

        if (hasText(mavenHome)) {
            Path resolvedHome = resolveExistingDirectory(workingDirectory, mavenHome, "mavenHome");
            invoker.setMavenHome(resolvedHome.toFile());
            return "home " + resolvedHome;
        }

        String mavenHomeProperty = System.getProperty("maven.home");
        if (hasText(mavenHomeProperty)) {
            Path resolvedHome = resolveExistingDirectory(workingDirectory, mavenHomeProperty, "maven.home");
            invoker.setMavenHome(resolvedHome.toFile());
            return "home " + resolvedHome;
        }

        String environmentMavenHome = Objects.requireNonNullElse(System.getenv("MAVEN_HOME"), System.getenv("M2_HOME"));
        if (hasText(environmentMavenHome)) {
            Path resolvedHome = resolveExistingDirectory(workingDirectory, environmentMavenHome, "MAVEN_HOME");
            invoker.setMavenHome(resolvedHome.toFile());
            return "home " + resolvedHome;
        }

        Path discoveredExecutable = findMavenExecutableOnPath();
        if (discoveredExecutable != null) {
            invoker.setMavenExecutable(discoveredExecutable.toFile());
            return "executable " + discoveredExecutable;
        }

        throw new MojoFailureException(
                "Impossible de localiser Maven. Fournissez -DmavenExecutable=..., -DmavenHome=..., ou definissez MAVEN_HOME / M2_HOME."
        );
    }

    private Map<String, String> parseConfiguration(Path configPath) throws IOException, MojoFailureException {
        String lowerCaseName = configPath.getFileName().toString().toLowerCase();
        if (lowerCaseName.endsWith(".properties")) {
            return parseProperties(configPath);
        }
        if (lowerCaseName.endsWith(".yml") || lowerCaseName.endsWith(".yaml")) {
            return parseFlatYaml(configPath);
        }
        throw new MojoFailureException("Format de fichier de configuration non supporte : " + configPath);
    }

    private Map<String, String> parseProperties(Path configPath) throws IOException {
        Properties properties = new Properties();
        try (Reader reader = Files.newBufferedReader(configPath, StandardCharsets.UTF_8)) {
            properties.load(reader);
        }

        Map<String, String> values = new LinkedHashMap<>();
        for (String propertyName : properties.stringPropertyNames()) {
            values.put(propertyName, unquote(properties.getProperty(propertyName)));
        }
        return values;
    }

    private Map<String, String> parseFlatYaml(Path configPath) throws IOException, MojoFailureException {
        Map<String, String> values = new LinkedHashMap<>();
        for (String rawLine : Files.readAllLines(configPath, StandardCharsets.UTF_8)) {
            String line = rawLine.trim();
            if (line.isEmpty() || line.startsWith("#")) {
                continue;
            }

            int separatorIndex = line.indexOf(':');
            if (separatorIndex < 0) {
                throw new MojoFailureException(
                        "Seules les paires cle/valeur YAML a plat sont supportees. Ligne invalide : " + rawLine
                );
            }

            String key = line.substring(0, separatorIndex).trim();
            String value = line.substring(separatorIndex + 1).trim();
            values.put(key, unquote(value));
        }
        return values;
    }

    private Path resolvePath(Path workingDirectory, String rawPath) {
        Path candidate = Paths.get(rawPath);
        if (candidate.isAbsolute()) {
            return candidate.normalize();
        }
        return workingDirectory.resolve(candidate).normalize();
    }

    private Path resolveExistingFile(Path workingDirectory, String rawPath, String label) throws MojoFailureException {
        Path resolvedPath = resolvePath(workingDirectory, rawPath);
        if (!Files.isRegularFile(resolvedPath)) {
            throw new MojoFailureException(
                    "Le chemin fourni pour '" + label + "' ne pointe pas vers un fichier : " + resolvedPath
            );
        }
        return resolvedPath;
    }

    private Path resolveExistingDirectory(Path workingDirectory, String rawPath, String label) throws MojoFailureException {
        Path resolvedPath = resolvePath(workingDirectory, rawPath);
        if (!Files.isDirectory(resolvedPath)) {
            throw new MojoFailureException(
                    "Le chemin fourni pour '" + label + "' ne pointe pas vers un repertoire : " + resolvedPath
            );
        }
        return resolvedPath;
    }

    private Path findMavenExecutableOnPath() {
        String pathVariable = System.getenv("PATH");
        if (!hasText(pathVariable)) {
            return null;
        }

        boolean windows = System.getProperty("os.name", "").toLowerCase().contains("win");
        List<String> executableNames = windows
                ? List.of("mvn.cmd", "mvn.bat", "mvn.exe", "mvn")
                : List.of("mvn");

        for (String pathEntry : pathVariable.split(java.io.File.pathSeparator)) {
            if (!hasText(pathEntry)) {
                continue;
            }

            Path directory = Paths.get(pathEntry.trim());
            for (String executableName : executableNames) {
                Path candidate = directory.resolve(executableName);
                if (Files.isRegularFile(candidate)) {
                    return candidate.normalize();
                }
            }
        }
        return null;
    }

    private void requireValue(Map<String, String> values, String key) throws MojoFailureException {
        String value = values.get(key);
        if (!hasText(value)) {
            throw new MojoFailureException(
                    "Cle obligatoire manquante '" + key + "'. Fournissez-la dans le fichier de configuration ou via une propriete -D."
            );
        }
    }

    private void putIfHasText(Map<String, String> values, String key, String value) {
        if (hasText(value)) {
            values.put(key, value.trim());
        }
    }

    private boolean hasText(String value) {
        return value != null && !value.isBlank();
    }

    private String unquote(String value) {
        String trimmed = Objects.requireNonNullElse(value, "").trim();
        if (trimmed.length() >= 2) {
            if (trimmed.startsWith("\"") && trimmed.endsWith("\"")) {
                return trimmed.substring(1, trimmed.length() - 1);
            }
            if (trimmed.startsWith("'") && trimmed.endsWith("'")) {
                return trimmed.substring(1, trimmed.length() - 1);
            }
        }
        return trimmed;
    }
}
