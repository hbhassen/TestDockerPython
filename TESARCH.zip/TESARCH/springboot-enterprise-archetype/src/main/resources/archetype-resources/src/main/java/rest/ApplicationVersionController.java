package ${package}.rest;

import ${package}.domaine.dto.ApplicationVersionResponse;
import ${package}.services.ApplicationInfoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
#if($webStack == "webmvc")
import org.springframework.http.ResponseEntity;
#end
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
#if($webStack == "webflux")
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
#end

/**
 * Controleur REST exposant le endpoint d exemple des metadonnees applicatives.
 *
 * <p>Utilisez ce controleur comme reference pour le decoupage attendu :
 * controller -> service -> repository -> database.
 */
@RestController
@RequestMapping("/api/application")
@Tag(name = "Application", description = "Endpoints des metadonnees applicatives")
public class ApplicationVersionController {

    private final ApplicationInfoService applicationInfoService;

    public ApplicationVersionController(ApplicationInfoService applicationInfoService) {
        this.applicationInfoService = applicationInfoService;
    }

    /**
     * Retourne les metadonnees de l application generee.
     *
     * @return charge utile des metadonnees applicatives
     */
    @GetMapping("/version")
    @Operation(summary = "Obtenir la version de l application", description = "Retourne les metadonnees de l application generee.")
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Metadonnees applicatives retournees avec succes",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ApplicationVersionResponse.class)
                    )
            )
    })
#if($webStack == "webmvc")
    public ResponseEntity<ApplicationVersionResponse> getApplicationVersion() {
        return ResponseEntity.ok(applicationInfoService.getApplicationVersion());
    }
#end
#if($webStack == "webflux")
    public Mono<ApplicationVersionResponse> getApplicationVersion() {
        return Mono.fromCallable(applicationInfoService::getApplicationVersion)
                .subscribeOn(Schedulers.boundedElastic());
    }
#end
}
