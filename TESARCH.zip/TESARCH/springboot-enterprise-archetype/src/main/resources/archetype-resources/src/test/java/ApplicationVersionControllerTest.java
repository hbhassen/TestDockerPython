package ${package};

import ${package}.config.ApplicationMetadataProperties;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
#if($webStack == "webmvc")
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
#end
#if($webStack == "webflux")
import org.springframework.boot.webtestclient.autoconfigure.AutoConfigureWebTestClient;
#end
#if($webStack == "webmvc")
import org.springframework.test.web.servlet.MockMvc;
#end
#if($webStack == "webflux")
import org.springframework.test.web.reactive.server.WebTestClient;
#end

#if($webStack == "webmvc")
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
#end

/**
 * Verifie le contrat REST public expose par le endpoint d exemple genere.
 *
 * <p>Ce test utilise la datasource de test generee pour pouvoir s executer
 * sans base externe, meme quand la cible d execution principale est PostgreSQL.
 */
#if($webStack == "webmvc")
@SpringBootTest
@AutoConfigureMockMvc
#end
#if($webStack == "webflux")
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureWebTestClient
#end
class ApplicationVersionControllerTest {

#if($webStack == "webmvc")
    private final MockMvc mockMvc;
#end
#if($webStack == "webflux")
    private final WebTestClient webTestClient;
#end
    private final ApplicationMetadataProperties applicationMetadataProperties;

    @Autowired
    ApplicationVersionControllerTest(
#if($webStack == "webmvc")
            MockMvc mockMvc,
#end
#if($webStack == "webflux")
            WebTestClient webTestClient,
#end
            ApplicationMetadataProperties applicationMetadataProperties
    ) {
#if($webStack == "webmvc")
        this.mockMvc = mockMvc;
#end
#if($webStack == "webflux")
        this.webTestClient = webTestClient;
#end
        this.applicationMetadataProperties = applicationMetadataProperties;
    }

    /**
     * Verifie que le endpoint de version retourne bien la charge utile de metadonnees configuree.
     *
     * @throws Exception si MockMvc n arrive pas a executer la requete
     */
    @Test
#if($webStack == "webmvc")
    void shouldReturnApplicationVersion() throws Exception {
        mockMvc.perform(get("/api/application/version"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value(applicationMetadataProperties.name()))
                .andExpect(jsonPath("$.version").value(applicationMetadataProperties.version()))
                .andExpect(jsonPath("$.description").value(applicationMetadataProperties.description()));
    }
#end
#if($webStack == "webflux")
    void shouldReturnApplicationVersion() {
        webTestClient.get()
                .uri("/api/application/version")
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.name").isEqualTo(applicationMetadataProperties.name())
                .jsonPath("$.version").isEqualTo(applicationMetadataProperties.version())
                .jsonPath("$.description").isEqualTo(applicationMetadataProperties.description());
    }
#end
}
