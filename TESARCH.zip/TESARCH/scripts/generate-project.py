#!/usr/bin/env python3

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path


def unquote(value: str) -> str:
    value = value.strip()
    if len(value) >= 2 and (
        (value.startswith('"') and value.endswith('"'))
        or (value.startswith("'") and value.endswith("'"))
    ):
        return value[1:-1]
    return value


def parse_properties(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or line.startswith("!"):
            continue
        if "=" not in line:
            raise ValueError(f"Ligne properties invalide : {raw_line}")
        key, value = line.split("=", 1)
        values[key.strip()] = unquote(value)
    return values


def parse_flat_yaml(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" not in line:
            raise ValueError(
                f"Seules les paires cle/valeur YAML a plat sont supportees. Ligne invalide : {raw_line}"
            )
        key, value = line.split(":", 1)
        values[key.strip()] = unquote(value)
    return values


def parse_config(path: Path) -> dict[str, str]:
    extension = path.suffix.lower()
    if extension == ".properties":
        return parse_properties(path)
    if extension in {".yml", ".yaml"}:
        return parse_flat_yaml(path)
    raise ValueError(f"Format de fichier de configuration non supporte : {extension}")


def require(values: dict[str, str], key: str) -> None:
    if not values.get(key):
        raise ValueError(f"Cle obligatoire manquante '{key}' dans le fichier de configuration.")


def resolve_maven_command() -> str:
    candidates = ["mvn.cmd", "mvn.bat", "mvn"]
    for candidate in candidates:
        resolved = shutil.which(candidate)
        if resolved:
            return resolved
    raise RuntimeError(
        "Executable Maven introuvable dans le PATH. Installez Maven 3.9+ et verifiez que mvn est disponible."
    )


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Genere un projet depuis l archetype entreprise a partir d un fichier properties ou YAML."
    )
    parser.add_argument("config_file", help="Chemin vers un fichier .properties, .yml ou .yaml")
    parser.add_argument("--archetype-group-id", default="com.company.archetype")
    parser.add_argument("--archetype-artifact-id", default="springboot-enterprise-archetype")
    parser.add_argument("--archetype-version", default="1.0.0")
    parser.add_argument("--archetype-catalog", default="local")
    parser.add_argument("--output-directory", default=".")
    args = parser.parse_args()

    config_path = Path(args.config_file).resolve()
    values = parse_config(config_path)

    for key in (
        "groupId",
        "artifactId",
        "version",
        "package",
        "databaseName",
        "databaseSchema",
    ):
        require(values, key)

    values.setdefault("webStack", "webmvc")
    values.setdefault("databaseHost", "localhost")
    values.setdefault("databasePort", "5432")
    values.setdefault("databaseUsername", "postgres")
    values.setdefault("databasePassword", "postgres")

    web_stack = values["webStack"].strip().lower()
    if web_stack not in {"webmvc", "webflux"}:
        raise ValueError("webStack doit valoir 'webmvc' ou 'webflux'.")
    values["webStack"] = web_stack

    values.setdefault("databaseType", "h2")
    database_type = values["databaseType"].strip().lower()
    if database_type == "postgres":
        database_type = "postgresql"
        values["databaseType"] = database_type

    if database_type not in {"h2", "postgresql"}:
        raise ValueError("databaseType doit valoir 'h2' ou 'postgresql'.")

    command = [
        resolve_maven_command(),
        "-B",
        "archetype:generate",
        f"-DarchetypeCatalog={args.archetype_catalog}",
        f"-DarchetypeGroupId={args.archetype_group_id}",
        f"-DarchetypeArtifactId={args.archetype_artifact_id}",
        f"-DarchetypeVersion={args.archetype_version}",
        "-DinteractiveMode=false",
        f"-DoutputDirectory={args.output_directory}",
    ]

    for key, value in values.items():
        command.append(f"-D{key}={value}")

    print(f"Generation du projet a partir du fichier de configuration '{config_path}'...")
    print(f"Pile web : {web_stack}")
    print(f"Type de base de donnees : {database_type}")

    completed = subprocess.run(command, check=False)
    return completed.returncode


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERREUR : {exc}", file=sys.stderr)
        raise SystemExit(1)
