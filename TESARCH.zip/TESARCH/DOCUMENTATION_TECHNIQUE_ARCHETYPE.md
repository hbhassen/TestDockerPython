﻿# Documentation Technique Archetype

## 1. Objectif

Cette documentation s'adresse aux developpeurs qui maintiennent le depot de l'archetype.

Le depot est maintenant organise comme un build Maven multi-modules. Une seule commande :

```powershell
mvn -B clean install
```

construit et installe localement les trois artefacts suivants :

- `springboot-enterprise-archetype-1.0.0`
- `archetype-config-maven-plugin-1.0.0`
- `archetype-config-generator-1.0.0`

## 2. Structure Du Depot

Le depot contient quatre blocs principaux :

- le build racine Maven
- le module archetype
- le module plugin Maven
- le module helper jar

### Racine

Fichiers et dossiers principaux :

- `pom.xml`
- `springboot-enterprise-archetype/`
- `archetype-config-maven-plugin/`
- `maven-config-generator/`
- `examples/`
- `scripts/`

## 3. Fonction Du `pom.xml` Racine

Le `pom.xml` racine :

- utilise le packaging `pom`
- declare les modules Maven du depot
- centralise la version `1.0.0`
- centralise le niveau Java `21`
- permet de construire tout le depot avec une seule commande

Modules declares :

- `springboot-enterprise-archetype`
- `archetype-config-maven-plugin`
- `maven-config-generator`

## 4. Module `springboot-enterprise-archetype/`

### Fonction

Ce module contient l'archetype Maven lui-meme.

### Fichiers principaux

- `springboot-enterprise-archetype/pom.xml`
- `springboot-enterprise-archetype/src/main/resources/META-INF/maven/archetype-metadata.xml`
- `springboot-enterprise-archetype/src/main/resources/archetype-resources/`

### `springboot-enterprise-archetype/pom.xml`

Ce POM :

- utilise le packaging `maven-archetype`
- produit l'artefact `springboot-enterprise-archetype-1.0.0.jar`
- declare l'extension `archetype-packaging`

### `archetype-metadata.xml`

Ce fichier declare :

- les proprietes de generation
- leurs valeurs par defaut
- les `fileSets`
- les ressources filtrees

Proprietes principales :

- `groupId`
- `artifactId`
- `version`
- `package`
- `webStack`
- `databaseType`
- `databaseName`
- `databaseSchema`
- `databaseHost`
- `databasePort`
- `databaseUsername`
- `databasePassword`

### `archetype-resources/`

Ce dossier contient le template reel du projet genere.

Tout changement fonctionnel applique au projet genere doit etre fait dans cette zone.

## 5. Structure Interne Du Template

Le template est dans :

- `springboot-enterprise-archetype/src/main/resources/archetype-resources/`

### Fichiers racine du template

- `pom.xml`
- `Dockerfile`
- `Jenkinsfile`
- `.dockerignore`

### Code Java principal

- `springboot-enterprise-archetype/src/main/resources/archetype-resources/src/main/java/Application.java`
- `springboot-enterprise-archetype/src/main/resources/archetype-resources/src/main/java/config/`
- `springboot-enterprise-archetype/src/main/resources/archetype-resources/src/main/java/domaine/`
- `springboot-enterprise-archetype/src/main/resources/archetype-resources/src/main/java/repositories/`
- `springboot-enterprise-archetype/src/main/resources/archetype-resources/src/main/java/services/`
- `springboot-enterprise-archetype/src/main/resources/archetype-resources/src/main/java/rest/`

### Ressources d execution

- `springboot-enterprise-archetype/src/main/resources/archetype-resources/src/main/resources/application.yml`
- `springboot-enterprise-archetype/src/main/resources/archetype-resources/src/main/resources/schema.sql`

### Tests

- `springboot-enterprise-archetype/src/main/resources/archetype-resources/src/test/java/ApplicationContextTest.java`
- `springboot-enterprise-archetype/src/main/resources/archetype-resources/src/test/java/ApplicationVersionControllerTest.java`
- `springboot-enterprise-archetype/src/main/resources/archetype-resources/src/test/resources/application.yml`

## 6. Logique Technique Du Template

Le template genere :

- une application Spring Boot 4
- un choix `webmvc` ou `webflux`
- un choix `h2` ou `postgresql`
- une couche repository JPA unique
- une securite moderne
- une documentation OpenAPI

Les branchements Velocity importants se trouvent dans :

- `springboot-enterprise-archetype/src/main/resources/archetype-resources/pom.xml`
- `springboot-enterprise-archetype/src/main/resources/archetype-resources/src/main/java/config/SecurityConfig.java`
- `springboot-enterprise-archetype/src/main/resources/archetype-resources/src/main/java/rest/ApplicationVersionController.java`
- `springboot-enterprise-archetype/src/main/resources/archetype-resources/src/test/java/ApplicationVersionControllerTest.java`
- `springboot-enterprise-archetype/src/main/resources/archetype-resources/src/main/resources/application.yml`

## 7. Module `archetype-config-maven-plugin/`

### Fonction

Ce module produit un plugin Maven pour generer un projet en restant sur une commande Maven native.

Artefact produit :

- `archetype-config-maven-plugin-1.0.0.jar`

### Fichiers principaux

- `archetype-config-maven-plugin/pom.xml`
- `archetype-config-maven-plugin/src/main/java/com/company/archetype/plugin/ArchetypeConfigGenerateMojo.java`

### Utilite

Ce plugin ajoute le goal :

- `com.company.archetype:archetype-config-maven-plugin:1.0.0:generate`

Ce goal :

- accepte `-DconfigFile=...`
- accepte aussi les proprietes inline `-D...`
- applique les valeurs par defaut
- lance ensuite `archetype:generate`

Exemple :

```powershell
mvn --% -B com.company.archetype:archetype-config-maven-plugin:1.0.0:generate -DconfigFile=.\examples\generation-h2.properties -DoutputDirectory=.\generated
```

## 8. Module `maven-config-generator/`

### Fonction

Ce module produit un helper jar executable.

Artefact produit :

- `archetype-config-generator-1.0.0.jar`

### Fichiers principaux

- `maven-config-generator/pom.xml`
- `maven-config-generator/src/main/java/com/company/archetype/generator/ArchetypeConfigGenerator.java`

### Utilite

Ce helper permet de generer un projet avec :

- un fichier `.properties`
- un fichier `.yml` ou `.yaml`
- ou des arguments inline

Exemple :

```powershell
java -jar .\maven-config-generator\target\archetype-config-generator-1.0.0.jar --configFile=.\examples\generation-h2.properties --outputDirectory=.\generated
```

## 9. Support Des Fichiers De Configuration

Les deux outils de generation supportent :

- `.properties`
- `.yml`
- `.yaml`

Limite voulue :

- le YAML est plat
- pas d'objets imbriques
- pas de listes

Cette limite simplifie la maintenance et reste adaptee aux parametres de l'archetype.

## 10. Build Unique Du Depot

Depuis la racine du depot :

```powershell
mvn -B clean install
```

Cette commande :

- construit l'agregateur racine
- construit le module `springboot-enterprise-archetype`
- construit le module `archetype-config-maven-plugin`
- construit le module `maven-config-generator`
- installe les trois artefacts dans le repository Maven local

Artefacts generes :

- `springboot-enterprise-archetype\target\springboot-enterprise-archetype-1.0.0.jar`
- `archetype-config-maven-plugin\target\archetype-config-maven-plugin-1.0.0.jar`
- `maven-config-generator\target\archetype-config-generator-1.0.0.jar`

## 11. Validation Recommandee

### Validation Du Build Multi-Modules

```powershell
mvn -B clean install
```

### Validation De La Generation Avec Le Plugin Maven

```powershell
mvn --% -B com.company.archetype:archetype-config-maven-plugin:1.0.0:generate -DconfigFile=.\examples\generation-h2.properties -DoutputDirectory=.\generated
```

### Validation De La Generation Avec Le Helper Jar

```powershell
java -jar .\maven-config-generator\target\archetype-config-generator-1.0.0.jar --configFile=.\examples\generation-h2.properties --outputDirectory=.\generated
```

### Validation D'Un Projet Genere

Depuis le projet genere :

```powershell
mvn -B test
```

## 12. Zones Sensibles A Modifier

Les zones les plus sensibles sont :

- `springboot-enterprise-archetype/src/main/resources/META-INF/maven/archetype-metadata.xml`
- `springboot-enterprise-archetype/src/main/resources/archetype-resources/pom.xml`
- `springboot-enterprise-archetype/src/main/resources/archetype-resources/src/main/resources/application.yml`
- `springboot-enterprise-archetype/src/main/resources/archetype-resources/src/main/java/config/SecurityConfig.java`
- `springboot-enterprise-archetype/src/main/resources/archetype-resources/src/main/java/rest/ApplicationVersionController.java`
- `archetype-config-maven-plugin/src/main/java/com/company/archetype/plugin/ArchetypeConfigGenerateMojo.java`
- `maven-config-generator/src/main/java/com/company/archetype/generator/ArchetypeConfigGenerator.java`

## 13. Points D'Attention

- le coeur fonctionnel reste dans `springboot-enterprise-archetype/src/main/resources/archetype-resources/`
- le plugin Maven et le helper jar sont deux facades de generation, pas le coeur du template
- les tests du projet genere restent bases sur H2 pour garantir un `mvn test` autonome
- le mode WebFlux conserve JPA, donc les appels bloquants sont delegues sur `Schedulers.boundedElastic()`

## 14. Lecture Recommandee Pour Un Mainteneur

Ordre conseille :

1. `pom.xml`
2. `springboot-enterprise-archetype/pom.xml`
3. `springboot-enterprise-archetype/src/main/resources/META-INF/maven/archetype-metadata.xml`
4. `springboot-enterprise-archetype/src/main/resources/archetype-resources/pom.xml`
5. `springboot-enterprise-archetype/src/main/resources/archetype-resources/src/main/resources/application.yml`
6. `archetype-config-maven-plugin/src/main/java/com/company/archetype/plugin/ArchetypeConfigGenerateMojo.java`
7. `maven-config-generator/src/main/java/com/company/archetype/generator/ArchetypeConfigGenerator.java`

## 15. Conclusion

Le depot est maintenant structure pour un usage simple et stable :

- un seul `mvn -B clean install` construit tout
- l'archetype vit dans un module dedie
- le plugin Maven et le helper jar sont construits dans le meme build
- la maintenance est plus simple car chaque responsabilite est isolee dans son module

