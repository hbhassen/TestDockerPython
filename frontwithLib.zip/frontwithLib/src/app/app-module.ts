import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { provideSmallibFront } from 'smallibfront';

import { App } from './app';

@NgModule({
  declarations: [
    App
  ],
  imports: [
    BrowserModule,
    HttpClientModule
  ],
  providers: [
    ...provideSmallibFront({
      requestMatcher: (request) => request.url.startsWith('http://localhost:8080/demo2/api/'),
      token: {
        responseHeaderName: 'X-Auth-Token',
        requestHeaderName: 'Authorization',
        requestHeaderPrefix: 'Bearer',
        storageKey: 'demo2front19.token',
        storageStrategy: 'memory'
      },
      saml: {
        enabled: true,
        expectedFormInputName: 'SAMLRequest',
        relayStateInputName: 'RelayState',
        overrideRelayStateWithCurrentUrl: true
      }
    })
  ],
  bootstrap: [App]
})
export class AppModule { }
