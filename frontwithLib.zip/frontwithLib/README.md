# demo2-front19

Frontend d'exemple Angular 19 consommant la librairie transverse `smallibfront`.

## Prerequis

- Node.js 20+
- npm 10+

## Installation

Depuis `examples/demo2-front19`:

```bash
npm install
```

La dependance locale `smallibfront` est referencee via:

```json
"smallibfront": "file:../smallibfront"
```

## Demarrage

```bash
npm start
```

Application disponible sur `http://localhost:4200/`.

## Build

```bash
npm run build
```

## Ou la librairie est branchee

La configuration et l'injection des intercepteurs sont centralisees dans:

- `src/app/app-module.ts`

Extrait:

```ts
...provideSmallibFront({
  requestMatcher: (request) => request.url.startsWith('http://localhost:8080/demo2/api/'),
  token: {
    responseHeaderName: 'X-Auth-Token',
    requestHeaderName: 'Authorization',
    requestHeaderPrefix: 'Bearer'
  },
  saml: {
    enabled: true,
    expectedFormInputName: 'SAMLRequest'
  }
})
```

## Documentation de la librairie

- README: `../smallibfront/README.md`
- Guide detaille: `../smallibfront/GUIDE-INTEGRATION.md`
