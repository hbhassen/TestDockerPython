# Guide développeur - Intégration WildFly 31+

Ce guide décrit l'intégration de `server-status` dans une application Jakarta EE déployée sur WildFly 31 ou une version plus récente compatible avec les APIs utilisées par la librairie.

## Prérequis

- Java 17 ou plus récent.
- Maven 3.9 ou plus récent.
- Une application packagée en WAR.
- Une configuration Jakarta REST active dans l'application.
- L'artefact `com.company.platform:server-status-wildfly:1.0.0-SNAPSHOT` disponible dans le dépôt Maven utilisé par l'application.

La librairie utilise les APIs `jakarta.*`, dont Jakarta REST 3.1. Les dépendances Jakarta fournies par WildFly doivent rester en scope `provided` lorsqu'elles sont déclarées dans l'application hôte.

En développement local, installez d'abord la librairie depuis la racine de ce dépôt :

```bash
cd <PROJECT_HOME>
mvn clean install
```

## Dépendance Maven

Ajoutez l'adaptateur WildFly dans le `pom.xml` du WAR :

```xml
<dependency>
    <groupId>com.company.platform</groupId>
    <artifactId>server-status-wildfly</artifactId>
    <version>1.0.0-SNAPSHOT</version>
</dependency>
```

Si l'application déclare explicitement Jakarta REST, gardez l'API fournie par le serveur :

```xml
<dependency>
    <groupId>jakarta.ws.rs</groupId>
    <artifactId>jakarta.ws.rs-api</artifactId>
    <scope>provided</scope>
</dependency>
```

## Activation Jakarta REST

L'application doit disposer d'une classe `Application` Jakarta REST. Exemple minimal :

```java
package com.company.platform.examples.serverstatus;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("/")
public class ExampleApplication extends Application {
}
```

L'adaptateur expose la ressource suivante :

```text
com.company.platform.serverstatus.wildfly.ServerStatusResource
```

Elle est annotée avec :

```text
@Path("/public/server-status")
```

Si l'application utilise `@ApplicationPath("/")`, les endpoints sont exposés sous `/public/server-status`. Si elle utilise par exemple `@ApplicationPath("/api")`, les endpoints sont exposés sous `/api/public/server-status`.

Le contexte du WAR peut aussi préfixer l'URL finale. Par exemple, avec un contexte `/my-app`, l'URL complète devient `/my-app/public/server-status/live` lorsque `@ApplicationPath("/")` est utilisé.

## Configuration par propriétés système

L'adaptateur WildFly lit sa configuration via `System.getProperty`.

| Propriété système | Défaut | Effet |
| --- | --- | --- |
| `server-status.application-name` | `unknown` | Nom affiché dans la réponse détaillée. |
| `server-status.details-enabled` | `false` | Active la réponse détaillée sur l'endpoint de statut. |
| `server-status.details.enabled` | `false` | Variante acceptée pour activer les détails. |
| `server-status.rate-limit.enabled` | `true` | Active la limitation de débit en mémoire. |
| `server-status.rate-limit.requests-per-minute` | `100` | Nombre de requêtes autorisées par minute et par adresse distante. |
| `server-status.cors.enabled` | `false` | Active la gestion CORS de la librairie. |
| `server-status.cors.allowed-origins` | liste vide | Liste CSV des origines autorisées exactes lorsque CORS est activé. |

Contrairement à l'adaptateur Spring Boot, l'adaptateur WildFly ne définit pas de propriété `server-status.enabled` ni `server-status.public-endpoint-enabled`.

Exemple avec options JVM :

```bash
-Dserver-status.application-name=my-wildfly-application
-Dserver-status.details-enabled=false
-Dserver-status.rate-limit.enabled=true
-Dserver-status.rate-limit.requests-per-minute=100
-Dserver-status.cors.enabled=false
-Dserver-status.cors.allowed-origins=https://example.com
```

Exemple via WildFly CLI :

```bash
<JBOSS_HOME>/bin/jboss-cli.sh --connect
/system-property=server-status.application-name:add(value=my-wildfly-application)
/system-property=server-status.details-enabled:add(value=false)
/system-property=server-status.rate-limit.enabled:add(value=true)
/system-property=server-status.rate-limit.requests-per-minute:add(value=100)
/system-property=server-status.cors.enabled:add(value=false)
reload
```

Sur Windows, utilisez `jboss-cli.bat` à la place de `jboss-cli.sh`.

## Endpoints exposés

| Méthode | Chemin avec `@ApplicationPath("/")` | Réponse |
| --- | --- | --- |
| `GET` | `/public/server-status/live` | Sonde de liveness. |
| `GET` | `/public/server-status/ready` | Sonde de readiness locale. |
| `GET` | `/public/server-status` | Statut minimal ou détaillé selon la configuration. |

Réponse minimale par défaut :

```json
{
  "status": "UP"
}
```

Réponse détaillée possible quand les détails sont activés :

```json
{
  "status": "UP",
  "application": "my-wildfly-application",
  "server": "WildFly",
  "javaVersion": "17.0.x",
  "uptimeSeconds": 123456,
  "timestamp": "2026-08-24T03:00:00Z"
}
```

## Packaging et déploiement

Depuis l'application hôte :

```bash
mvn clean package
```

Pour une application Jakarta REST sans `WEB-INF/web.xml`, vérifiez que le build WAR de l'application hôte accepte ce mode ou fournissez un `web.xml` conforme à sa politique de packaging. Sans cette configuration, le Maven WAR Plugin peut refuser d'assembler le WAR.

Déployez ensuite le WAR généré dans WildFly 31+ selon la procédure de l'application ou via la CLI WildFly :

```bash
<JBOSS_HOME>/bin/jboss-cli.sh --connect --command="deploy target/<APPLICATION>.war --force"
```

Pour vérifier la compilation de l'exemple fourni dans ce dépôt sans modifier son POM :

```bash
cd <PROJECT_HOME>
mvn clean install
cd examples/wildfly
mvn clean compile
```

Le dossier `examples/wildfly` illustre la dépendance Maven et la classe `Application` Jakarta REST minimale.

## Vérification HTTP

Adaptez le préfixe si l'application a un contexte WAR ou un `@ApplicationPath` différent :

```bash
curl -i http://localhost:8080/public/server-status/live
curl -i http://localhost:8080/public/server-status/ready
curl -i http://localhost:8080/public/server-status
```

Avec un contexte `/my-app` :

```bash
curl -i http://localhost:8080/my-app/public/server-status/live
curl -i http://localhost:8080/my-app/public/server-status/ready
curl -i http://localhost:8080/my-app/public/server-status
```

## Sécurité

La librairie ne configure pas la sécurité WildFly de l'application hôte. Les contraintes d'accès, rôles, politiques réseau, reverse proxies et règles de publication restent sous la responsabilité de l'application et de la plateforme.

Les endpoints n'acceptent pas d'entrée utilisateur fonctionnelle : pas de corps de requête, pas de paramètres requis, pas d'URL, pas de chemin de fichier, pas de fragment SQL, pas de commande et pas d'expression dynamique.

La réponse ne doit pas exposer de secrets, variables d'environnement, chemins système, nom d'utilisateur, adresse IP interne, classpath, URL de base de données ou stack trace.

## CORS

CORS est désactivé par défaut. Pour l'activer :

```bash
-Dserver-status.cors.enabled=true
-Dserver-status.cors.allowed-origins=https://example.com,https://admin.example.com
```

Seules les origines exactes listées sont reflétées. La librairie n'émet pas `Access-Control-Allow-Origin: *`.

## Limitation de débit

La limitation de débit par défaut est activée en mémoire :

```bash
-Dserver-status.rate-limit.enabled=true
-Dserver-status.rate-limit.requests-per-minute=100
```

Elle est calculée par adresse distante fournie par le conteneur. Elle ne fait pas confiance à `X-Forwarded-For` par défaut. Dans un cluster, chaque JVM possède son propre compteur.

## Kubernetes et OpenShift

Exemple avec un contexte racine :

```yaml
livenessProbe:
  httpGet:
    path: /public/server-status/live
    port: 8080
readinessProbe:
  httpGet:
    path: /public/server-status/ready
    port: 8080
```

Si le WAR est déployé sous un contexte applicatif, ajoutez ce contexte au chemin.

## Diagnostic rapide

| Symptôme | Vérification |
| --- | --- |
| Dépendance Maven introuvable | Publier l'artefact ou exécuter `mvn clean install` depuis la racine de la librairie. |
| Endpoint en `404` | Vérifier le contexte du WAR, `@ApplicationPath` et l'activation Jakarta REST. |
| Réponse `429` | Vérifier `server-status.rate-limit.requests-per-minute` ou désactiver temporairement `server-status.rate-limit.enabled`. |
| Pas d'en-tête CORS | Vérifier `server-status.cors.enabled=true` et la liste CSV `server-status.cors.allowed-origins`. |
| Pas de détails dans `/public/server-status` | Activer `server-status.details-enabled=true` ou `server-status.details.enabled=true`. |
| Détails accessibles publiquement | Protéger l'endpoint côté application hôte ou plateforme avant d'activer les détails. |
