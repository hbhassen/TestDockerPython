# server-status

`server-status` est une librairie Maven Java 17 qui expose des endpoints sécurisés d'état serveur pour :

- les applications Spring Boot 3.x ;
- les applications Jakarta EE / WildFly.

La librairie est volontairement réduite. L'état de santé de base est calculé uniquement à partir de l'état local de la JVM. Elle n'utilise pas SQL, LDAP, les entrées de fichiers, les URL externes, les commandes shell, les expressions dynamiques, les templates ou les données fournies par l'utilisateur dans la requête.

## Architecture

```text
server-status-core
       |
       +-----------------------+
       |                       |
       v                       v
server-status-spring-boot   server-status-wildfly
```

Modules :

- `server-status-core` : modèles, contrat de service, état local de la JVM, constantes d'en-têtes de sécurité, politique CORS et abstraction de limitation de débit.
- `server-status-spring-boot` : auto-configuration Spring Boot 3 et contrôleur REST.
- `server-status-wildfly` : ressource Jakarta REST pour WildFly.
- `server-status-integration-tests` : contrôles d'architecture et d'intégration.

Le module core ne dépend pas de Spring, Spring Boot, WildFly, Servlet, Jakarta REST, JDBC, JPA ou Hibernate.

## Artefacts Maven

```xml
<groupId>com.company.platform</groupId>
<artifactId>server-status-core</artifactId>
<version>1.0.0-SNAPSHOT</version>
```

```xml
<groupId>com.company.platform</groupId>
<artifactId>server-status-spring-boot</artifactId>
<version>1.0.0-SNAPSHOT</version>
```

```xml
<groupId>com.company.platform</groupId>
<artifactId>server-status-wildfly</artifactId>
<version>1.0.0-SNAPSHOT</version>
```

## Installation Spring Boot

Ajoutez l'adaptateur Spring Boot :

```xml
<dependency>
    <groupId>com.company.platform</groupId>
    <artifactId>server-status-spring-boot</artifactId>
    <version>1.0.0-SNAPSHOT</version>
</dependency>
```

Spring Boot découvre `ServerStatusAutoConfiguration` via :

```text
META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports
```

Aucun enregistrement manuel du contrôleur n'est nécessaire dans l'application hôte.

Guide détaillé : [Guide développeur - Intégration Spring Boot](docs/GUIDE_INTEGRATION_SPRING_BOOT.md).

## Installation WildFly

Ajoutez l'adaptateur WildFly dans le WAR :

```xml
<dependency>
    <groupId>com.company.platform</groupId>
    <artifactId>server-status-wildfly</artifactId>
    <version>1.0.0-SNAPSHOT</version>
</dependency>
```

L'adaptateur expose une ressource Jakarta REST basée sur les APIs `jakarta.*` :

```text
com.company.platform.serverstatus.wildfly.ServerStatusResource
```

Cible de compatibilité : runtimes compatibles Jakarta EE 10 / Jakarta REST 3.1, dont les applications déployées sur WildFly 31 et versions plus récentes lorsque leur pile Jakarta EE est compatible avec ces APIs.

Guide détaillé : [Guide développeur - Intégration WildFly 31+](docs/GUIDE_INTEGRATION_WILDFLY_31_PLUS.md).

## Configuration

Propriétés Spring Boot :

```properties
server-status.enabled=true
server-status.application-name=${spring.application.name:unknown}
server-status.public-endpoint-enabled=true
server-status.details-enabled=false
server-status.details.enabled=false
server-status.rate-limit.enabled=true
server-status.rate-limit.requests-per-minute=100
server-status.cors.enabled=false
server-status.cors.allowed-origins=https://example.com
```

Propriétés système WildFly :

```properties
server-status.application-name=unknown
server-status.details-enabled=false
server-status.details.enabled=false
server-status.rate-limit.enabled=true
server-status.rate-limit.requests-per-minute=100
server-status.cors.enabled=false
server-status.cors.allowed-origins=https://example.com
```

`details-enabled=false` est la valeur sécurisée par défaut. La réponse contient uniquement :

```json
{
  "status": "UP"
}
```

Lorsque les détails sont activés, l'endpoint de statut peut retourner :

```json
{
  "status": "UP",
  "application": "my-application",
  "server": "Spring Boot",
  "javaVersion": "17.0.x",
  "uptimeSeconds": 123456,
  "timestamp": "2026-08-24T03:00:00Z"
}
```

## Endpoints

| Méthode | Chemin | Rôle |
| --- | --- | --- |
| `GET` | `/public/server-status/live` | Sonde de liveness. Vérifie que le processus peut répondre. |
| `GET` | `/public/server-status/ready` | Sonde de readiness. Indique si l'application peut recevoir du trafic. |
| `GET` | `/public/server-status` | Statut minimal ou détaillé selon la configuration. |

Seule la méthode `GET` est supportée. `POST`, `PUT`, `DELETE` et `PATCH` retournent `405`.

## Liveness et readiness

La liveness est volontairement minimale. Elle doit rester suffisamment légère pour les sondes Kubernetes/OpenShift et ne doit pas dépendre d'une base de données, du réseau, de fichiers, de commandes shell, de LDAP ou de services externes.

La readiness représente la capacité de l'application hôte à recevoir du trafic. Cette librairie retourne un statut local, car elle ne possède pas les dépendances spécifiques de l'application hôte. Les applications qui nécessitent des contrôles de readiness plus profonds doivent les ajouter côté application hôte sans accepter d'entrée utilisateur.

## Exemples curl

```bash
curl -i http://localhost:8080/public/server-status/live
curl -i http://localhost:8080/public/server-status/ready
curl -i http://localhost:8080/public/server-status
```

## Modèle de sécurité

Les endpoints publics n'acceptent pas de corps de requête, paramètres de requête, URL, chemins de fichiers, fragments SQL, commandes, filtres LDAP, expressions ou templates.

L'implémentation ne retourne jamais :

- nom d'hôte ;
- adresse IP interne ;
- nom d'utilisateur ;
- mot de passe ;
- variables d'environnement ;
- classpath ;
- chemins système ;
- secrets ;
- tokens ;
- identifiants ;
- URL de base de données ;
- stack traces ;
- configuration interne.

Spring Security et la sécurité WildFly restent sous la responsabilité de l'application hôte. Cette librairie n'implémente pas de JWT personnalisé ni de magasin de secrets.

## Limitation de débit

Le core expose `RateLimiter`. L'implémentation par défaut est une limitation en mémoire sur une fenêtre fixe d'une minute.

Valeurs par défaut :

```properties
server-status.rate-limit.enabled=true
server-status.rate-limit.requests-per-minute=100
```

L'implémentation utilise l'adresse distante fournie par le conteneur. Elle ne fait pas confiance à `X-Forwarded-For` par défaut. Si un déploiement doit tenir compte d'un reverse proxy, cette frontière de confiance doit être configurée dans la plateforme ou le serveur hôte, pas en acceptant aveuglément les en-têtes client.

## CORS

CORS est désactivé par défaut :

```properties
server-status.cors.enabled=false
```

Quand CORS est activé, seules les origines explicitement autorisées sont reflétées :

```properties
server-status.cors.allowed-origins=https://example.com
```

La librairie n'émet pas `Access-Control-Allow-Origin: *`.

## En-têtes HTTP

Chaque réponse JSON produite par les adaptateurs inclut :

- `Content-Type: application/json`
- `X-Content-Type-Options: nosniff`
- `Cache-Control: no-store`
- `Referrer-Policy: no-referrer`
- `Permissions-Policy: geolocation=(), microphone=(), camera=()`

Ces en-têtes réduisent le content sniffing, la mise en cache des réponses de statut, la fuite de referrer et les accès inutiles aux fonctionnalités du navigateur.

## Kubernetes et OpenShift

Utilisez :

```yaml
livenessProbe:
  httpGet:
    path: /public/server-status/live
    port: 8080
readinessProbe:
  httpGet:
    path: /public/server-status/ready
    port: 8080
```

L'endpoint `/live` est volontairement léger :

1. Recevoir la requête.
2. Vérifier la méthode HTTP via le routage du framework.
3. Appliquer les protections HTTP.
4. Retourner l'état local de la JVM.
5. Émettre un petit corps JSON.

Il n'effectue pas de SQL, appels réseau, lectures de fichiers, exécution shell, évaluation d'expressions dynamiques ou rendu de templates.

## Tests

Exécutez :

```bash
mvn clean verify
```

La suite de tests couvre :

- le contrat du service de statut core ;
- l'implémentation de statut JVM ;
- les réponses du contrôleur Spring Boot ;
- les méthodes HTTP ;
- le type de contenu JSON ;
- les en-têtes de sécurité ;
- le comportement de la allowlist CORS ;
- la limitation de débit ;
- les payloads d'injection qui ne doivent pas atteindre la logique métier ;
- les réponses d'erreur minimales sans stack traces ;
- les frontières d'architecture du module core.

## Build Maven

Prérequis :

- Java 17 ou plus récent ;
- Maven 3.9 ou plus récent.

Commandes :

```bash
mvn clean verify
mvn dependency:tree
```

Le Maven Enforcer Plugin vérifie les versions de Java et Maven ainsi que la convergence des dépendances.

## Analyse des dépendances

Le projet inclut un profil OWASP Dependency-Check optionnel :

```bash
mvn -Pdependency-check verify
```

Cette analyse peut nécessiter un accès réseau aux flux de vulnérabilités. Configurez les clés API requises via des variables d'environnement ou des secrets CI, jamais dans Git. Définissez `NVD_API_KEY` lorsque l'API NVD exige un accès authentifié.

## Artifactory

Le POM parent définit des entrées `distributionManagement` alimentées par des variables d'environnement :

```text
ARTIFACTORY_RELEASE_URL
ARTIFACTORY_SNAPSHOT_URL
```

Les identifiants doivent être fournis via le `settings.xml` Maven, des variables d'environnement ou des secrets CI/CD :

```text
ARTIFACTORY_USER
ARTIFACTORY_TOKEN
```

Aucun nom d'utilisateur, mot de passe, token ou URL Artifactory n'est stocké dans le code source.

## Compatibilité

- Java : 17 minimum.
- Maven : 3.9 minimum.
- Spring Boot : 3.x.
- Jakarta REST : 3.1.
- WildFly : distributions compatibles Jakarta EE 10, notamment WildFly 31+ lorsque l'application cible cette pile.

## Limites

- Le contrôle de readiness de base est uniquement local.
- Le limiteur de débit en mémoire est propre à chaque instance JVM et n'est pas partagé entre les noeuds d'un cluster.
- Le statut détaillé est désactivé par défaut et doit être protégé par l'application hôte lorsqu'il est activé.
- Aucun contrôle de santé basé sur une base de données, LDAP, URL externe, commande système ou système de fichiers n'est inclus.

## Modèle de menace

Voir [SECURITY.md](SECURITY.md) et [docs/THREAT_MODEL.md](docs/THREAT_MODEL.md).

## Exemples et guides d'intégration

Exemples :

- [examples/spring-boot](examples/spring-boot)
- [examples/wildfly](examples/wildfly)

Guides développeur :

- [Guide développeur - Intégration Spring Boot](docs/GUIDE_INTEGRATION_SPRING_BOOT.md)
- [Guide développeur - Intégration WildFly 31+](docs/GUIDE_INTEGRATION_WILDFLY_31_PLUS.md)
