# Guide développeur - Intégration Spring Boot

Ce guide décrit l'intégration de `server-status` dans une application Spring Boot 3.x.

## Prérequis

- Java 17 ou plus récent.
- Maven 3.9 ou plus récent.
- Une application Spring Boot 3.x avec une pile web compatible Spring MVC.
- L'artefact `com.company.platform:server-status-spring-boot:1.0.0-SNAPSHOT` disponible dans le dépôt Maven utilisé par l'application.

En développement local, installez d'abord la librairie depuis la racine de ce dépôt :

```bash
cd <PROJECT_HOME>
mvn clean install
```

## Dépendance Maven

Ajoutez l'adaptateur Spring Boot dans le `pom.xml` de l'application hôte :

```xml
<dependency>
    <groupId>com.company.platform</groupId>
    <artifactId>server-status-spring-boot</artifactId>
    <version>1.0.0-SNAPSHOT</version>
</dependency>
```

L'adaptateur dépend du module `server-status-core`. Maven résout cette dépendance transitivement.

## Auto-configuration

Spring Boot charge automatiquement :

```text
com.company.platform.serverstatus.springboot.ServerStatusAutoConfiguration
```

Cette auto-configuration est déclarée dans :

```text
META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports
```

Quand `server-status.enabled=true` ou quand la propriété est absente, elle crée les beans suivants si l'application hôte ne fournit pas déjà un bean du même type :

- `ServerStatusService`
- `RateLimiter`
- `CorsPolicy`
- `ServerStatusController`
- `ServerStatusErrorHandler`

Le contrôleur public est créé quand `server-status.public-endpoint-enabled=true` ou quand cette propriété est absente.

## Configuration minimale

Exemple `application.yml` :

```yaml
spring:
  application:
    name: my-spring-application

server-status:
  enabled: true
  application-name: ${spring.application.name:unknown}
  public-endpoint-enabled: true
  details-enabled: false
  rate-limit:
    enabled: true
    requests-per-minute: 100
  cors:
    enabled: false
    allowed-origins:
      - https://example.com
```

## Propriétés disponibles

| Propriété | Défaut | Effet |
| --- | --- | --- |
| `server-status.enabled` | `true` | Active ou désactive l'auto-configuration. |
| `server-status.application-name` | `unknown` | Nom affiché dans la réponse détaillée. |
| `server-status.public-endpoint-enabled` | `true` | Expose ou masque le contrôleur `/public/server-status`. |
| `server-status.details-enabled` | `false` | Active la réponse détaillée sur l'endpoint de statut. |
| `server-status.details.enabled` | `false` | Variante imbriquée de l'activation des détails. |
| `server-status.rate-limit.enabled` | `true` | Active la limitation de débit en mémoire. |
| `server-status.rate-limit.requests-per-minute` | `100` | Nombre de requêtes autorisées par minute et par adresse distante. |
| `server-status.cors.enabled` | `false` | Active la gestion CORS de la librairie. |
| `server-status.cors.allowed-origins` | liste vide | Origines autorisées exactes lorsque CORS est activé. |

Les détails sont activés si `server-status.details-enabled=true` ou si `server-status.details.enabled=true`.

## Endpoints exposés

| Méthode | Chemin | Réponse |
| --- | --- | --- |
| `GET` | `/public/server-status/live` | Sonde de liveness. |
| `GET` | `/public/server-status/ready` | Sonde de readiness locale. |
| `GET` | `/public/server-status` | Statut minimal ou détaillé selon la configuration. |

Les méthodes `POST`, `PUT`, `DELETE` et `PATCH` retournent `405`.

Réponse minimale par défaut :

```json
{
  "status": "UP"
}
```

Réponse détaillée possible quand les détails sont activés :

```json
{
  "status": "UP",
  "application": "my-spring-application",
  "server": "Spring Boot",
  "javaVersion": "17.0.x",
  "uptimeSeconds": 123456,
  "timestamp": "2026-08-24T03:00:00Z"
}
```

## Vérification locale

Depuis l'application hôte :

```bash
mvn clean verify
mvn spring-boot:run
```

Dans un autre terminal :

```bash
curl -i http://localhost:8080/public/server-status/live
curl -i http://localhost:8080/public/server-status/ready
curl -i http://localhost:8080/public/server-status
```

Pour tester l'exemple fourni dans ce dépôt :

```bash
cd <PROJECT_HOME>
mvn clean install
cd examples/spring-boot
mvn clean verify
mvn spring-boot:run
```

## Sécurité

La librairie ne configure pas Spring Security. Si l'application hôte utilise Spring Security, les règles d'accès à `/public/server-status/**` doivent être définies dans l'application hôte.

Les endpoints n'acceptent pas d'entrée utilisateur fonctionnelle : pas de corps de requête, pas de paramètres requis, pas d'URL, pas de chemin de fichier, pas de fragment SQL, pas de commande et pas d'expression dynamique.

La réponse ne doit pas exposer de secrets, variables d'environnement, chemins système, nom d'utilisateur, adresse IP interne, classpath, URL de base de données ou stack trace.

## Personnalisation contrôlée

L'application hôte peut fournir ses propres beans pour remplacer les implémentations par défaut :

- `ServerStatusService` pour contrôler la logique de statut.
- `RateLimiter` pour remplacer la limitation de débit en mémoire.
- `CorsPolicy` pour contrôler la politique CORS.

La readiness fournie par défaut reste locale. Si l'application doit vérifier une base de données, un broker ou un service externe, ces contrôles doivent être ajoutés côté application hôte sans accepter d'entrée utilisateur non maîtrisée.

## Kubernetes et OpenShift

Exemple de sondes :

```yaml
livenessProbe:
  httpGet:
    path: /public/server-status/live
    port: 8080
readinessProbe:
  httpGet:
    path: /public/server-status/ready
    port: 8080
```

Si l'application définit un `server.servlet.context-path`, ajoutez ce préfixe aux chemins des sondes.

## Diagnostic rapide

| Symptôme | Vérification |
| --- | --- |
| Dépendance Maven introuvable | Publier l'artefact ou exécuter `mvn clean install` depuis la racine de la librairie. |
| Endpoint en `404` | Vérifier `server-status.enabled`, `server-status.public-endpoint-enabled`, le contexte web et le `context-path`. |
| Réponse `429` | Vérifier `server-status.rate-limit.requests-per-minute` ou désactiver temporairement `server-status.rate-limit.enabled`. |
| Pas d'en-tête CORS | Vérifier que `server-status.cors.enabled=true` et que l'origine exacte est listée. |
| Pas de détails dans `/public/server-status` | Activer `server-status.details-enabled=true` ou `server-status.details.enabled=true`. |
