import java.nio.charset.StandardCharsets
import java.nio.file.DirectoryStream
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.Comparator

def projectProperties = new Properties()
if (request.getProperties() != null) {
    projectProperties.putAll(request.getProperties())
}

String repositoryUrl = projectProperties.getProperty("gitRepositoryUrl", "").trim()
String branch = projectProperties.getProperty("gitBranch", "").trim()
String gitToken = projectProperties.getProperty("gitToken", "").trim()

if ("__git_disabled__".equals(repositoryUrl)) {
    repositoryUrl = ""
}
if ("__git_disabled__".equals(branch)) {
    branch = ""
}
if ("__git_token_disabled__".equals(gitToken)) {
    gitToken = ""
}

if (repositoryUrl.isEmpty() && branch.isEmpty()) {
    return
}

if (repositoryUrl.isEmpty() || branch.isEmpty()) {
    throw new IllegalStateException(
            "Les parametres Git 'gitRepositoryUrl' et 'gitBranch' doivent etre renseignes ensemble."
    )
}

String artifactIdValue = request.getArtifactId()
if (artifactIdValue == null || artifactIdValue.isBlank()) {
    artifactIdValue = projectProperties.getProperty("artifactId", "").trim()
}

Path generatedProjectDirectory = Paths.get(request.getOutputDirectory()).resolve(artifactIdValue).normalize()
if (!Files.isDirectory(generatedProjectDirectory)) {
    throw new IllegalStateException("Le repertoire du projet genere est introuvable : " + generatedProjectDirectory)
}

Path gitExecutable = findGitExecutableOnPath()
if (gitExecutable == null) {
    throw new IllegalStateException(
            "Executable Git introuvable dans le PATH. Installez Git ou retirez les parametres Git."
    )
}

println "Publication Git activee vers '${repositoryUrl}' sur la branche '${branch}'."

Path tempRoot = Files.createTempDirectory("generated-project-git-")
Path checkoutDirectory = tempRoot.resolve("checkout")

try {
    requireSuccess(
            executeCommand([gitExecutable.toString(), "clone", repositoryUrl, checkoutDirectory.toString()], tempRoot),
            "cloner le depot Git"
    )

    if (remoteBranchExists(gitExecutable, repositoryUrl, branch, tempRoot)) {
        requireSuccess(
                executeCommand(
                        [
                                gitExecutable.toString(),
                                "-C",
                                checkoutDirectory.toString(),
                                "checkout",
                                "-B",
                                branch,
                                "origin/" + branch
                        ],
                        tempRoot
                ),
                "selectionner la branche Git cible"
        )
    } else {
        requireSuccess(
                executeCommand(
                        [
                                gitExecutable.toString(),
                                "-C",
                                checkoutDirectory.toString(),
                                "checkout",
                                "--orphan",
                                branch
                        ],
                        tempRoot
                ),
                "creer la branche Git cible"
        )
    }

    deleteDirectoryContents(checkoutDirectory)
    copyDirectoryContents(generatedProjectDirectory, checkoutDirectory)

    requireSuccess(
            executeCommand(
                    [gitExecutable.toString(), "-C", checkoutDirectory.toString(), "add", "--all"],
                    tempRoot
            ),
            "ajouter les fichiers au commit Git"
    )

    if (!hasPendingChanges(gitExecutable, checkoutDirectory, tempRoot)) {
        println "Aucun changement Git a publier sur la branche '${branch}'."
        return
    }

    ensureGitCommitIdentity(gitExecutable, checkoutDirectory, tempRoot, gitToken)

    requireSuccess(
            executeCommand(
                    [
                            gitExecutable.toString(),
                            "-C",
                            checkoutDirectory.toString(),
                            "commit",
                            "-m",
                            buildCommitMessage(projectProperties, artifactIdValue)
                    ],
                    tempRoot
            ),
            "creer le commit Git"
    )

    requireSuccess(
            executeCommand(
                    [
                            gitExecutable.toString(),
                            "-C",
                            checkoutDirectory.toString(),
                            "push",
                            "--set-upstream",
                            "origin",
                            branch
                    ],
                    tempRoot
            ),
            "publier la branche Git"
    )

    println "Projet genere publie sur la branche '${branch}'."
} finally {
    try {
        deleteRecursively(tempRoot)
    } catch (IOException ignored) {
    }
}

Path findGitExecutableOnPath() {
    String pathVariable = System.getenv("PATH")
    if (pathVariable == null || pathVariable.isBlank()) {
        return null
    }

    boolean windows = System.getProperty("os.name", "").toLowerCase().contains("win")
    List<String> executableNames = windows
            ? ["git.exe", "git.cmd", "git.bat", "git"]
            : ["git"]

    for (String pathEntry : pathVariable.split(java.io.File.pathSeparator)) {
        if (pathEntry == null || pathEntry.isBlank()) {
            continue
        }

        Path directory = Paths.get(pathEntry.trim())
        for (String executableName : executableNames) {
            Path candidate = directory.resolve(executableName)
            if (Files.isRegularFile(candidate)) {
                return candidate.normalize()
            }
        }
    }
    return null
}

boolean remoteBranchExists(Path gitExecutable, String repositoryUrl, String branch, Path workingDirectory) {
    CommandResult result = executeCommand(
            [
                    gitExecutable.toString(),
                    "ls-remote",
                    "--exit-code",
                    "--heads",
                    repositoryUrl,
                    branch
            ],
            workingDirectory
    )

    if (result.exitCode == 0) {
        return true
    }
    if (result.exitCode == 2) {
        return false
    }

    throw new IllegalStateException(
            "Impossible de verifier la branche Git distante '${branch}'.\n${result.output}"
    )
}

boolean hasPendingChanges(Path gitExecutable, Path checkoutDirectory, Path workingDirectory) {
    CommandResult result = executeCommand(
            [gitExecutable.toString(), "-C", checkoutDirectory.toString(), "status", "--short"],
            workingDirectory
    )
    requireSuccess(result, "verifier l etat Git")
    return !result.output.isBlank()
}

void ensureGitCommitIdentity(Path gitExecutable, Path checkoutDirectory, Path workingDirectory, String gitToken) {
    if (hasCommitIdentity(gitExecutable, checkoutDirectory, workingDirectory)) {
        return
    }

    if (gitToken == null || gitToken.isBlank()) {
        throw new IllegalStateException(
                "Configuration Git utilisateur introuvable pour creer le commit. " +
                        "Configurez 'user.name' et 'user.email' ou fournissez le parametre 'gitToken'."
        )
    }

    GitIdentity fallbackIdentity = buildFallbackGitIdentity(gitToken)

    requireSuccess(
            executeCommand(
                    [
                            gitExecutable.toString(),
                            "-C",
                            checkoutDirectory.toString(),
                            "config",
                            "user.name",
                            fallbackIdentity.name
                    ],
                    workingDirectory
            ),
            "configurer l identite Git locale (user.name)"
    )
    requireSuccess(
            executeCommand(
                    [
                            gitExecutable.toString(),
                            "-C",
                            checkoutDirectory.toString(),
                            "config",
                            "user.email",
                            fallbackIdentity.email
                    ],
                    workingDirectory
            ),
            "configurer l identite Git locale (user.email)"
    )

    println "Configuration Git utilisateur introuvable. Utilisation d une identite technique locale pour le commit."
}

boolean hasCommitIdentity(Path gitExecutable, Path checkoutDirectory, Path workingDirectory) {
    CommandResult authorIdentity = executeCommand(
            [gitExecutable.toString(), "-C", checkoutDirectory.toString(), "var", "GIT_AUTHOR_IDENT"],
            workingDirectory
    )
    if (authorIdentity.exitCode != 0) {
        return false
    }

    CommandResult committerIdentity = executeCommand(
            [gitExecutable.toString(), "-C", checkoutDirectory.toString(), "var", "GIT_COMMITTER_IDENT"],
            workingDirectory
    )
    return committerIdentity.exitCode == 0
}

String buildCommitMessage(Properties properties, String artifactIdValue) {
    String version = properties.getProperty("version", "").trim()
    if (version.isEmpty()) {
        return "Generate ${artifactIdValue} from archetype"
    }
    return "Generate ${artifactIdValue} ${version} from archetype"
}

GitIdentity buildFallbackGitIdentity(String gitToken) {
    String tokenFingerprint = fingerprintGitToken(gitToken)
    return new GitIdentity(
            "archetype-generator",
            "archetype-generator+${tokenFingerprint}@archetype.local"
    )
}

String fingerprintGitToken(String gitToken) {
    byte[] digest = MessageDigest.getInstance("SHA-256").digest(gitToken.getBytes(StandardCharsets.UTF_8))
    StringBuilder hexBuilder = new StringBuilder(digest.length * 2)
    for (byte currentByte : digest) {
        hexBuilder.append(String.format("%02x", currentByte & 0xff))
    }
    return hexBuilder.substring(0, 12)
}

void deleteDirectoryContents(Path directory) {
    DirectoryStream<Path> entries = Files.newDirectoryStream(directory)
    try {
        for (Path entry : entries) {
            if (".git".equals(entry.getFileName().toString())) {
                continue
            }
            deleteRecursively(entry)
        }
    } finally {
        entries.close()
    }
}

void copyDirectoryContents(Path sourceDirectory, Path targetDirectory) {
    Files.walk(sourceDirectory).withCloseable { stream ->
        List<Path> paths = stream.toList()
        for (Path sourcePath : paths) {
            Path relativePath = sourceDirectory.relativize(sourcePath)
            if (relativePath.toString().isEmpty() || isNestedGitMetadata(relativePath)) {
                continue
            }

            Path targetPath = targetDirectory.resolve(relativePath.toString())
            if (Files.isDirectory(sourcePath)) {
                Files.createDirectories(targetPath)
            } else {
                Path parentDirectory = targetPath.getParent()
                if (parentDirectory != null) {
                    Files.createDirectories(parentDirectory)
                }
                Files.copy(sourcePath, targetPath, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES)
            }
        }
    }
}

boolean isNestedGitMetadata(Path relativePath) {
    if (relativePath.getNameCount() == 0) {
        return false
    }
    return ".git".equals(relativePath.getName(0).toString())
}

void deleteRecursively(Path path) {
    if (path == null || Files.notExists(path)) {
        return
    }

    IOException lastException = null
    for (int attempt = 1; attempt <= 5; attempt++) {
        try {
            Files.walk(path).withCloseable { stream ->
                List<Path> paths = stream.sorted(Comparator.reverseOrder()).toList()
                for (Path currentPath : paths) {
                    Files.deleteIfExists(currentPath)
                }
            }
            return
        } catch (IOException exception) {
            lastException = exception
            if (attempt == 5) {
                break
            }
            try {
                Thread.sleep(200L)
            } catch (InterruptedException interruptedException) {
                Thread.currentThread().interrupt()
                throw new IOException(
                        "Interruption pendant le nettoyage du repertoire temporaire Git.",
                        interruptedException
                )
            }
        }
    }

    throw lastException
}

CommandResult executeCommand(List<String> command, Path workingDirectory) {
    ProcessBuilder processBuilder = new ProcessBuilder(command)
    processBuilder.directory(workingDirectory.toFile())
    processBuilder.redirectErrorStream(true)

    Process process = processBuilder.start()
    byte[] outputBytes
    process.getInputStream().withCloseable { input ->
        outputBytes = input.readAllBytes()
    }
    int exitCode = process.waitFor()
    String output = new String(outputBytes, StandardCharsets.UTF_8).trim()
    return new CommandResult(exitCode, output)
}

void requireSuccess(CommandResult result, String action) {
    if (result.exitCode != 0) {
        String details = result.output.isBlank() ? "(aucune sortie)" : result.output
        throw new IllegalStateException("Impossible de ${action}.\n${details}")
    }
}

class CommandResult {
    final int exitCode
    final String output

    CommandResult(int exitCode, String output) {
        this.exitCode = exitCode
        this.output = output
    }
}

class GitIdentity {
    final String name
    final String email

    GitIdentity(String name, String email) {
        this.name = name
        this.email = email
    }
}
