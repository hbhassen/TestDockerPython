# ${artifactId}

Application Spring Boot generee depuis l archetype `springboot-enterprise-archetype`.

**1. Objectif Du Projet**

Ce projet fournit une base de depart structuree pour une application entreprise simple avec :

- une API REST
- une couche service
- une couche data basee sur Spring Data JPA
- une configuration Spring centralisee
- un exemple de pipeline Jenkins
- un `Dockerfile` de build et de runtime

Identite du projet genere :

- `groupId` : `${groupId}`
- `artifactId` : `${artifactId}`
- `version` : `${version}`
- `package racine` : `${package}`
- `pile web` : `${webStack}`
- `base de donnees` : `${databaseType}`
- `nom de base` : `${databaseName}`
- `schema` : `${databaseSchema}`

**2. Vue D Ensemble De L Architecture**

Le projet suit le decoupage suivant :

- `controller/rest` : recoit les requetes HTTP et retourne les reponses
- `service` : porte la logique d orchestration applicative
- `repository/data` : accede a la base de donnees
- `config` : centralise la configuration technique Spring
- `domaine` : contient les DTO et entites

Flux recommande :

`Controller -> Service -> Repository -> Base de donnees`

**3. Structure Du Projet**

Fichiers et dossiers principaux :

```text
.
|-- Dockerfile
|-- Jenkinsfile
|-- pom.xml
|-- src
|   |-- main
|   |   |-- java
|   |   |   `-- ${packageInPathFormat}
|   |   |       |-- Application.java
|   |   |       |-- config
|   |   |       |-- domaine
|   |   |       |-- repositories
|   |   |       |-- rest
|   |   |       `-- services
|   |   `-- resources
|   |       |-- application.yml
|   |       `-- schema.sql
|   `-- test
|       |-- java
|       `-- resources
```

**4. Explication Des Couches Applicatives**

**4.1 Couche Controller**

Chemin :

- `src/main/java/${packageInPathFormat}/rest/`

Fichier genere :

- `ApplicationVersionController.java`

Responsabilite :

- exposer les endpoints HTTP
- convertir une demande HTTP en appel de service
- laisser la logique metier hors du controller

Dans ce projet, le controller expose :

- `GET /api/application/version`

Regle a garder :

- pas de logique metier lourde dans cette couche
- pas d acces direct a la base depuis un controller
- le controller appelle toujours un service

#if($webStack == "webmvc")
Specificite `${webStack}` :

- le controller retourne des `ResponseEntity`
- l execution est basee sur la pile servlet Spring MVC
#end
#if($webStack == "webflux")
Specificite `${webStack}` :

- le controller retourne des `Mono`
- JPA restant bloquant, l appel service est delegue sur `Schedulers.boundedElastic()`
#end

**4.2 Couche Service**

Chemin :

- `src/main/java/${packageInPathFormat}/services/`

Fichiers generes :

- `ApplicationInfoService.java`
- `ApplicationInfoServiceImpl.java`

Responsabilite :

- orchestrer les traitements applicatifs
- appeler un ou plusieurs repositories
- transformer les entites en DTO
- definir les frontieres metier de l application

Regle a garder :

- la couche service ne gere pas directement HTTP
- la couche service ne depend pas de Swagger
- la couche service porte la logique metier et les validations applicatives

**4.3 Couche Data / Repository**

Chemin :

- `src/main/java/${packageInPathFormat}/repositories/`

Fichier genere :

- `ApplicationMetadataRepository.java`

Responsabilite :

- lire et ecrire les donnees en base
- declarer les methodes Spring Data JPA
- contenir les requetes derivees, JPQL ou natives si necessaire

Regle a garder :

- pas de logique HTTP
- pas d orchestration metier complexe
- garder ici uniquement la logique d acces aux donnees

**4.4 Couche Domaine**

Chemins :

- `src/main/java/${packageInPathFormat}/domaine/entities/`
- `src/main/java/${packageInPathFormat}/domaine/dto/`

Fichiers generes :

- `ApplicationMetadataEntity.java`
- `ApplicationVersionResponse.java`

Responsabilite :

- `entities` : modeliser les objets persistants JPA
- `dto` : modeliser les objets echanges avec l exterieur

Bonne pratique :

- ne retournez pas directement vos entites JPA dans les controllers
- passez par des DTO quand l API commence a evoluer

**4.5 Couche Configuration**

Chemin :

- `src/main/java/${packageInPathFormat}/config/`

Fichiers generes :

- `ApplicationMetadataInitializer.java`
- `ApplicationMetadataProperties.java`
- `OpenApiConfig.java`
- `SecurityConfig.java`

Responsabilite :

- configurer la securite
- configurer OpenAPI
- declarer les proprietes applicatives
- initialiser les donnees techniques de depart

Regle a garder :

- les classes de configuration restent techniques
- elles ne remplacent pas la couche service

**5. Explication De `application.yml`**

Chemin :

- `src/main/resources/application.yml`

Ce fichier centralise la configuration runtime du service.

Sections principales :

**`server`**

- configure le port HTTP du service
- valeur par defaut : `8080`

**`spring.application`**

- definit le nom logique de l application
- reutilise dans les logs et l observabilite

**`spring.main`**

- definit le type d application web

#if($webStack == "webmvc")
Pour `${webStack}` :

- `web-application-type: servlet`
#end
#if($webStack == "webflux")
Pour `${webStack}` :

- `web-application-type: reactive`
#end

**`spring.datasource`**

- configure la connexion a la base

#if($databaseType == "h2")
Dans ce projet genere :

- la datasource pointe vers une base H2 en memoire
- ce choix est adapte au developpement local rapide
#end
#if($databaseType == "postgresql")
Dans ce projet genere :

- la datasource pointe vers PostgreSQL
- l URL est composee a partir de `databaseHost`, `databasePort`, `databaseName` et `databaseSchema`
- les secrets devront etre externalises en environnement reel
#end

**`spring.jpa`**

- active les reglages Hibernate et JPA
- `ddl-auto: update` facilite le demarrage local
- `open-in-view: false` garde des frontieres de transaction explicites

**`spring.sql.init`**

- execute `schema.sql` au demarrage
- permet de creer le schema avant l execution de JPA

**`management`**

- expose les endpoints Actuator minimaux
- par defaut : `health` et `info`

**`info.app`**

- fournit les metadonnees exposees par Actuator `info`

**`application.metadata`**

- contient les metadonnees lues par le endpoint d exemple
- cette section est reliee a `ApplicationMetadataProperties`

**`springdoc`**

- active OpenAPI
- documentation JSON : `/v3/api-docs`
- interface Swagger UI : `/swagger-ui.html`

**6. Explication Du `Dockerfile`**

Le `Dockerfile` genere est un build multi-stage :

**Etape 1 : builder**

- image utilisee : `maven:3.9.11-eclipse-temurin-21`
- copie `pom.xml` et `src`
- lance `mvn -B clean package -DskipTests`

But :

- construire le jar dans un environnement Maven complet

**Etape 2 : runtime**

- image utilisee : `eclipse-temurin:21-jre`
- copie le jar construit depuis l etape builder
- expose le port `8080`
- lance `java -jar /app/app.jar`

But :

- garder une image finale plus legere
- ne pas embarquer Maven dans l image de runtime

**7. Explication Du `Jenkinsfile`**

Le `Jenkinsfile` fournit un pipeline simple avec les etapes suivantes :

**`Checkout`**

- recupere le code depuis le SCM Jenkins

**`Build`**

- lance `mvn -B clean compile`

**`Test`**

- lance `mvn -B test`

**`Package`**

- lance `mvn -B package -DskipTests`

**`Docker build`**

- construit une image Docker taggee `${artifactId}:latest`

Le pipeline gere les environnements Unix et Windows via `sh` ou `bat`.

**8. Lancer L Application**

**En local avec Maven**

Depuis la racine du projet genere :

```powershell
mvn -B spring-boot:run
```

**Lancer les tests**

```powershell
mvn -B test
```

**Construire le jar**

```powershell
mvn -B clean package
```

**Construire l image Docker**

```powershell
docker build -t ${artifactId}:latest .
```

**Lancer l image Docker**

```powershell
docker run --rm -p 8080:8080 ${artifactId}:latest
```

**URLs utiles**

- API exemple : `http://localhost:8080/api/application/version`
- Swagger UI : `http://localhost:8080/swagger-ui.html`
- Health : `http://localhost:8080/actuator/health`

**9. Comment Ajouter Un Fichier Dans Chaque Couche**

**Ajouter un controller**

Ajoutez un fichier dans :

- `src/main/java/${packageInPathFormat}/rest/`

Exemple :

- `CustomerController.java`

Regle :

- un controller appelle un service, pas un repository directement

**Ajouter un service**

Ajoutez vos fichiers dans :

- `src/main/java/${packageInPathFormat}/services/`

Exemple :

- `CustomerService.java`
- `CustomerServiceImpl.java`

Regle :

- le service porte l orchestration metier

**Ajouter un repository**

Ajoutez un fichier dans :

- `src/main/java/${packageInPathFormat}/repositories/`

Exemple :

- `CustomerRepository.java`

Regle :

- etendez `JpaRepository` ou un repository Spring Data approprie

**Ajouter une entite**

Ajoutez un fichier dans :

- `src/main/java/${packageInPathFormat}/domaine/entities/`

Exemple :

- `CustomerEntity.java`

Regle :

- mappez la table, les colonnes et les relations ici

**Ajouter un DTO**

Ajoutez un fichier dans :

- `src/main/java/${packageInPathFormat}/domaine/dto/`

Exemple :

- `CustomerResponse.java`
- `CreateCustomerRequest.java`

Regle :

- utilisez les DTO pour l entree et la sortie de l API

**Ajouter une configuration technique**

Ajoutez un fichier dans :

- `src/main/java/${packageInPathFormat}/config/`

Exemple :

- `CustomerProperties.java`
- `CustomerBatchConfig.java`

Regle :

- placez ici les `@Configuration`, `@ConfigurationProperties` et beans techniques

**Ajouter une ressource de configuration**

Ajoutez ou modifiez les fichiers dans :

- `src/main/resources/`

Exemple :

- `application.yml`
- `schema.sql`

Regle :

- gardez les proprietes techniques dans `application.yml`
- si vous ajoutez de nouvelles proprietes, mappez-les vers une classe de config dediee

**10. Exemple D Extension Complete**

Pour ajouter un nouveau cas d usage `Customer` :

1. creez `CustomerEntity` dans `domaine/entities`
2. creez `CustomerRepository` dans `repositories`
3. creez `CustomerService` et `CustomerServiceImpl` dans `services`
4. creez `CustomerResponse` et vos DTO d entree dans `domaine/dto`
5. creez `CustomerController` dans `rest`
6. ajoutez les proprietes necessaires dans `application.yml`
7. ajoutez les tests associes dans `src/test/java`

**11. Recommandations De Maintien**

- gardez la logique metier dans les services
- gardez l acces base dans les repositories
- gardez les controllers fins
- gardez les classes de configuration purement techniques
- externalisez les secrets de base de donnees pour les environnements reels

**12. Resume**

Le projet genere est volontairement simple mais deja structure pour evoluer.

Point d entree principal :

- `Application.java`

Fichier de configuration central :

- `src/main/resources/application.yml`

Points de depart pour developper :

- `rest/` pour exposer l API
- `services/` pour la logique applicative
- `repositories/` pour la persistence
- `config/` pour la configuration technique
