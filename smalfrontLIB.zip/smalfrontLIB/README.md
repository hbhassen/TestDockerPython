# smallibfront

`smallibfront` est une librairie Angular transverse qui centralise:

- la gestion du token d'authentification SMAL,
- l'ajout du token dans les requetes API,
- l'extraction du token depuis les reponses backend,
- l'interception des reponses HTML SAML et l'auto-submit de formulaire.

La librairie est concue pour etre configurable, evolutive et reutilisable dans plusieurs frontends.

## Fonctionnalites

- Intercepteur `AuthToken`: ajoute l'en-tete `Authorization` (ou autre configurable).
- Intercepteur `SamlResponse`: gere les reponses texte/HTML recues sur des appels JSON.
- Detection de formulaire SAML et soumission automatique cote navigateur.
- Stockage du token en `memory`, `sessionStorage`, `localStorage` ou stockage custom.
- Hooks d'extension (`onTokenUpdated`, `onSamlAutoSubmit`).
- Filtrage des requetes via `requestMatcher` ou `requestUrlIncludes`.

## Installation (dependance locale)

Depuis un projet Angular consommateur:

```bash
npm install ../smallibfront
```

Ou dans `package.json`:

```json
{
  "dependencies": {
    "smallibfront": "file:../smallibfront"
  }
}
```

## Build de la librairie

Depuis `examples/smallibfront`:

```bash
npm install
npm run build
```

## Usage rapide

```ts
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { provideSmallibFront } from 'smallibfront';

@NgModule({
  imports: [BrowserModule, HttpClientModule],
  providers: [
    ...provideSmallibFront({
      requestUrlIncludes: ['/api/'],
      token: {
        responseHeaderName: 'X-Auth-Token',
        requestHeaderName: 'Authorization',
        requestHeaderPrefix: 'Bearer',
        storageStrategy: 'memory'
      },
      saml: {
        enabled: true,
        expectedFormInputName: 'SAMLRequest',
        relayStateInputName: 'RelayState',
        overrideRelayStateWithCurrentUrl: true
      }
    })
  ]
})
export class AppModule {}
```

## API principale

- `provideSmallibFront(config?: SmallibFrontConfigInput): Provider[]`
- `createSmallibFrontConfig(input?: SmallibFrontConfigInput): SmallibFrontConfig`

Consulter [GUIDE-INTEGRATION.md](./GUIDE-INTEGRATION.md) pour le detail complet.
