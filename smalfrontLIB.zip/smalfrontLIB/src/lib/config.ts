import type { HttpRequest, HttpResponse } from '@angular/common/http';

export type SmallibRequestMatcher = (request: HttpRequest<unknown>) => boolean;
export type SmallibTokenExtractor = (response: HttpResponse<unknown>) => string | null;
export type SmallibTokenAutoUpdateHook = (token: string | null) => void;
export type SmallibTokenStorageStrategy = 'memory' | 'sessionStorage' | 'localStorage';

export interface SmallibTokenStorage {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem(key: string): void;
}

export interface SmallibTokenConfig {
  responseHeaderName: string;
  requestHeaderName: string;
  requestHeaderPrefix: string;
  storageKey: string;
  storageStrategy: SmallibTokenStorageStrategy;
  customStorage?: SmallibTokenStorage;
  tokenExtractor?: SmallibTokenExtractor;
}

export interface SmallibSamlAutoSubmitDetails {
  action: string | null;
  method: string;
  inputCount: number;
}

export type SmallibSamlAutoSubmitHook = (details: SmallibSamlAutoSubmitDetails) => void;

export interface SmallibSamlConfig {
  enabled: boolean;
  expectedFormInputName: string;
  relayStateInputName: string;
  overrideRelayStateWithCurrentUrl: boolean;
}

export interface SmallibFrontConfig {
  enabled: boolean;
  requestMatcher: SmallibRequestMatcher;
  requestUrlIncludes: string[];
  token: SmallibTokenConfig;
  saml: SmallibSamlConfig;
  onTokenUpdated?: SmallibTokenAutoUpdateHook;
  onSamlAutoSubmit?: SmallibSamlAutoSubmitHook;
}

export interface SmallibFrontConfigInput {
  enabled?: boolean;
  requestMatcher?: SmallibRequestMatcher;
  requestUrlIncludes?: string[];
  token?: Partial<SmallibTokenConfig>;
  saml?: Partial<SmallibSamlConfig>;
  onTokenUpdated?: SmallibTokenAutoUpdateHook;
  onSamlAutoSubmit?: SmallibSamlAutoSubmitHook;
}

const DEFAULT_REQUEST_URL_INCLUDES = ['/api/'];

/**
 * Construit une configuration finale et complete a partir d'options partielles.
 * Cette fonction centralise les valeurs par defaut pour faciliter l'evolution de la librairie.
 */
export function createSmallibFrontConfig(input: SmallibFrontConfigInput = {}): SmallibFrontConfig {
  const requestUrlIncludes = normalizeRequestUrlIncludes(input.requestUrlIncludes);
  const requestMatcher = input.requestMatcher ?? createDefaultRequestMatcher(requestUrlIncludes);

  return {
    enabled: input.enabled ?? true,
    requestMatcher,
    requestUrlIncludes,
    token: {
      responseHeaderName: input.token?.responseHeaderName ?? 'X-Auth-Token',
      requestHeaderName: input.token?.requestHeaderName ?? 'Authorization',
      requestHeaderPrefix: input.token?.requestHeaderPrefix ?? 'Bearer',
      storageKey: input.token?.storageKey ?? 'smallib.auth.token',
      storageStrategy: input.token?.storageStrategy ?? 'memory',
      customStorage: input.token?.customStorage,
      tokenExtractor: input.token?.tokenExtractor
    },
    saml: {
      enabled: input.saml?.enabled ?? true,
      expectedFormInputName: input.saml?.expectedFormInputName ?? 'SAMLRequest',
      relayStateInputName: input.saml?.relayStateInputName ?? 'RelayState',
      overrideRelayStateWithCurrentUrl: input.saml?.overrideRelayStateWithCurrentUrl ?? true
    },
    onTokenUpdated: input.onTokenUpdated,
    onSamlAutoSubmit: input.onSamlAutoSubmit
  };
}

function normalizeRequestUrlIncludes(values: string[] | undefined): string[] {
  if (!values) {
    return [...DEFAULT_REQUEST_URL_INCLUDES];
  }
  const cleaned = values.map((value) => value.trim()).filter((value) => value.length > 0);
  return cleaned.length > 0 ? cleaned : [...DEFAULT_REQUEST_URL_INCLUDES];
}

function createDefaultRequestMatcher(includes: string[]): SmallibRequestMatcher {
  return (request: HttpRequest<unknown>) => includes.some((part) => request.url.includes(part));
}
