import { InjectionToken } from '@angular/core';
import type { SmallibFrontConfig } from './config';

export interface SmallibSamlFormHandler {
  handleHtmlResponse(body: string | null | undefined): boolean;
}

export const SMALLIB_SAML_FORM_HANDLER = new InjectionToken<SmallibSamlFormHandler>(
  'SMALLIB_SAML_FORM_HANDLER'
);

/**
 * Cree le gestionnaire de reponse HTML SAML.
 * Son role est d'identifier un formulaire SAML et de le soumettre automatiquement.
 */
export function createSmallibSamlFormHandler(
  config: SmallibFrontConfig,
  documentRef: Document | null
): SmallibSamlFormHandler {
  return {
    handleHtmlResponse: (body: string | null | undefined) => {
      if (!config.saml.enabled) {
        return false;
      }

      const trimmed = (body ?? '').trim();
      if (!looksLikeSamlHtml(trimmed, config)) {
        return false;
      }

      const parser = createDomParser(documentRef);
      if (!parser || !documentRef?.body) {
        return false;
      }

      const parsed = parser.parseFromString(trimmed, 'text/html');
      const sourceForm = parsed.querySelector('form');
      if (!sourceForm) {
        return false;
      }

      const sourceInputs = Array.from(sourceForm.querySelectorAll('input'));
      const expectedName = config.saml.expectedFormInputName.toLowerCase();
      const hasExpectedInput = sourceInputs.some(
        (input) => (input.getAttribute('name') ?? '').toLowerCase() === expectedName
      );
      if (!hasExpectedInput) {
        return false;
      }

      const form = documentRef.createElement('form');
      form.method = (sourceForm.getAttribute('method') ?? 'post').toLowerCase();
      const action = sourceForm.getAttribute('action');
      if (action) {
        form.action = action;
      }

      for (const sourceInput of sourceInputs) {
        const input = documentRef.createElement('input');
        input.type = sourceInput.getAttribute('type') ?? 'hidden';
        input.name = sourceInput.getAttribute('name') ?? '';
        // RelayState peut etre recalcule pour revenir vers l'URL en cours apres SSO.
        input.value = resolveInputValue(sourceInput, documentRef, config);
        form.appendChild(input);
      }

      documentRef.body.appendChild(form);
      config.onSamlAutoSubmit?.({
        action: action ?? null,
        method: form.method,
        inputCount: sourceInputs.length
      });
      form.submit();
      return true;
    }
  };
}

function looksLikeSamlHtml(html: string, config: SmallibFrontConfig): boolean {
  if (!html) {
    return false;
  }
  const lower = html.toLowerCase();
  if (!lower.startsWith('<')) {
    return false;
  }
  if (!lower.includes('<form')) {
    return false;
  }
  return lower.includes(config.saml.expectedFormInputName.toLowerCase());
}

function createDomParser(documentRef: Document | null): DOMParser | null {
  const domParserCtor =
    documentRef?.defaultView?.DOMParser ??
    (typeof DOMParser !== 'undefined' ? DOMParser : undefined);
  if (!domParserCtor) {
    return null;
  }
  return new domParserCtor();
}

function resolveInputValue(
  input: Element,
  documentRef: Document,
  config: SmallibFrontConfig
): string {
  const inputName = (input.getAttribute('name') ?? '').toLowerCase();
  const relayStateName = config.saml.relayStateInputName.toLowerCase();
  if (config.saml.overrideRelayStateWithCurrentUrl && inputName === relayStateName) {
    return documentRef.location?.href ?? '';
  }
  return input.getAttribute('value') ?? '';
}
