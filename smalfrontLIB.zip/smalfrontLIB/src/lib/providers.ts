import { DOCUMENT } from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { InjectionToken, Optional } from '@angular/core';
import {
  createSmallibFrontConfig
} from './config';
import type { Provider } from '@angular/core';
import type { SmallibFrontConfig, SmallibFrontConfigInput } from './config';
import { createAuthTokenInterceptor, createSamlResponseInterceptor } from './interceptors';
import { createSmallibSamlFormHandler, SMALLIB_SAML_FORM_HANDLER } from './saml-form-handler';
import { createSmallibTokenStore, SMALLIB_TOKEN_STORE } from './token-store';

export const SMALLIB_FRONT_CONFIG = new InjectionToken<SmallibFrontConfig>('SMALLIB_FRONT_CONFIG');

/**
 * Point d'entree principal de la librairie.
 * Retourne tous les providers necessaires pour activer la gestion SMAL (token + SAML).
 */
export function provideSmallibFront(configInput: SmallibFrontConfigInput = {}): Provider[] {
  return [
    {
      provide: SMALLIB_FRONT_CONFIG,
      useValue: createSmallibFrontConfig(configInput)
    },
    {
      provide: SMALLIB_TOKEN_STORE,
      useFactory: createSmallibTokenStore,
      deps: [SMALLIB_FRONT_CONFIG]
    },
    {
      provide: SMALLIB_SAML_FORM_HANDLER,
      useFactory: createSmallibSamlFormHandler,
      deps: [SMALLIB_FRONT_CONFIG, [new Optional(), DOCUMENT]]
    },
    {
      provide: HTTP_INTERCEPTORS,
      useFactory: createAuthTokenInterceptor,
      deps: [SMALLIB_FRONT_CONFIG, SMALLIB_TOKEN_STORE],
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useFactory: createSamlResponseInterceptor,
      deps: [SMALLIB_FRONT_CONFIG, SMALLIB_SAML_FORM_HANDLER],
      multi: true
    }
  ];
}
