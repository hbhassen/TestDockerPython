import type { SmallibTokenStorage, SmallibTokenStorageStrategy } from './config';

/**
 * Cree l'implementation de stockage a utiliser pour le token.
 * Si le stockage navigateur n'est pas accessible (SSR, mode prive restrictif, etc.),
 * la librairie retombe automatiquement sur un stockage memoire.
 */
export function createSmallibTokenStorage(
  strategy: SmallibTokenStorageStrategy,
  customStorage?: SmallibTokenStorage
): SmallibTokenStorage {
  if (customStorage) {
    return customStorage;
  }

  if (strategy === 'memory') {
    return createInMemoryStorage();
  }

  const browserStorage = resolveBrowserStorage(strategy);
  if (!browserStorage || !isBrowserStorageAccessible(browserStorage)) {
    return createInMemoryStorage();
  }

  return {
    getItem: (key) => browserStorage.getItem(key),
    setItem: (key, value) => browserStorage.setItem(key, value),
    removeItem: (key) => browserStorage.removeItem(key)
  };
}

function createInMemoryStorage(): SmallibTokenStorage {
  const values = new Map<string, string>();
  return {
    getItem: (key) => values.get(key) ?? null,
    setItem: (key, value) => values.set(key, value),
    removeItem: (key) => values.delete(key)
  };
}

function resolveBrowserStorage(strategy: SmallibTokenStorageStrategy): Storage | null {
  if (typeof window === 'undefined') {
    return null;
  }
  if (strategy === 'localStorage') {
    return window.localStorage;
  }
  if (strategy === 'sessionStorage') {
    return window.sessionStorage;
  }
  return null;
}

function isBrowserStorageAccessible(storage: Storage): boolean {
  const testKey = '__smallib_storage_test__';
  try {
    storage.setItem(testKey, '1');
    storage.removeItem(testKey);
    return true;
  } catch {
    return false;
  }
}
