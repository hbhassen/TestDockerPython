import { InjectionToken } from '@angular/core';
import type { SmallibFrontConfig } from './config';
import { createSmallibTokenStorage } from './token-storage';

export interface SmallibTokenStore {
  getToken(): string | null;
  setToken(token: string | null): void;
  clearToken(): void;
}

export const SMALLIB_TOKEN_STORE = new InjectionToken<SmallibTokenStore>('SMALLIB_TOKEN_STORE');

/**
 * Construit un store de token robuste avec persistance configurable.
 * Le token est mis en cache en memoire pour limiter les lectures repetees du storage navigateur.
 */
export function createSmallibTokenStore(config: SmallibFrontConfig): SmallibTokenStore {
  const storage = createSmallibTokenStorage(config.token.storageStrategy, config.token.customStorage);
  let cachedToken: string | null | undefined;

  const loadToken = (): string | null => {
    if (cachedToken !== undefined) {
      return cachedToken;
    }
    try {
      cachedToken = normalizeToken(storage.getItem(config.token.storageKey));
      return cachedToken;
    } catch {
      cachedToken = null;
      return null;
    }
  };

  const persistToken = (token: string | null): void => {
    const normalized = normalizeToken(token);
    cachedToken = normalized;
    try {
      if (normalized === null) {
        storage.removeItem(config.token.storageKey);
      } else {
        storage.setItem(config.token.storageKey, normalized);
      }
    } catch {
      // Le token reste au moins disponible dans le cache memoire.
    }
    config.onTokenUpdated?.(normalized);
  };

  return {
    getToken: () => loadToken(),
    setToken: (token: string | null) => persistToken(token),
    clearToken: () => persistToken(null)
  };
}

function normalizeToken(token: string | null | undefined): string | null {
  const trimmed = (token ?? '').trim();
  return trimmed.length > 0 ? trimmed : null;
}
