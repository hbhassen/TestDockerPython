import {
  HttpErrorResponse,
  HttpResponse
} from '@angular/common/http';
import { Observable, catchError, mergeMap, of, tap, throwError } from 'rxjs';
import type { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import type { SmallibFrontConfig } from './config';
import type { SmallibSamlFormHandler } from './saml-form-handler';
import type { SmallibTokenStore } from './token-store';

/**
 * Intercepteur 1: ajoute le token sur les requetes sortantes
 * et capte la mise a jour du token depuis les reponses serveur.
 */
export function createAuthTokenInterceptor(
  config: SmallibFrontConfig,
  tokenStore: SmallibTokenStore
): HttpInterceptor {
  return {
    intercept: (request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> => {
      if (!shouldHandleRequest(request, config)) {
        return next.handle(request);
      }

      const token = tokenStore.getToken();
      const authRequest = token
        ? request.clone({
            setHeaders: {
              // Header d'auth configurable pour s'adapter aux conventions backend.
              [config.token.requestHeaderName]: buildAuthorizationHeaderValue(
                config.token.requestHeaderPrefix,
                token
              )
            }
          })
        : request;

      return next.handle(authRequest).pipe(
        tap((event) => {
          if (!(event instanceof HttpResponse)) {
            return;
          }
          const extracted = extractTokenFromResponse(event, config);
          if (extracted !== null) {
            tokenStore.setToken(extracted);
          }
        })
      );
    }
  };
}

/**
 * Intercepteur 2: transforme les reponses texte/HTML retournees pour les APIs JSON.
 * S'il detecte un formulaire SAML, il declenche l'auto-submit et renvoie un body null.
 */
export function createSamlResponseInterceptor(
  config: SmallibFrontConfig,
  samlFormHandler: SmallibSamlFormHandler
): HttpInterceptor {
  return {
    intercept: (request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> => {
      if (!shouldHandleSamlResponse(request, config)) {
        return next.handle(request);
      }

      const textRequest = request.clone({ responseType: 'text' as 'json' });
      // On force un body texte pour detecter d'abord le HTML SAML puis parser le JSON si necessaire.
      return next.handle(textRequest).pipe(
        mergeMap((event) => normalizeJsonEvent(event, samlFormHandler)),
        catchError((error: unknown) => handleSamlErrorResponse(error, samlFormHandler))
      );
    }
  };
}

function shouldHandleRequest(request: HttpRequest<unknown>, config: SmallibFrontConfig): boolean {
  if (!config.enabled) {
    return false;
  }
  return config.requestMatcher(request);
}

function shouldHandleSamlResponse(request: HttpRequest<unknown>, config: SmallibFrontConfig): boolean {
  if (!shouldHandleRequest(request, config)) {
    return false;
  }
  if (!config.saml.enabled) {
    return false;
  }
  return request.responseType === 'json';
}

function buildAuthorizationHeaderValue(prefix: string, token: string): string {
  const cleanPrefix = prefix.trim();
  if (!cleanPrefix) {
    return token;
  }
  return `${cleanPrefix} ${token}`;
}

function extractTokenFromResponse(
  response: HttpResponse<unknown>,
  config: SmallibFrontConfig
): string | null {
  const customExtractor = config.token.tokenExtractor;
  if (customExtractor) {
    return normalizeToken(customExtractor(response));
  }
  return normalizeToken(response.headers.get(config.token.responseHeaderName));
}

function normalizeJsonEvent(
  event: HttpEvent<unknown>,
  samlFormHandler: SmallibSamlFormHandler
): Observable<HttpEvent<unknown>> {
  if (!(event instanceof HttpResponse)) {
    return of(event);
  }
  if (typeof event.body !== 'string') {
    return of(event);
  }

  const trimmed = event.body.trim();
  // Si le backend renvoie un formulaire SAML, on declenche l'auto-submit navigateur.
  if (samlFormHandler.handleHtmlResponse(trimmed)) {
    return of(event.clone({ body: null }));
  }

  if (!trimmed) {
    return of(event.clone({ body: null }));
  }

  try {
    const parsed = JSON.parse(trimmed);
    return of(event.clone({ body: parsed }));
  } catch (error) {
    return throwError(() => error);
  }
}

function handleSamlErrorResponse(
  error: unknown,
  samlFormHandler: SmallibSamlFormHandler
): Observable<HttpEvent<unknown>> {
  if (!(error instanceof HttpErrorResponse)) {
    return throwError(() => error);
  }

  if (typeof error.error === 'string' && samlFormHandler.handleHtmlResponse(error.error.trim())) {
    return of(
      new HttpResponse({
        status: 200,
        url: error.url ?? undefined,
        headers: error.headers,
        body: null
      })
    );
  }

  return throwError(() => error);
}

function normalizeToken(token: string | null | undefined): string | null {
  const trimmed = (token ?? '').trim();
  return trimmed ? trimmed : null;
}
