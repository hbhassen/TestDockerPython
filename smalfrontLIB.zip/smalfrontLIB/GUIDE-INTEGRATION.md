# Guide d'utilisation et d'integration `smallibfront`

## 1. Objectif

`smallibfront` externalise la logique SMAL du frontend:

- login SAML cote navigateur via auto-submit du formulaire IdP,
- interception HTTP transverse,
- gestion du token d'authentification.

Le meme package peut etre injecte dans `demo2-front19` ou dans n'importe quel autre frontend Angular.

## 2. Contrat de configuration

`provideSmallibFront(...)` accepte un `SmallibFrontConfigInput` partiel. Les valeurs non fournies prennent les defauts.

### Parametres globaux

- `enabled` (`boolean`, defaut `true`): active ou desactive la librairie.
- `requestUrlIncludes` (`string[]`, defaut `['/api/']`): filtre simple des URLs concernees.
- `requestMatcher` (`(req) => boolean`): filtre avance. Prioritaire sur `requestUrlIncludes`.

### Parametres token (`token`)

- `responseHeaderName` (defaut `X-Auth-Token`): header lu dans les reponses backend.
- `requestHeaderName` (defaut `Authorization`): header ecrit dans les requetes.
- `requestHeaderPrefix` (defaut `Bearer`): prefixe ajoute avant le token.
- `storageKey` (defaut `smallib.auth.token`): cle de persistance.
- `storageStrategy`: `memory` (defaut), `sessionStorage`, `localStorage`.
- `customStorage`: implementation custom (`getItem`, `setItem`, `removeItem`).
- `tokenExtractor`: strategie custom d'extraction token depuis la reponse.

### Parametres SAML (`saml`)

- `enabled` (`boolean`, defaut `true`): active la gestion SAML.
- `expectedFormInputName` (defaut `SAMLRequest`): input obligatoire du formulaire IdP.
- `relayStateInputName` (defaut `RelayState`): nom du champ relay state.
- `overrideRelayStateWithCurrentUrl` (defaut `true`): remplace relay state par l'URL courante.

### Hooks

- `onTokenUpdated(token)`: callback appele a chaque mise a jour du token.
- `onSamlAutoSubmit(details)`: callback appele avant soumission du formulaire SAML.

## 3. Exemple complet dans un `AppModule`

```ts
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { provideSmallibFront } from 'smallibfront';

@NgModule({
  imports: [BrowserModule, HttpClientModule],
  providers: [
    ...provideSmallibFront({
      requestMatcher: (request) =>
        request.url.startsWith('http://localhost:8080/demo2/api/'),
      token: {
        responseHeaderName: 'X-Auth-Token',
        requestHeaderName: 'Authorization',
        requestHeaderPrefix: 'Bearer',
        storageKey: 'demo2front.token',
        storageStrategy: 'sessionStorage'
      },
      saml: {
        enabled: true,
        expectedFormInputName: 'SAMLRequest',
        relayStateInputName: 'RelayState',
        overrideRelayStateWithCurrentUrl: true
      },
      onTokenUpdated: (token) => console.debug('[smallibfront] token updated', token),
      onSamlAutoSubmit: (details) => console.debug('[smallibfront] saml submit', details)
    })
  ]
})
export class AppModule {}
```

## 4. Exemple avance: extraction token custom

```ts
...provideSmallibFront({
  token: {
    tokenExtractor: (response) => {
      const fromHeader = response.headers.get('X-Auth-Token');
      if (fromHeader) {
        return fromHeader;
      }
      const body = response.body as { token?: string } | null;
      return body?.token ?? null;
    }
  }
})
```

## 5. Strategie d'evolution recommandee

- Ajouter de nouvelles options via `SmallibFrontConfigInput` sans casser les defauts.
- Eviter de modifier les signatures publiques existantes.
- Ajouter des hooks avant tout comportement metier specifique.
- Garder les intercepteurs idempotents et sans etat metier local.

## 6. Integration dans un autre projet Angular

1. Copier/publier le package `smallibfront`.
2. Installer la dependance (`npm install <source>`).
3. Enregistrer `...provideSmallibFront(...)` dans `providers`.
4. Verifier que `HttpClientModule` est present.
5. Adapter `requestMatcher` et les noms de headers selon votre backend.
