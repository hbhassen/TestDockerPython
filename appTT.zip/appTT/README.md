# server-status

`server-status` is a Java 17 Maven library that exposes secure server status endpoints for:

- Spring Boot 3.x applications.
- Jakarta EE / WildFly applications.

The library is intentionally small. The base health status is computed from local JVM state only. It does not use SQL, LDAP, file input, external URLs, shell commands, dynamic expressions, templates, or user supplied request data.

## Architecture

```text
server-status-core
       |
       +-----------------------+
       |                       |
       v                       v
server-status-spring-boot   server-status-wildfly
```

Modules:

- `server-status-core`: model, service contract, local JVM status, security header constants, CORS policy, and rate limiter abstraction.
- `server-status-spring-boot`: Spring Boot 3 auto-configuration and REST controller.
- `server-status-wildfly`: Jakarta REST resource for WildFly.
- `server-status-integration-tests`: architecture and integration checks.

The core module does not depend on Spring, Spring Boot, WildFly, Servlet, Jakarta REST, JDBC, JPA, or Hibernate.

## Maven Artifacts

```xml
<groupId>com.company.platform</groupId>
<artifactId>server-status-core</artifactId>
<version>1.0.0-SNAPSHOT</version>
```

```xml
<groupId>com.company.platform</groupId>
<artifactId>server-status-spring-boot</artifactId>
<version>1.0.0-SNAPSHOT</version>
```

```xml
<groupId>com.company.platform</groupId>
<artifactId>server-status-wildfly</artifactId>
<version>1.0.0-SNAPSHOT</version>
```

## Spring Boot Installation

Add the Spring Boot adapter:

```xml
<dependency>
    <groupId>com.company.platform</groupId>
    <artifactId>server-status-spring-boot</artifactId>
    <version>1.0.0-SNAPSHOT</version>
</dependency>
```

Spring Boot discovers `ServerStatusAutoConfiguration` through:

```text
META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports
```

No controller registration is required in the host application.

## WildFly Installation

Add the WildFly adapter to the WAR:

```xml
<dependency>
    <groupId>com.company.platform</groupId>
    <artifactId>server-status-wildfly</artifactId>
    <version>1.0.0-SNAPSHOT</version>
</dependency>
```

The adapter exposes a Jakarta REST resource using `jakarta.*` APIs:

```text
com.company.platform.serverstatus.wildfly.ServerStatusResource
```

WildFly compatibility target: Jakarta EE 10 / Jakarta REST 3.1 compatible runtimes.

## Configuration

Spring Boot properties:

```properties
server-status.enabled=true
server-status.application-name=${spring.application.name:unknown}
server-status.public-endpoint-enabled=true
server-status.details-enabled=false
server-status.details.enabled=false
server-status.rate-limit.enabled=true
server-status.rate-limit.requests-per-minute=100
server-status.cors.enabled=false
server-status.cors.allowed-origins=https://example.com
```

WildFly system properties:

```properties
server-status.application-name=unknown
server-status.details-enabled=false
server-status.rate-limit.enabled=true
server-status.rate-limit.requests-per-minute=100
server-status.cors.enabled=false
server-status.cors.allowed-origins=https://example.com
```

`details-enabled=false` is the secure default. It returns only:

```json
{
  "status": "UP"
}
```

When details are enabled, the detailed endpoint may return:

```json
{
  "status": "UP",
  "application": "my-application",
  "server": "Spring Boot",
  "javaVersion": "17.0.x",
  "uptimeSeconds": 123456,
  "timestamp": "2026-08-24T03:00:00Z"
}
```

## Endpoints

| Method | Path | Purpose |
| --- | --- | --- |
| `GET` | `/public/server-status/live` | Liveness probe. Verifies that the process can answer. |
| `GET` | `/public/server-status/ready` | Readiness probe. Indicates whether the application should receive traffic. |
| `GET` | `/public/server-status` | Minimal or detailed status depending on configuration. |

Only `GET` is supported. `POST`, `PUT`, `DELETE`, and `PATCH` return `405`.

## Liveness vs Readiness

Liveness is intentionally minimal. It should stay cheap enough for Kubernetes/OpenShift process probes and must not depend on databases, networks, files, shell commands, LDAP, or external services.

Readiness represents whether the host application can receive traffic. This base library returns the local status because it does not own host-specific dependencies. Applications that need deeper readiness checks should add host-owned checks without accepting user input.

## Curl Examples

```bash
curl -i http://localhost:8080/public/server-status/live
curl -i http://localhost:8080/public/server-status/ready
curl -i http://localhost:8080/public/server-status
```

## Security Model

Public endpoints do not accept request bodies, query parameters, URLs, file paths, SQL fragments, commands, LDAP filters, expressions, or templates.

The implementation never returns:

- Hostname.
- Internal IP address.
- Username.
- Password.
- Environment variables.
- Classpath.
- System paths.
- Secrets.
- Tokens.
- Credentials.
- Database URLs.
- Stack traces.
- Internal configuration.

Spring Security and WildFly security remain owned by the host application. This library does not implement a custom JWT or secret store.

## Rate Limiting

The core exposes `RateLimiter`. The default implementation is an in-memory fixed one-minute limiter.

Defaults:

```properties
server-status.rate-limit.enabled=true
server-status.rate-limit.requests-per-minute=100
```

The implementation uses the container remote address. It does not trust `X-Forwarded-For` by default. If a deployment requires reverse proxy awareness, that trust boundary must be configured in the host platform or server, not by blindly accepting client headers.

## CORS

CORS is disabled by default:

```properties
server-status.cors.enabled=false
```

When enabled, only exact allowlisted origins are reflected:

```properties
server-status.cors.allowed-origins=https://example.com
```

`Access-Control-Allow-Origin: *` is not emitted by this library.

## HTTP Headers

Every JSON response produced by the adapters includes:

- `Content-Type: application/json`
- `X-Content-Type-Options: nosniff`
- `Cache-Control: no-store`
- `Referrer-Policy: no-referrer`
- `Permissions-Policy: geolocation=(), microphone=(), camera=()`

These headers reduce content sniffing, caching of status payloads, referrer leakage, and unnecessary browser feature access.

## Kubernetes and OpenShift

Use:

```yaml
livenessProbe:
  httpGet:
    path: /public/server-status/live
    port: 8080
readinessProbe:
  httpGet:
    path: /public/server-status/ready
    port: 8080
```

The `/live` endpoint is deliberately light:

1. Receive the request.
2. Verify the HTTP method through framework routing.
3. Apply HTTP protections.
4. Return local JVM status.
5. Emit a small JSON body.

It does not perform SQL, network calls, file reads, shell execution, dynamic expression evaluation, or template rendering.

## Tests

Run:

```bash
mvn clean verify
```

The test suite covers:

- Core status service contract.
- JVM status implementation.
- Spring Boot controller responses.
- HTTP methods.
- JSON content type.
- Security headers.
- CORS allowlist behavior.
- Rate limiting.
- Injection payloads that must not reach business logic.
- Minimal error responses without stack traces.
- Core module architecture boundaries.

## Maven Build

Requirements:

- Java 17 or newer.
- Maven 3.9 or newer.

Commands:

```bash
mvn clean verify
mvn dependency:tree
```

The Maven Enforcer Plugin checks Java and Maven versions and dependency convergence.

## Dependency Scan

The project includes an optional OWASP Dependency-Check profile:

```bash
mvn -Pdependency-check verify
```

This scan may need network access to vulnerability feeds. Configure any required API keys through environment variables or CI secrets, not in Git. Set `NVD_API_KEY` when the NVD API requires authenticated access.

## Artifactory

The parent POM defines `distributionManagement` entries backed by environment variables:

```text
ARTIFACTORY_RELEASE_URL
ARTIFACTORY_SNAPSHOT_URL
```

Credentials must be provided through Maven `settings.xml`, environment variables, or CI/CD secrets:

```text
ARTIFACTORY_USER
ARTIFACTORY_TOKEN
```

No username, password, token, or Artifactory URL is stored in source code.

## Compatibility

- Java: 17 minimum.
- Maven: 3.9 minimum.
- Spring Boot: 3.x.
- Jakarta REST: 3.1.
- WildFly: Jakarta EE 10 compatible distributions.

## Limitations

- The base readiness check is local only.
- The in-memory rate limiter is per JVM instance and is not shared across cluster nodes.
- Detailed status is disabled by default and should be protected by the host application when enabled.
- No database, LDAP, external URL, command execution, or filesystem based health check is included.

## Threat Model

See [SECURITY.md](SECURITY.md) and [docs/THREAT_MODEL.md](docs/THREAT_MODEL.md).

## Integration Examples

Examples are available in:

- [examples/spring-boot](examples/spring-boot)
- [examples/wildfly](examples/wildfly)
