package com.company.platform.serverstatus.it;

public final class IntegrationTestModule {

    private IntegrationTestModule() {
    }
}
