package com.company.platform.serverstatus.it;

import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ProjectArchitectureIT {

    @Test
    void corePomDoesNotDeclareWebOrPersistenceFrameworks() throws IOException {
        String corePom = Files.readString(Path.of("..", "server-status-core", "pom.xml"));

        assertFalse(corePom.contains("spring-boot"));
        assertFalse(corePom.contains("spring-web"));
        assertFalse(corePom.contains("jakarta.ws.rs"));
        assertFalse(corePom.contains("hibernate"));
        assertFalse(corePom.contains("jdbc"));
        assertFalse(corePom.contains("jpa"));
    }

    @Test
    void adaptersAndCoreAreLoadableTogether() {
        assertDoesNotThrow(() -> Class.forName("com.company.platform.serverstatus.core.DefaultServerStatusService"));
        assertDoesNotThrow(() -> Class.forName("com.company.platform.serverstatus.springboot.ServerStatusController"));
        assertDoesNotThrow(() -> Class.forName("com.company.platform.serverstatus.wildfly.ServerStatusResource"));
    }

    @Test
    void springBootAutoConfigurationDescriptorExists() {
        assertTrue(Files.exists(Path.of(
                "..",
                "server-status-spring-boot",
                "src",
                "main",
                "resources",
                "META-INF",
                "spring",
                "org.springframework.boot.autoconfigure.AutoConfiguration.imports"
        )));
    }
}
