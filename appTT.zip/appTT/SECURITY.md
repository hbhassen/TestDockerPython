# Security Policy

## Principles

`server-status` reduces attack surface by refusing unnecessary user input. The public endpoints do not need request bodies, query parameters, external URLs, file paths, SQL fragments, shell commands, LDAP filters, templates, or expressions.

The base status check uses local JVM APIs only:

- `ManagementFactory.getRuntimeMXBean()`
- `Runtime.version()`
- `Instant.now()`

## Threat Model

| Threat | Risk | Scenario | Mitigation | Associated test |
| --- | --- | --- | --- | --- |
| SQL Injection | Dynamic SQL can expose or modify data. | A caller sends `' OR '1'='1`. | No SQL dependency or SQL execution exists in the health path. | `InjectionSecurityTest`, `ProjectArchitectureIT` |
| XSS | Reflected HTML can execute in a browser. | A caller sends `<script>alert(1)</script>`. | User input is not reflected; responses are JSON; `nosniff` is set. | `InjectionSecurityTest`, `JsonResponseTest`, `HeaderSecurityTest` |
| SSRF | Server-side URL fetches can reach internal services. | A caller sends `http://169.254.169.254`. | No URL is accepted or fetched by the status logic. | `InjectionSecurityTest` |
| Command Injection | Shell execution can compromise the host. | A caller sends `; whoami` or `$(whoami)`. | No shell or `ProcessBuilder` is used. | `InjectionSecurityTest` |
| Path Traversal | File reads can expose host files. | A caller sends `../../../../etc/passwd`. | No user supplied path is accepted and no file read is used for status. | `InjectionSecurityTest` |
| LDAP Injection | LDAP filters can be manipulated. | A caller sends `${jndi:ldap://example.com/a}`. | No LDAP usage exists in the health path. | `InjectionSecurityTest` |
| XXE | XML parsing can expose files or networks. | A payload contains an external XML entity. | Endpoints do not accept XML or complex request bodies. | `JsonResponseTest` |
| Deserialization | Polymorphic payloads can trigger unsafe types. | A caller sends a crafted JSON payload. | Endpoints do not accept JSON request bodies. | `HttpMethodSecurityTest` |
| Log Injection | Malicious values can forge log lines. | A caller sends CRLF input. | User input is not logged by the endpoint logic; errors log only exception class names. | `ErrorHandlingTest` |
| Header Injection | Reflected header data can split responses. | A caller sends a malicious origin. | CORS reflects only exact allowlisted origins and ignores `*`. | `CorsTest` |
| DoS | Excessive probes can consume CPU or memory. | A caller floods public endpoints. | In-memory rate limiting is enabled by default. | `RateLimitTest`, `InMemoryRateLimiterTest` |
| Rate Abuse | Reverse proxy headers can be spoofed. | A caller spoofs `X-Forwarded-For`. | The default client key uses the container remote address, not `X-Forwarded-For`. | `SpringBootSecurityTest` |
| Information Disclosure | Status endpoints can leak host details. | A public call requests `/public/server-status`. | Details are disabled by default; no hostname, IP, user, paths, secrets, or stack traces are returned. | `SpringBootSecurityTest`, `ErrorHandlingTest` |
| Dependency Vulnerabilities | Transitive dependencies can introduce CVEs. | A framework dependency receives a CVE. | Maven Enforcer and optional OWASP Dependency-Check profile are configured. | `mvn dependency:tree`, `mvn -Pdependency-check verify` |

## Sensitive Data Rules

Never store or expose:

- Passwords.
- Tokens.
- Authorization headers.
- Cookies.
- Credentials.
- Secrets.
- Internal paths.
- Internal IP addresses.
- Usernames.
- Environment variables.
- Database URLs.
- Stack traces.

## Reporting

Use the owning repository issue or security process for vulnerability reports. Do not include real secrets in reports, logs, screenshots, or reproduction data.
