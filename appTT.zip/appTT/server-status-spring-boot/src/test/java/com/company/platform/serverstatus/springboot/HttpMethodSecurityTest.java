package com.company.platform.serverstatus.springboot;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class HttpMethodSecurityTest {

    private final MockMvc mockMvc = ServerStatusMockMvcSupport.mockMvc();

    @ParameterizedTest
    @ValueSource(strings = {"POST", "PUT", "DELETE", "PATCH"})
    void liveEndpointRejectsNonGetMethods(String method) throws Exception {
        perform(method)
                .andExpect(status().isMethodNotAllowed())
                .andExpect(jsonPath("$.error").value("method_not_allowed"));
    }

    private ResultActions perform(String method) throws Exception {
        return switch (method) {
            case "POST" -> mockMvc.perform(post("/public/server-status/live"));
            case "PUT" -> mockMvc.perform(put("/public/server-status/live"));
            case "DELETE" -> mockMvc.perform(delete("/public/server-status/live"));
            case "PATCH" -> mockMvc.perform(patch("/public/server-status/live"));
            default -> throw new IllegalArgumentException("Unsupported method: " + method);
        };
    }
}
