package com.company.platform.serverstatus.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class SpringBootControllerTest {

    private final MockMvc mockMvc = ServerStatusMockMvcSupport.mockMvc();

    @Test
    void liveEndpointReturnsUp() throws Exception {
        mockMvc.perform(get("/public/server-status/live"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("UP"));
    }

    @Test
    void readyEndpointReturnsUp() throws Exception {
        mockMvc.perform(get("/public/server-status/ready"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("UP"));
    }

    @Test
    void statusEndpointReturnsMinimalResponseByDefault() throws Exception {
        mockMvc.perform(get("/public/server-status"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("UP"))
                .andExpect(jsonPath("$.application").doesNotExist());
    }

    @Test
    void statusEndpointCanReturnConfiguredDetails() throws Exception {
        ServerStatusProperties properties = new ServerStatusProperties();
        properties.setDetailsEnabled(true);

        ServerStatusMockMvcSupport.mockMvc(properties)
                .perform(get("/public/server-status"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("UP"))
                .andExpect(jsonPath("$.application").value("test-application"))
                .andExpect(jsonPath("$.server").value("Spring Boot"))
                .andExpect(jsonPath("$.uptimeSeconds").isNumber())
                .andExpect(jsonPath("$.timestamp").exists());
    }
}
