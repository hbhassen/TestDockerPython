package com.company.platform.serverstatus.springboot;

import com.company.platform.serverstatus.core.CorsPolicy;
import com.company.platform.serverstatus.core.DefaultServerStatusService;
import com.company.platform.serverstatus.core.InMemoryRateLimiter;
import com.company.platform.serverstatus.core.RateLimiter;
import com.company.platform.serverstatus.core.ServerStatusService;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

final class ServerStatusMockMvcSupport {

    private ServerStatusMockMvcSupport() {
    }

    static MockMvc mockMvc() {
        return mockMvc(new ServerStatusProperties());
    }

    static MockMvc mockMvc(ServerStatusProperties properties) {
        RateLimiter rateLimiter = new InMemoryRateLimiter(
                properties.getRateLimit().isEnabled(),
                properties.getRateLimit().getRequestsPerMinute()
        );
        return mockMvc(properties, new DefaultServerStatusService("test-application", "Spring Boot"), rateLimiter);
    }

    static MockMvc mockMvc(
            ServerStatusProperties properties,
            ServerStatusService serverStatusService,
            RateLimiter rateLimiter
    ) {
        CorsPolicy corsPolicy = new CorsPolicy(
                properties.getCors().isEnabled(),
                properties.getCors().getAllowedOrigins()
        );
        ServerStatusController controller = new ServerStatusController(
                serverStatusService,
                rateLimiter,
                corsPolicy,
                properties
        );
        return MockMvcBuilders.standaloneSetup(controller)
                .setControllerAdvice(new ServerStatusErrorHandler(corsPolicy))
                .setMessageConverters(jsonConverter())
                .addFilters(new ServerStatusHeaderFilter(corsPolicy))
                .build();
    }

    private static MappingJackson2HttpMessageConverter jsonConverter() {
        return new MappingJackson2HttpMessageConverter(Jackson2ObjectMapperBuilder.json().build());
    }
}
