package com.company.platform.serverstatus.springboot;

import com.company.platform.serverstatus.core.ServerStatusService;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;

import static org.assertj.core.api.Assertions.assertThat;

class ServerStatusAutoConfigurationTest {

    private final ApplicationContextRunner contextRunner = new ApplicationContextRunner()
            .withConfiguration(AutoConfigurations.of(ServerStatusAutoConfiguration.class));

    @Test
    void autoConfigurationProvidesDefaultBeans() {
        contextRunner.run(context -> {
            assertThat(context).hasSingleBean(ServerStatusService.class);
            assertThat(context).hasSingleBean(ServerStatusController.class);
            assertThat(context).hasSingleBean(ServerStatusProperties.class);
        });
    }

    @Test
    void endpointCanBeDisabled() {
        contextRunner
                .withPropertyValues("server-status.public-endpoint-enabled=false")
                .run(context -> assertThat(context).doesNotHaveBean(ServerStatusController.class));
    }
}
