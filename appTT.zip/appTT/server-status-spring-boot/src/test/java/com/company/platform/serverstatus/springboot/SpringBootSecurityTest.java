package com.company.platform.serverstatus.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class SpringBootSecurityTest {

    private final MockMvc mockMvc = ServerStatusMockMvcSupport.mockMvc();

    @Test
    void defaultResponseDoesNotExposeSensitiveDetails() throws Exception {
        mockMvc.perform(get("/public/server-status"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("UP"))
                .andExpect(jsonPath("$.javaVersion").doesNotExist())
                .andExpect(jsonPath("$.timestamp").doesNotExist())
                .andExpect(content().string(not(containsString("password"))))
                .andExpect(content().string(not(containsString("token"))))
                .andExpect(content().string(not(containsString("stackTrace"))));
    }

    @Test
    void forwardedForHeaderIsNotReflected() throws Exception {
        mockMvc.perform(get("/public/server-status/live")
                        .header("X-Forwarded-For", "203.0.113.10, 127.0.0.1"))
                .andExpect(status().isOk())
                .andExpect(content().string(not(containsString("203.0.113.10"))))
                .andExpect(content().string(not(containsString("127.0.0.1"))));
    }
}
