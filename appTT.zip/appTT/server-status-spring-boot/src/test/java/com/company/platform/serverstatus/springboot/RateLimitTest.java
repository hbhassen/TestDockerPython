package com.company.platform.serverstatus.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class RateLimitTest {

    @Test
    void returnsTooManyRequestsWhenLimitIsExceeded() throws Exception {
        ServerStatusProperties properties = new ServerStatusProperties();
        properties.getRateLimit().setRequestsPerMinute(1);
        MockMvc mockMvc = ServerStatusMockMvcSupport.mockMvc(properties);

        mockMvc.perform(get("/public/server-status/live"))
                .andExpect(status().isOk());

        mockMvc.perform(get("/public/server-status/live"))
                .andExpect(status().isTooManyRequests())
                .andExpect(jsonPath("$.error").value("too_many_requests"));
    }
}
