package com.company.platform.serverstatus.springboot;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class InjectionSecurityTest {

    private final MockMvc mockMvc = ServerStatusMockMvcSupport.mockMvc();

    @ParameterizedTest
    @ValueSource(strings = {
            "<script>alert(1)</script>",
            "' OR '1'='1",
            "\" OR 1=1 --",
            "../../../../etc/passwd",
            "$(whoami)",
            "; whoami",
            "${jndi:ldap://example.com/a}",
            "http://127.0.0.1",
            "http://169.254.169.254"
    })
    void userSuppliedValuesAreIgnored(String payload) throws Exception {
        mockMvc.perform(get("/public/server-status/live").param("ignored", payload))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("UP"))
                .andExpect(content().string(not(containsString(payload))));
    }
}
