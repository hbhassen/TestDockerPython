package com.company.platform.serverstatus.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class HeaderSecurityTest {

    private final MockMvc mockMvc = ServerStatusMockMvcSupport.mockMvc();

    @Test
    void responseContainsSecurityHeaders() throws Exception {
        mockMvc.perform(get("/public/server-status/live"))
                .andExpect(status().isOk())
                .andExpect(header().string("X-Content-Type-Options", "nosniff"))
                .andExpect(header().string("Cache-Control", "no-store"))
                .andExpect(header().string("Referrer-Policy", "no-referrer"))
                .andExpect(header().string("Permissions-Policy", "geolocation=(), microphone=(), camera=()"));
    }
}
