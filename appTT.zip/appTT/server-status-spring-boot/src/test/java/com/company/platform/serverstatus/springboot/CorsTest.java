package com.company.platform.serverstatus.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class CorsTest {

    @Test
    void corsIsDisabledByDefault() throws Exception {
        ServerStatusMockMvcSupport.mockMvc()
                .perform(get("/public/server-status/live")
                        .header(HttpHeaders.ORIGIN, "https://example.com"))
                .andExpect(status().isOk())
                .andExpect(header().doesNotExist(HttpHeaders.ACCESS_CONTROL_ALLOW_ORIGIN));
    }

    @Test
    void corsUsesExplicitAllowListWhenEnabled() throws Exception {
        ServerStatusProperties properties = new ServerStatusProperties();
        properties.getCors().setEnabled(true);
        properties.getCors().setAllowedOrigins(List.of("https://example.com", "*"));
        MockMvc mockMvc = ServerStatusMockMvcSupport.mockMvc(properties);

        mockMvc.perform(get("/public/server-status/live")
                        .header(HttpHeaders.ORIGIN, "https://example.com"))
                .andExpect(status().isOk())
                .andExpect(header().string(HttpHeaders.ACCESS_CONTROL_ALLOW_ORIGIN, "https://example.com"));

        mockMvc.perform(get("/public/server-status/live")
                        .header(HttpHeaders.ORIGIN, "https://other.example"))
                .andExpect(status().isOk())
                .andExpect(header().doesNotExist(HttpHeaders.ACCESS_CONTROL_ALLOW_ORIGIN));
    }
}
