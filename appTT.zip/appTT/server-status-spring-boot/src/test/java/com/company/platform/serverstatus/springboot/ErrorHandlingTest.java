package com.company.platform.serverstatus.springboot;

import com.company.platform.serverstatus.core.InMemoryRateLimiter;
import com.company.platform.serverstatus.core.ServerStatusService;
import org.junit.jupiter.api.Test;

import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class ErrorHandlingTest {

    @Test
    void unexpectedErrorsReturnMinimalJsonWithoutStackTrace() throws Exception {
        ServerStatusProperties properties = new ServerStatusProperties();
        properties.setDetailsEnabled(true);
        ServerStatusService failingService = () -> {
            throw new IllegalStateException("databasePassword:<DATABASE_PASSWORD>");
        };

        ServerStatusMockMvcSupport.mockMvc(properties, failingService, new InMemoryRateLimiter(false, 1))
                .perform(get("/public/server-status"))
                .andExpect(status().isInternalServerError())
                .andExpect(jsonPath("$.error").value("server_status_unavailable"))
                .andExpect(content().string(not(containsString("IllegalStateException"))))
                .andExpect(content().string(not(containsString("databasePassword"))))
                .andExpect(content().string(not(containsString("stackTrace"))));
    }
}
