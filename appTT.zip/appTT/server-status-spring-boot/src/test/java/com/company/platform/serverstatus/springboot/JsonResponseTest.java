package com.company.platform.serverstatus.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.startsWith;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class JsonResponseTest {

    private final MockMvc mockMvc = ServerStatusMockMvcSupport.mockMvc();

    @Test
    void liveEndpointReturnsJsonOnly() throws Exception {
        mockMvc.perform(get("/public/server-status/live"))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andExpect(header().string("Content-Type", startsWith("application/json")))
                .andExpect(content().string(not(startsWith("<!doctype html"))));
    }
}
