package com.company.platform.serverstatus.springboot;

import com.company.platform.serverstatus.core.CorsPolicy;
import com.company.platform.serverstatus.core.HttpSecurityHeaders;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpHeaders;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

public final class ServerStatusHeaderFilter extends OncePerRequestFilter {

    private final CorsPolicy corsPolicy;

    public ServerStatusHeaderFilter(CorsPolicy corsPolicy) {
        this.corsPolicy = corsPolicy;
    }

    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain
    ) throws ServletException, IOException {
        HttpSecurityHeaders.defaultHeaders().forEach(response::setHeader);

        String origin = request.getHeader(HttpHeaders.ORIGIN);
        corsPolicy.allowOrigin(origin).ifPresent(allowedOrigin -> {
            response.setHeader(HttpHeaders.ACCESS_CONTROL_ALLOW_ORIGIN, allowedOrigin);
            response.addHeader(HttpHeaders.VARY, HttpHeaders.ORIGIN);
        });

        filterChain.doFilter(request, response);
    }
}
