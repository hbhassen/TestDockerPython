package com.company.platform.serverstatus.springboot;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.ArrayList;
import java.util.List;

@ConfigurationProperties(prefix = "server-status")
public class ServerStatusProperties {

    private boolean enabled = true;
    private String applicationName = "unknown";
    private boolean publicEndpointEnabled = true;
    private boolean detailsEnabled = false;
    private Details details = new Details();
    private RateLimit rateLimit = new RateLimit();
    private Cors cors = new Cors();

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getApplicationName() {
        return applicationName;
    }

    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }

    public boolean isPublicEndpointEnabled() {
        return publicEndpointEnabled;
    }

    public void setPublicEndpointEnabled(boolean publicEndpointEnabled) {
        this.publicEndpointEnabled = publicEndpointEnabled;
    }

    public boolean isDetailsEnabled() {
        return detailsEnabled;
    }

    public void setDetailsEnabled(boolean detailsEnabled) {
        this.detailsEnabled = detailsEnabled;
    }

    public Details getDetails() {
        return details;
    }

    public void setDetails(Details details) {
        this.details = details == null ? new Details() : details;
    }

    public boolean resolvedDetailsEnabled() {
        return detailsEnabled || details.isEnabled();
    }

    public RateLimit getRateLimit() {
        return rateLimit;
    }

    public void setRateLimit(RateLimit rateLimit) {
        this.rateLimit = rateLimit == null ? new RateLimit() : rateLimit;
    }

    public Cors getCors() {
        return cors;
    }

    public void setCors(Cors cors) {
        this.cors = cors == null ? new Cors() : cors;
    }

    public static class Details {
        private boolean enabled = false;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }
    }

    public static class RateLimit {
        private boolean enabled = true;
        private int requestsPerMinute = 100;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public int getRequestsPerMinute() {
            return requestsPerMinute;
        }

        public void setRequestsPerMinute(int requestsPerMinute) {
            this.requestsPerMinute = requestsPerMinute;
        }
    }

    public static class Cors {
        private boolean enabled = false;
        private List<String> allowedOrigins = new ArrayList<>();

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public List<String> getAllowedOrigins() {
            return allowedOrigins;
        }

        public void setAllowedOrigins(List<String> allowedOrigins) {
            this.allowedOrigins = allowedOrigins == null ? new ArrayList<>() : allowedOrigins;
        }
    }
}
