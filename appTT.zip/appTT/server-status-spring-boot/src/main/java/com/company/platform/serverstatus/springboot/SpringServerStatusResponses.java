package com.company.platform.serverstatus.springboot;

import com.company.platform.serverstatus.core.CorsPolicy;
import com.company.platform.serverstatus.core.HttpSecurityHeaders;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import java.util.List;

final class SpringServerStatusResponses {

    private SpringServerStatusResponses() {
    }

    static ResponseEntity<Object> json(
            HttpStatus status,
            Object body,
            CorsPolicy corsPolicy,
            HttpServletRequest request
    ) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpSecurityHeaders.defaultHeaders().forEach(headers::set);

        String origin = request == null ? null : request.getHeader(HttpHeaders.ORIGIN);
        corsPolicy.allowOrigin(origin).ifPresent(allowedOrigin -> {
            headers.set(HttpHeaders.ACCESS_CONTROL_ALLOW_ORIGIN, allowedOrigin);
            headers.setVary(List.of(HttpHeaders.ORIGIN));
        });

        return ResponseEntity.status(status).headers(headers).body(body);
    }
}
