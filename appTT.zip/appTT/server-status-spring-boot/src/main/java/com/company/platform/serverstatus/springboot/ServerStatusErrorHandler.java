package com.company.platform.serverstatus.springboot;

import com.company.platform.serverstatus.core.CorsPolicy;
import com.company.platform.serverstatus.core.ServerStatusErrorResponse;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ServerStatusErrorHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(ServerStatusErrorHandler.class);

    private final CorsPolicy corsPolicy;

    public ServerStatusErrorHandler(CorsPolicy corsPolicy) {
        this.corsPolicy = corsPolicy;
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> handle(Exception exception, HttpServletRequest request) {
        LOGGER.warn("Server status endpoint failed with {}", exception.getClass().getName());
        return SpringServerStatusResponses.json(
                HttpStatus.INTERNAL_SERVER_ERROR,
                ServerStatusErrorResponse.genericFailure(),
                corsPolicy,
                request
        );
    }
}
