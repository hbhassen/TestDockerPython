package com.company.platform.serverstatus.springboot;

import com.company.platform.serverstatus.core.CorsPolicy;
import com.company.platform.serverstatus.core.RateLimiter;
import com.company.platform.serverstatus.core.ServerStatus;
import com.company.platform.serverstatus.core.ServerStatusErrorResponse;
import com.company.platform.serverstatus.core.ServerStatusProbeResponse;
import com.company.platform.serverstatus.core.ServerStatusService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "/public/server-status", produces = MediaType.APPLICATION_JSON_VALUE)
public class ServerStatusController {

    private static final ServerStatusProbeResponse UP_RESPONSE = new ServerStatusProbeResponse(ServerStatus.UP);

    private final ServerStatusService serverStatusService;
    private final RateLimiter rateLimiter;
    private final CorsPolicy corsPolicy;
    private final ServerStatusProperties properties;

    public ServerStatusController(
            ServerStatusService serverStatusService,
            RateLimiter rateLimiter,
            CorsPolicy corsPolicy,
            ServerStatusProperties properties
    ) {
        this.serverStatusService = serverStatusService;
        this.rateLimiter = rateLimiter;
        this.corsPolicy = corsPolicy;
        this.properties = properties;
    }

    @GetMapping("/live")
    public ResponseEntity<Object> live(HttpServletRequest request) {
        return probeResponse(request);
    }

    @GetMapping("/ready")
    public ResponseEntity<Object> ready(HttpServletRequest request) {
        return probeResponse(request);
    }

    @GetMapping({"", "/"})
    public ResponseEntity<Object> status(HttpServletRequest request) {
        if (isRateLimited(request)) {
            return SpringServerStatusResponses.json(
                    HttpStatus.TOO_MANY_REQUESTS,
                    ServerStatusErrorResponse.tooManyRequests(),
                    corsPolicy,
                    request
            );
        }
        Object body = properties.resolvedDetailsEnabled() ? serverStatusService.getStatus() : UP_RESPONSE;
        return SpringServerStatusResponses.json(HttpStatus.OK, body, corsPolicy, request);
    }

    @RequestMapping(
            path = {"/live", "/ready", "", "/"},
            method = {RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.PATCH}
    )
    public ResponseEntity<Object> methodNotAllowed(HttpServletRequest request) {
        return SpringServerStatusResponses.json(
                HttpStatus.METHOD_NOT_ALLOWED,
                ServerStatusErrorResponse.methodNotAllowed(),
                corsPolicy,
                request
        );
    }

    private ResponseEntity<Object> probeResponse(HttpServletRequest request) {
        if (isRateLimited(request)) {
            return SpringServerStatusResponses.json(
                    HttpStatus.TOO_MANY_REQUESTS,
                    ServerStatusErrorResponse.tooManyRequests(),
                    corsPolicy,
                    request
            );
        }
        return SpringServerStatusResponses.json(HttpStatus.OK, UP_RESPONSE, corsPolicy, request);
    }

    private boolean isRateLimited(HttpServletRequest request) {
        return !rateLimiter.tryAcquire(clientKey(request));
    }

    private static String clientKey(HttpServletRequest request) {
        if (request == null || request.getRemoteAddr() == null || request.getRemoteAddr().isBlank()) {
            return "spring";
        }
        return request.getRemoteAddr();
    }
}
