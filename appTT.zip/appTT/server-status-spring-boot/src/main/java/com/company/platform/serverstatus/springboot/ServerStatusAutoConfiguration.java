package com.company.platform.serverstatus.springboot;

import com.company.platform.serverstatus.core.CorsPolicy;
import com.company.platform.serverstatus.core.DefaultServerStatusService;
import com.company.platform.serverstatus.core.InMemoryRateLimiter;
import com.company.platform.serverstatus.core.RateLimiter;
import com.company.platform.serverstatus.core.ServerStatusService;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.core.Ordered;

@AutoConfiguration
@EnableConfigurationProperties(ServerStatusProperties.class)
@ConditionalOnProperty(prefix = "server-status", name = "enabled", havingValue = "true", matchIfMissing = true)
public class ServerStatusAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    public ServerStatusService serverStatusService(ServerStatusProperties properties) {
        return new DefaultServerStatusService(properties.getApplicationName(), "Spring Boot");
    }

    @Bean
    @ConditionalOnMissingBean
    public RateLimiter serverStatusRateLimiter(ServerStatusProperties properties) {
        return new InMemoryRateLimiter(
                properties.getRateLimit().isEnabled(),
                properties.getRateLimit().getRequestsPerMinute()
        );
    }

    @Bean
    @ConditionalOnMissingBean
    public CorsPolicy serverStatusCorsPolicy(ServerStatusProperties properties) {
        return new CorsPolicy(
                properties.getCors().isEnabled(),
                properties.getCors().getAllowedOrigins()
        );
    }

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(
            prefix = "server-status",
            name = "public-endpoint-enabled",
            havingValue = "true",
            matchIfMissing = true
    )
    public ServerStatusController serverStatusController(
            ServerStatusService serverStatusService,
            RateLimiter serverStatusRateLimiter,
            CorsPolicy serverStatusCorsPolicy,
            ServerStatusProperties properties
    ) {
        return new ServerStatusController(
                serverStatusService,
                serverStatusRateLimiter,
                serverStatusCorsPolicy,
                properties
        );
    }

    @Bean
    @ConditionalOnMissingBean
    public ServerStatusErrorHandler serverStatusErrorHandler(CorsPolicy serverStatusCorsPolicy) {
        return new ServerStatusErrorHandler(serverStatusCorsPolicy);
    }

    @Bean
    public FilterRegistrationBean<ServerStatusHeaderFilter> serverStatusHeaderFilter(CorsPolicy serverStatusCorsPolicy) {
        FilterRegistrationBean<ServerStatusHeaderFilter> registration = new FilterRegistrationBean<>();
        registration.setFilter(new ServerStatusHeaderFilter(serverStatusCorsPolicy));
        registration.addUrlPatterns("/public/server-status", "/public/server-status/*");
        registration.setName("serverStatusHeaderFilter");
        registration.setOrder(Ordered.HIGHEST_PRECEDENCE);
        return registration;
    }
}
