package com.company.platform.serverstatus.core;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class ServerStatusServiceTest {

    @Test
    void contractReturnsLocalStatusResponse() {
        ServerStatusService service = new DefaultServerStatusService("app", "server");

        ServerStatusResponse response = service.getStatus();

        assertEquals(ServerStatus.UP, response.status());
        assertEquals("app", response.application());
        assertEquals("server", response.server());
        assertNotNull(response.javaVersion());
        assertNotNull(response.timestamp());
    }
}
