package com.company.platform.serverstatus.core;

import org.junit.jupiter.api.Test;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class InMemoryRateLimiterTest {

    @Test
    void deniesRequestsAboveConfiguredMinuteLimit() {
        Clock clock = Clock.fixed(Instant.parse("2026-08-24T03:00:00Z"), ZoneOffset.UTC);
        RateLimiter rateLimiter = new InMemoryRateLimiter(true, 2, clock);

        assertTrue(rateLimiter.tryAcquire("client-a"));
        assertTrue(rateLimiter.tryAcquire("client-a"));
        assertFalse(rateLimiter.tryAcquire("client-a"));
        assertTrue(rateLimiter.tryAcquire("client-b"));
    }

    @Test
    void disabledLimiterAlwaysAllowsRequests() {
        RateLimiter rateLimiter = new InMemoryRateLimiter(false, 1);

        assertTrue(rateLimiter.tryAcquire("client-a"));
        assertTrue(rateLimiter.tryAcquire("client-a"));
    }
}
