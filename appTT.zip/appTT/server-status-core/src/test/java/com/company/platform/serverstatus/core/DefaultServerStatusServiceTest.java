package com.company.platform.serverstatus.core;

import org.junit.jupiter.api.Test;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class DefaultServerStatusServiceTest {

    @Test
    void returnsJvmStatusWithoutExternalDependency() {
        DefaultServerStatusService service = new DefaultServerStatusService("my-application", "Spring Boot");

        ServerStatusResponse response = service.getStatus();

        assertEquals(ServerStatus.UP, response.status());
        assertTrue(response.uptimeSeconds() >= 0);
        assertFalse(response.javaVersion().isBlank());
    }

    @Test
    void sanitizesConfiguredPublicText() {
        Clock clock = Clock.fixed(Instant.parse("2026-08-24T03:00:00Z"), ZoneOffset.UTC);
        DefaultServerStatusService service = new DefaultServerStatusService(
                "name\r\n<script>alert(1)</script>",
                "server\nname",
                clock,
                java.lang.management.ManagementFactory.getRuntimeMXBean()
        );

        ServerStatusResponse response = service.getStatus();

        assertEquals("name<script>alert(1)</script>", response.application());
        assertEquals("servername", response.server());
        assertEquals(Instant.parse("2026-08-24T03:00:00Z"), response.timestamp());
    }
}
