package com.company.platform.serverstatus.core;

public record ServerStatusProbeResponse(ServerStatus status) {
}
