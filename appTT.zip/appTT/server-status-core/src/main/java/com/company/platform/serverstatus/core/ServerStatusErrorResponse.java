package com.company.platform.serverstatus.core;

public record ServerStatusErrorResponse(ServerStatus status, String error) {

    public static ServerStatusErrorResponse genericFailure() {
        return new ServerStatusErrorResponse(ServerStatus.DOWN, "server_status_unavailable");
    }

    public static ServerStatusErrorResponse tooManyRequests() {
        return new ServerStatusErrorResponse(ServerStatus.DOWN, "too_many_requests");
    }

    public static ServerStatusErrorResponse methodNotAllowed() {
        return new ServerStatusErrorResponse(ServerStatus.DOWN, "method_not_allowed");
    }
}
