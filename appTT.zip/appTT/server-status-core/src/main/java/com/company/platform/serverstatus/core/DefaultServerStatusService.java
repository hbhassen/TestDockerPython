package com.company.platform.serverstatus.core;

import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.time.Clock;
import java.time.Instant;
import java.util.Objects;

public final class DefaultServerStatusService implements ServerStatusService {

    private static final int MAX_PUBLIC_TEXT_LENGTH = 120;
    private static final String UNKNOWN = "unknown";

    private final String applicationName;
    private final String serverName;
    private final Clock clock;
    private final RuntimeMXBean runtimeMXBean;

    public DefaultServerStatusService() {
        this(UNKNOWN, "Java");
    }

    public DefaultServerStatusService(String applicationName, String serverName) {
        this(applicationName, serverName, Clock.systemUTC(), ManagementFactory.getRuntimeMXBean());
    }

    public DefaultServerStatusService(
            String applicationName,
            String serverName,
            Clock clock,
            RuntimeMXBean runtimeMXBean
    ) {
        this.applicationName = normalizePublicText(applicationName, UNKNOWN);
        this.serverName = normalizePublicText(serverName, UNKNOWN);
        this.clock = Objects.requireNonNull(clock, "clock must not be null");
        this.runtimeMXBean = Objects.requireNonNull(runtimeMXBean, "runtimeMXBean must not be null");
    }

    @Override
    public ServerStatusResponse getStatus() {
        long uptimeSeconds = Math.max(0, runtimeMXBean.getUptime() / 1_000);
        return new ServerStatusResponse(
                ServerStatus.UP,
                applicationName,
                serverName,
                Runtime.version().toString(),
                uptimeSeconds,
                Instant.now(clock)
        );
    }

    private static String normalizePublicText(String value, String fallback) {
        if (value == null || value.isBlank()) {
            return fallback;
        }
        String normalized = value.codePoints()
                .filter(codePoint -> !Character.isISOControl(codePoint))
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                .toString()
                .trim();
        if (normalized.isBlank()) {
            return fallback;
        }
        if (normalized.length() <= MAX_PUBLIC_TEXT_LENGTH) {
            return normalized;
        }
        return normalized.substring(0, MAX_PUBLIC_TEXT_LENGTH);
    }
}
