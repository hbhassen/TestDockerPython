package com.company.platform.serverstatus.core;

import java.time.Instant;

public record ServerStatusResponse(
        ServerStatus status,
        String application,
        String server,
        String javaVersion,
        long uptimeSeconds,
        Instant timestamp
) {
}
