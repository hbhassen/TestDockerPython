package com.company.platform.serverstatus.core;

public enum ServerStatus {
    UP,
    DOWN
}
