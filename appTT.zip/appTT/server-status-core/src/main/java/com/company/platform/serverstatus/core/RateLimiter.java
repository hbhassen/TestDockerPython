package com.company.platform.serverstatus.core;

public interface RateLimiter {

    boolean tryAcquire(String clientKey);
}
