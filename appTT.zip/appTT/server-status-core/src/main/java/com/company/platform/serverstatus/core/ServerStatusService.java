package com.company.platform.serverstatus.core;

public interface ServerStatusService {

    ServerStatusResponse getStatus();
}
