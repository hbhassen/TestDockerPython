package com.company.platform.serverstatus.core;

import java.util.LinkedHashMap;
import java.util.Map;

public final class HttpSecurityHeaders {

    public static final String X_CONTENT_TYPE_OPTIONS = "X-Content-Type-Options";
    public static final String CACHE_CONTROL = "Cache-Control";
    public static final String REFERRER_POLICY = "Referrer-Policy";
    public static final String PERMISSIONS_POLICY = "Permissions-Policy";

    private HttpSecurityHeaders() {
    }

    public static Map<String, String> defaultHeaders() {
        Map<String, String> headers = new LinkedHashMap<>();
        headers.put(X_CONTENT_TYPE_OPTIONS, "nosniff");
        headers.put(CACHE_CONTROL, "no-store");
        headers.put(REFERRER_POLICY, "no-referrer");
        headers.put(PERMISSIONS_POLICY, "geolocation=(), microphone=(), camera=()");
        return Map.copyOf(headers);
    }
}
