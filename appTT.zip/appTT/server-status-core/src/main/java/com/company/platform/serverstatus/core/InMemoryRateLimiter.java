package com.company.platform.serverstatus.core;

import java.time.Clock;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public final class InMemoryRateLimiter implements RateLimiter {

    private static final String DEFAULT_CLIENT_KEY = "default";
    private static final int MAX_TRACKED_CLIENTS = 4_096;

    private final boolean enabled;
    private final int requestsPerMinute;
    private final Clock clock;
    private final ConcurrentMap<String, Window> windows = new ConcurrentHashMap<>();

    public InMemoryRateLimiter(boolean enabled, int requestsPerMinute) {
        this(enabled, requestsPerMinute, Clock.systemUTC());
    }

    public InMemoryRateLimiter(boolean enabled, int requestsPerMinute, Clock clock) {
        this.enabled = enabled;
        this.requestsPerMinute = Math.max(1, requestsPerMinute);
        this.clock = Objects.requireNonNull(clock, "clock must not be null");
    }

    @Override
    public boolean tryAcquire(String clientKey) {
        if (!enabled) {
            return true;
        }

        String key = normalizeClientKey(clientKey);
        long bucket = clock.instant().getEpochSecond() / 60;
        AtomicBoolean allowed = new AtomicBoolean(false);

        windows.compute(key, (ignored, existing) -> {
            Window current = existing;
            if (current == null || current.minuteBucket != bucket) {
                current = new Window(bucket);
            }
            allowed.set(current.requests.incrementAndGet() <= requestsPerMinute);
            return current;
        });

        if (windows.size() > MAX_TRACKED_CLIENTS) {
            removeExpiredBuckets(bucket);
        }
        return allowed.get();
    }

    private void removeExpiredBuckets(long currentBucket) {
        windows.entrySet().removeIf(entry -> entry.getValue().minuteBucket < currentBucket);
    }

    private static String normalizeClientKey(String clientKey) {
        if (clientKey == null || clientKey.isBlank()) {
            return DEFAULT_CLIENT_KEY;
        }
        return clientKey.strip();
    }

    private static final class Window {
        private final long minuteBucket;
        private final AtomicInteger requests = new AtomicInteger();

        private Window(long minuteBucket) {
            this.minuteBucket = minuteBucket;
        }
    }
}
