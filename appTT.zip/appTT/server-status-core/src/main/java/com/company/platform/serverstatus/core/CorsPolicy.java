package com.company.platform.serverstatus.core;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

public final class CorsPolicy {

    private final boolean enabled;
    private final Set<String> allowedOrigins;

    public CorsPolicy(boolean enabled, Collection<String> allowedOrigins) {
        this.enabled = enabled;
        this.allowedOrigins = normalizeAllowedOrigins(allowedOrigins);
    }

    public static CorsPolicy disabled() {
        return new CorsPolicy(false, Set.of());
    }

    public Optional<String> allowOrigin(String origin) {
        if (!enabled || origin == null || origin.isBlank()) {
            return Optional.empty();
        }
        String candidate = origin.strip();
        if (allowedOrigins.contains(candidate)) {
            return Optional.of(candidate);
        }
        return Optional.empty();
    }

    public boolean enabled() {
        return enabled;
    }

    public Set<String> allowedOrigins() {
        return allowedOrigins;
    }

    private static Set<String> normalizeAllowedOrigins(Collection<String> origins) {
        if (origins == null || origins.isEmpty()) {
            return Set.of();
        }
        Set<String> normalized = new LinkedHashSet<>();
        origins.stream()
                .filter(Objects::nonNull)
                .map(String::strip)
                .filter(origin -> !origin.isBlank())
                .filter(origin -> !"*".equals(origin))
                .forEach(normalized::add);
        return Set.copyOf(normalized);
    }
}
