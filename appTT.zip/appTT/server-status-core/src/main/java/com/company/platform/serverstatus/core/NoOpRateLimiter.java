package com.company.platform.serverstatus.core;

public final class NoOpRateLimiter implements RateLimiter {

    @Override
    public boolean tryAcquire(String clientKey) {
        return true;
    }
}
