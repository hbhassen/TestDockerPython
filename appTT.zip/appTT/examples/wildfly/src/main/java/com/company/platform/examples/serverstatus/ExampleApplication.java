package com.company.platform.examples.serverstatus;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("/")
public class ExampleApplication extends Application {
}
