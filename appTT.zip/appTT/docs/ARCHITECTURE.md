# Architecture

`server-status` uses a strict adapter architecture.

```text
server-status-core
       |
       +-----------------------+
       |                       |
       v                       v
server-status-spring-boot   server-status-wildfly
```

## Core

The core owns:

- `ServerStatus`
- `ServerStatusResponse`
- `ServerStatusProbeResponse`
- `ServerStatusService`
- `DefaultServerStatusService`
- `RateLimiter`
- `InMemoryRateLimiter`
- `CorsPolicy`
- `HttpSecurityHeaders`

The core does not depend on web frameworks or persistence frameworks.

## Spring Boot Adapter

The Spring Boot adapter owns:

- `ServerStatusAutoConfiguration`
- `ServerStatusProperties`
- `ServerStatusController`
- `ServerStatusHeaderFilter`
- `ServerStatusErrorHandler`

It is loaded by Spring Boot 3 through the auto-configuration imports file.

## WildFly Adapter

The WildFly adapter owns:

- `ServerStatusResource`
- `WildFlyServerStatusConfig`
- `ServerStatusExceptionMapper`

It uses Jakarta REST annotations and provided Jakarta APIs.

## Status Flow

`/public/server-status/live`:

1. Route only `GET`.
2. Apply security headers.
3. Apply rate limit.
4. Return `{"status":"UP"}`.

`/public/server-status/ready` follows the same local flow.

`/public/server-status` returns either the minimal status or detailed JVM information depending on configuration.
