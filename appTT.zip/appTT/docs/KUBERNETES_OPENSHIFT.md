# Kubernetes and OpenShift

Recommended probes:

```yaml
livenessProbe:
  httpGet:
    path: /public/server-status/live
    port: 8080
  initialDelaySeconds: 10
  periodSeconds: 10

readinessProbe:
  httpGet:
    path: /public/server-status/ready
    port: 8080
  initialDelaySeconds: 10
  periodSeconds: 10
```

## Liveness

Liveness checks whether the JVM process and HTTP route can answer.

The endpoint does not perform:

- SQL.
- External HTTP calls.
- File reads.
- Shell commands.
- LDAP calls.
- Dynamic expressions.
- Template rendering.

## Readiness

Readiness checks whether the application should receive traffic.

This library provides a safe local readiness response. If the host application needs database, queue, or downstream checks, those checks should be implemented by the host application with parameterized APIs and without accepting public user input.

## Detailed Status

Keep detailed status disabled on public routes unless the host application protects the route with its own security mechanism.
