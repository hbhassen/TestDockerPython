# Dependencies

The project minimizes runtime dependencies.

| Dependency | Scope | Module | Purpose |
| --- | --- | --- | --- |
| `org.slf4j:slf4j-api` | compile | core/adapters | Logging API without forcing a logging backend. |
| `org.springframework.boot:spring-boot-autoconfigure` | compile | Spring adapter | Auto-configuration support. |
| `org.springframework:spring-web` | compile | Spring adapter | REST controller annotations and web filter support. |
| `jakarta.ws.rs:jakarta.ws.rs-api` | provided | WildFly adapter | Jakarta REST annotations and response API supplied by WildFly. |
| `jakarta.enterprise:jakarta.enterprise.cdi-api` | provided | WildFly adapter | CDI scope annotations supplied by WildFly. |
| `jakarta.inject:jakarta.inject-api` | provided | WildFly adapter | Jakarta injection API supplied by WildFly. |
| `jakarta.servlet:jakarta.servlet-api` | provided | WildFly adapter | Servlet request access supplied by WildFly. |
| `org.junit.jupiter:junit-jupiter` | test | tests | Unit and integration tests. |
| `org.springframework.boot:spring-boot-starter-test` | test | Spring adapter | MockMvc, AssertJ, and Spring test utilities. |
| `org.glassfish.jersey.core:jersey-common` | test | WildFly adapter | JAX-RS runtime delegate for local resource tests only. |

## Compatibility

- Java 17 minimum.
- Maven 3.9 minimum.
- Spring Boot 3.x.
- Jakarta REST 3.1.
- WildFly distributions compatible with Jakarta EE 10.

## Vulnerability Review

Run:

```bash
mvn dependency:tree
mvn -Pdependency-check verify
```

The dependency-check profile is optional because vulnerability feed access may require network configuration or API credentials. Set `NVD_API_KEY` outside Git when the NVD API requires authenticated access.
