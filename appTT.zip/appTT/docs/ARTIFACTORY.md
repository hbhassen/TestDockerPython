# Artifactory Publication

The parent POM prepares Maven deployment with:

```xml
<distributionManagement>
    <repository>
        <id>artifactory-releases</id>
        <url>${artifactory.release.url}</url>
    </repository>
    <snapshotRepository>
        <id>artifactory-snapshots</id>
        <url>${artifactory.snapshot.url}</url>
    </snapshotRepository>
</distributionManagement>
```

The URLs are populated from:

```text
ARTIFACTORY_RELEASE_URL
ARTIFACTORY_SNAPSHOT_URL
```

Credentials must be provided outside Git, for example in Maven `settings.xml`:

```xml
<settings>
  <servers>
    <server>
      <id>artifactory-releases</id>
      <username>${env.ARTIFACTORY_USER}</username>
      <password>${env.ARTIFACTORY_TOKEN}</password>
    </server>
    <server>
      <id>artifactory-snapshots</id>
      <username>${env.ARTIFACTORY_USER}</username>
      <password>${env.ARTIFACTORY_TOKEN}</password>
    </server>
  </servers>
  <profiles>
    <profile>
      <id>artifactory</id>
      <properties>
        <artifactory.release.url>${env.ARTIFACTORY_RELEASE_URL}</artifactory.release.url>
        <artifactory.snapshot.url>${env.ARTIFACTORY_SNAPSHOT_URL}</artifactory.snapshot.url>
      </properties>
    </profile>
  </profiles>
  <activeProfiles>
    <activeProfile>artifactory</activeProfile>
  </activeProfiles>
</settings>
```

Deploy snapshots:

```bash
mvn clean deploy
```

Deploy releases only from an approved release branch or tag after validation:

```bash
mvn clean deploy -DskipTests=false
```

Do not store real usernames, passwords, tokens, or repository URLs in Git.
