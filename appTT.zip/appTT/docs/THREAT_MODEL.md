# Threat Model

## Assets

- Server availability.
- Status endpoint integrity.
- Host metadata confidentiality.
- Application secrets.
- Deployment topology.

## Trust Boundaries

- Public HTTP client to application server.
- Reverse proxy to application server.
- Application server to library code.
- CI/CD environment to artifact repository.

The library does not trust client supplied headers such as `X-Forwarded-For` by default.

## Entry Points

- `GET /public/server-status/live`
- `GET /public/server-status/ready`
- `GET /public/server-status`

No endpoint accepts request bodies or required parameters.

## Mitigations

- JSON-only responses.
- Minimal default response.
- Security headers.
- CORS disabled by default.
- CORS exact allowlist when enabled.
- Rate limiting enabled by default.
- Central error responses without stack traces.
- No SQL, LDAP, network, file, shell, expression, or template execution.
- Core module isolated from web and persistence frameworks.

## Residual Risks

- In-memory rate limiting is per JVM and not cluster-wide.
- Host security configuration is outside the library.
- Dependency vulnerability feeds require operational configuration.
- Detailed status can expose Java version and uptime when enabled; protect it in the host application.
