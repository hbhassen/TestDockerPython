package com.company.platform.serverstatus.wildfly;

import com.company.platform.serverstatus.core.HttpSecurityHeaders;
import com.company.platform.serverstatus.core.ServerStatusErrorResponse;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Provider
public class ServerStatusExceptionMapper implements ExceptionMapper<Throwable> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ServerStatusExceptionMapper.class);

    @Override
    public Response toResponse(Throwable exception) {
        LOGGER.warn("Server status endpoint failed with {}", exception.getClass().getName());
        Response.ResponseBuilder builder = Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                .type(MediaType.APPLICATION_JSON_TYPE)
                .entity(ServerStatusErrorResponse.genericFailure());
        HttpSecurityHeaders.defaultHeaders().forEach(builder::header);
        return builder.build();
    }
}
