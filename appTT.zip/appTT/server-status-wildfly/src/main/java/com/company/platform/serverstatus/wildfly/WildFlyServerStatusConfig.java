package com.company.platform.serverstatus.wildfly;

import java.util.Arrays;
import java.util.List;

public final class WildFlyServerStatusConfig {

    private static final String DEFAULT_APPLICATION_NAME = "unknown";

    private final String applicationName;
    private final boolean detailsEnabled;
    private final boolean rateLimitEnabled;
    private final int requestsPerMinute;
    private final boolean corsEnabled;
    private final List<String> allowedOrigins;

    public WildFlyServerStatusConfig(
            String applicationName,
            boolean detailsEnabled,
            boolean rateLimitEnabled,
            int requestsPerMinute,
            boolean corsEnabled,
            List<String> allowedOrigins
    ) {
        this.applicationName = applicationName == null || applicationName.isBlank()
                ? DEFAULT_APPLICATION_NAME
                : applicationName;
        this.detailsEnabled = detailsEnabled;
        this.rateLimitEnabled = rateLimitEnabled;
        this.requestsPerMinute = Math.max(1, requestsPerMinute);
        this.corsEnabled = corsEnabled;
        this.allowedOrigins = allowedOrigins == null ? List.of() : List.copyOf(allowedOrigins);
    }

    public static WildFlyServerStatusConfig fromSystemProperties() {
        return new WildFlyServerStatusConfig(
                System.getProperty("server-status.application-name", DEFAULT_APPLICATION_NAME),
                booleanProperty("server-status.details-enabled", booleanProperty("server-status.details.enabled", false)),
                booleanProperty("server-status.rate-limit.enabled", true),
                intProperty("server-status.rate-limit.requests-per-minute", 100),
                booleanProperty("server-status.cors.enabled", false),
                csvProperty("server-status.cors.allowed-origins")
        );
    }

    public String applicationName() {
        return applicationName;
    }

    public boolean detailsEnabled() {
        return detailsEnabled;
    }

    public boolean rateLimitEnabled() {
        return rateLimitEnabled;
    }

    public int requestsPerMinute() {
        return requestsPerMinute;
    }

    public boolean corsEnabled() {
        return corsEnabled;
    }

    public List<String> allowedOrigins() {
        return allowedOrigins;
    }

    private static boolean booleanProperty(String key, boolean defaultValue) {
        return Boolean.parseBoolean(System.getProperty(key, Boolean.toString(defaultValue)));
    }

    private static int intProperty(String key, int defaultValue) {
        String rawValue = System.getProperty(key);
        if (rawValue == null || rawValue.isBlank()) {
            return defaultValue;
        }
        try {
            return Integer.parseInt(rawValue);
        } catch (NumberFormatException ignored) {
            return defaultValue;
        }
    }

    private static List<String> csvProperty(String key) {
        String rawValue = System.getProperty(key);
        if (rawValue == null || rawValue.isBlank()) {
            return List.of();
        }
        return Arrays.stream(rawValue.split(","))
                .map(String::strip)
                .filter(value -> !value.isBlank())
                .toList();
    }
}
