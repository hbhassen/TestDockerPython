package com.company.platform.serverstatus.wildfly;

import com.company.platform.serverstatus.core.CorsPolicy;
import com.company.platform.serverstatus.core.DefaultServerStatusService;
import com.company.platform.serverstatus.core.HttpSecurityHeaders;
import com.company.platform.serverstatus.core.InMemoryRateLimiter;
import com.company.platform.serverstatus.core.RateLimiter;
import com.company.platform.serverstatus.core.ServerStatus;
import com.company.platform.serverstatus.core.ServerStatusErrorResponse;
import com.company.platform.serverstatus.core.ServerStatusProbeResponse;
import com.company.platform.serverstatus.core.ServerStatusService;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@ApplicationScoped
@Path("/public/server-status")
@Produces(MediaType.APPLICATION_JSON)
public class ServerStatusResource {

    private static final ServerStatusProbeResponse UP_RESPONSE = new ServerStatusProbeResponse(ServerStatus.UP);
    private static final String ORIGIN_HEADER = "Origin";
    private static final String ACCESS_CONTROL_ALLOW_ORIGIN_HEADER = "Access-Control-Allow-Origin";
    private static final String VARY_HEADER = "Vary";

    private final ServerStatusService serverStatusService;
    private final RateLimiter rateLimiter;
    private final CorsPolicy corsPolicy;
    private final boolean detailsEnabled;

    public ServerStatusResource() {
        this(WildFlyServerStatusConfig.fromSystemProperties());
    }

    ServerStatusResource(WildFlyServerStatusConfig config) {
        this(
                new DefaultServerStatusService(config.applicationName(), "WildFly"),
                new InMemoryRateLimiter(config.rateLimitEnabled(), config.requestsPerMinute()),
                new CorsPolicy(config.corsEnabled(), config.allowedOrigins()),
                config.detailsEnabled()
        );
    }

    ServerStatusResource(
            ServerStatusService serverStatusService,
            RateLimiter rateLimiter,
            CorsPolicy corsPolicy,
            boolean detailsEnabled
    ) {
        this.serverStatusService = serverStatusService;
        this.rateLimiter = rateLimiter;
        this.corsPolicy = corsPolicy;
        this.detailsEnabled = detailsEnabled;
    }

    @GET
    @Path("/live")
    public Response live(@Context HttpServletRequest request, @Context HttpHeaders headers) {
        return probeResponse(request, headers);
    }

    @GET
    @Path("/ready")
    public Response ready(@Context HttpServletRequest request, @Context HttpHeaders headers) {
        return probeResponse(request, headers);
    }

    @GET
    public Response status(@Context HttpServletRequest request, @Context HttpHeaders headers) {
        if (isRateLimited(request)) {
            return json(429, ServerStatusErrorResponse.tooManyRequests(), headers);
        }
        Object entity = detailsEnabled ? serverStatusService.getStatus() : UP_RESPONSE;
        return json(Response.Status.OK.getStatusCode(), entity, headers);
    }

    private Response probeResponse(HttpServletRequest request, HttpHeaders headers) {
        if (isRateLimited(request)) {
            return json(429, ServerStatusErrorResponse.tooManyRequests(), headers);
        }
        return json(Response.Status.OK.getStatusCode(), UP_RESPONSE, headers);
    }

    private Response json(int status, Object entity, HttpHeaders requestHeaders) {
        Response.ResponseBuilder builder = Response.status(status)
                .type(MediaType.APPLICATION_JSON_TYPE)
                .entity(entity);

        HttpSecurityHeaders.defaultHeaders().forEach(builder::header);
        String origin = requestHeaders == null ? null : requestHeaders.getHeaderString(ORIGIN_HEADER);
        corsPolicy.allowOrigin(origin).ifPresent(allowedOrigin -> {
            builder.header(ACCESS_CONTROL_ALLOW_ORIGIN_HEADER, allowedOrigin);
            builder.header(VARY_HEADER, ORIGIN_HEADER);
        });
        return builder.build();
    }

    private boolean isRateLimited(HttpServletRequest request) {
        return !rateLimiter.tryAcquire(clientKey(request));
    }

    private static String clientKey(HttpServletRequest request) {
        if (request == null || request.getRemoteAddr() == null || request.getRemoteAddr().isBlank()) {
            return "wildfly";
        }
        return request.getRemoteAddr();
    }
}
