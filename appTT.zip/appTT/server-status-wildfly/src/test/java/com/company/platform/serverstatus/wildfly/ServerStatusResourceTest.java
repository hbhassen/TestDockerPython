package com.company.platform.serverstatus.wildfly;

import com.company.platform.serverstatus.core.InMemoryRateLimiter;
import com.company.platform.serverstatus.core.ServerStatusProbeResponse;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;

class ServerStatusResourceTest {

    @Test
    void liveReturnsJsonWithSecurityHeaders() {
        ServerStatusResource resource = new ServerStatusResource(
                () -> null,
                new InMemoryRateLimiter(false, 1),
                com.company.platform.serverstatus.core.CorsPolicy.disabled(),
                false
        );

        Response response = resource.live(null, null);

        assertEquals(200, response.getStatus());
        assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getMediaType());
        assertEquals("nosniff", response.getHeaderString("X-Content-Type-Options"));
        assertEquals("no-store", response.getHeaderString("Cache-Control"));
        assertInstanceOf(ServerStatusProbeResponse.class, response.getEntity());
    }

    @Test
    void rateLimitReturnsTooManyRequests() {
        ServerStatusResource resource = new ServerStatusResource(
                () -> null,
                new InMemoryRateLimiter(true, 1),
                com.company.platform.serverstatus.core.CorsPolicy.disabled(),
                false
        );

        assertEquals(200, resource.live(null, null).getStatus());
        assertEquals(429, resource.live(null, null).getStatus());
    }
}
