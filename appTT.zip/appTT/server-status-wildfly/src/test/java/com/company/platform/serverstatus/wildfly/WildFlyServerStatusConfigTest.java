package com.company.platform.serverstatus.wildfly;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class WildFlyServerStatusConfigTest {

    @Test
    void usesSecureDefaults() {
        WildFlyServerStatusConfig config = new WildFlyServerStatusConfig(null, false, true, 100, false, null);

        assertEquals("unknown", config.applicationName());
        assertFalse(config.detailsEnabled());
        assertTrue(config.rateLimitEnabled());
        assertEquals(100, config.requestsPerMinute());
        assertFalse(config.corsEnabled());
        assertTrue(config.allowedOrigins().isEmpty());
    }
}
