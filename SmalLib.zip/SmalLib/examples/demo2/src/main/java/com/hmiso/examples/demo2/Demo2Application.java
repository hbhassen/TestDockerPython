package com.hmiso.examples.demo2;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("/api")
public class Demo2Application extends Application {
}
