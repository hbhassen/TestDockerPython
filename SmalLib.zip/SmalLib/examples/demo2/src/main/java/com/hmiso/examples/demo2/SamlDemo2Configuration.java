package com.hmiso.examples.demo2;

import com.hmiso.saml.DefaultSamlServiceProviderFactory;
import com.hmiso.saml.api.SamlServiceProvider;
import com.hmiso.saml.api.SamlServiceProviderFactory;
import com.hmiso.saml.config.SamlConfiguration;

public final class SamlDemo2Configuration {

    public static final String SESSION_ATTRIBUTE_KEY = "saml.principal";

    private SamlDemo2Configuration() {
    }

    public static SamlConfiguration samlConfiguration() {
        return samlConfiguration("/demo2");
    }

    public static SamlConfiguration samlConfiguration(String contextPath) {
        SamlDemo2YamlConfigLoader loader = new SamlDemo2YamlConfigLoader();
        return loader.load(contextPath);
    }

    public static SamlServiceProvider buildServiceProvider() {
        SamlServiceProviderFactory factory = new DefaultSamlServiceProviderFactory();
        return factory.create(samlConfiguration());
    }

    public static SamlServiceProvider buildServiceProvider(String contextPath) {
        SamlServiceProviderFactory factory = new DefaultSamlServiceProviderFactory();
        return factory.create(samlConfiguration(contextPath));
    }

}
