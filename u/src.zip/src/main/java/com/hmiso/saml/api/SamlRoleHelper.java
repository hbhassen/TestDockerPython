package com.hmiso.saml.api;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Helper to extract and validate roles from SAML attributes.
 */
public final class SamlRoleHelper {
    public static final String DEFAULT_ROLE_ATTRIBUTE = SamlAttributeKeys.ROLE;

    private SamlRoleHelper() {
    }

    public static List<String> extractRoles(SamlPrincipal principal) {
        if (principal == null) {
            return List.of();
        }
        return extractRoles(principal.getAttributes());
    }

    public static List<String> extractRoles(Map<String, Object> attributes) {
        if (attributes == null) {
            return List.of();
        }
        Object value = attributes.get(DEFAULT_ROLE_ATTRIBUTE);
        if (value instanceof List<?> list) {
            List<String> roles = new ArrayList<>(list.size());
            for (Object item : list) {
                String role = normalizeRole(item);
                if (role != null) {
                    roles.add(role);
                }
            }
            return List.copyOf(roles);
        }
        String role = normalizeRole(value);
        if (role != null) {
            return List.of(role);
        }
        return List.of();
    }

    public static boolean hasRole(SamlPrincipal principal, String role) {
        if (principal == null) {
            return false;
        }
        String normalized = normalizeRole(role);
        if (normalized == null) {
            return false;
        }
        return extractRoles(principal).stream().anyMatch(normalized::equals);
    }

    private static String normalizeRole(Object value) {
        if (value == null) {
            return null;
        }
        String text = value.toString().trim();
        return text.isEmpty() ? null : text;
    }
}
