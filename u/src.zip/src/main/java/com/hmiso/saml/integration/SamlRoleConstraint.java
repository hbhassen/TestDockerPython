package com.hmiso.saml.integration;

import com.hmiso.saml.api.SamlPrincipal;
import com.hmiso.saml.api.SamlRoleHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * Defines required roles for a protected path.
 */
public final class SamlRoleConstraint {
    private final String path;
    private final List<String> roles;

    public SamlRoleConstraint(String path, List<String> roles) {
        this.path = Objects.requireNonNull(path, "path");
        this.roles = normalizeRoles(roles);
    }

    public String getPath() {
        return path;
    }

    public List<String> getRoles() {
        return roles;
    }

    public boolean matches(String requestUri) {
        if (requestUri == null) {
            return false;
        }
        if (path.endsWith("/*")) {
            String base = path.substring(0, path.length() - 2);
            return requestUri.startsWith(base);
        }
        return requestUri.equals(path);
    }

    public boolean isSatisfiedBy(Set<String> userRoles) {
        if (userRoles == null || userRoles.isEmpty()) {
            return false;
        }
        for (String required : roles) {
            if (userRoles.contains(required)) {
                return true;
            }
        }
        return false;
    }

    public boolean isSatisfiedBy(SamlPrincipal principal) {
        if (principal == null) {
            return false;
        }
        for (String required : roles) {
            if (SamlRoleHelper.hasRole(principal, required)) {
                return true;
            }
        }
        return false;
    }

    private List<String> normalizeRoles(List<String> values) {
        if (values == null) {
            throw new IllegalArgumentException("roles");
        }
        List<String> normalized = new ArrayList<>(values.size());
        for (String value : values) {
            if (value == null) {
                continue;
            }
            String trimmed = value.trim();
            if (!trimmed.isEmpty()) {
                normalized.add(trimmed);
            }
        }
        if (normalized.isEmpty()) {
            throw new IllegalArgumentException("roles");
        }
        return List.copyOf(normalized);
    }
}
