package com.hmiso.saml.config;

/**
 * Types de binding SAML supportés par SmalLib.
 */
public enum BindingType {
    HTTP_REDIRECT,
    HTTP_POST
}
