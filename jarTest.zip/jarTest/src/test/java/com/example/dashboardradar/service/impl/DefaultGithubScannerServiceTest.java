package com.example.dashboardradar.service.impl;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.example.dashboardradar.config.GithubProperties;
import com.example.dashboardradar.service.MetadataAnalyzerService;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.web.reactive.function.client.WebClient;

class DefaultGithubScannerServiceTest {

    @Test
    void addsAuthorizationHeaderWhenTokenProvided() {
        WebClient.Builder builder = mock(WebClient.Builder.class);
        when(builder.baseUrl("https://api.github.com")).thenReturn(builder);
        when(builder.defaultHeader(HttpHeaders.ACCEPT, "application/vnd.github+json")).thenReturn(builder);
        when(builder.defaultHeader(HttpHeaders.AUTHORIZATION, "Bearer tok")).thenReturn(builder);
        WebClient client = mock(WebClient.class);
        when(builder.build()).thenReturn(client);
        MetadataAnalyzerService analyzer = mock(MetadataAnalyzerService.class);

        new DefaultGithubScannerService(builder, new GithubProperties("tok", "org", null, 10), analyzer);

        verify(builder).defaultHeader(HttpHeaders.AUTHORIZATION, "Bearer tok");
    }

    @Test
    void fetchProjectsThrowsWhenOrganizationMissing() {
        WebClient.Builder builder = mock(WebClient.Builder.class);
        when(builder.baseUrl("https://api.github.com")).thenReturn(builder);
        when(builder.defaultHeader(HttpHeaders.ACCEPT, "application/vnd.github+json")).thenReturn(builder);
        WebClient client = mock(WebClient.class);
        when(builder.build()).thenReturn(client);
        MetadataAnalyzerService analyzer = mock(MetadataAnalyzerService.class);
        DefaultGithubScannerService service = new DefaultGithubScannerService(
                builder, new GithubProperties(null, null, null, 10), analyzer);

        assertThatThrownBy(service::fetchProjects)
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("dashboard.github.organization");
    }
}
