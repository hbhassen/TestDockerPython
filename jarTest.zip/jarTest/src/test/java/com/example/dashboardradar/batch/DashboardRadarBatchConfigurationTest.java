package com.example.dashboardradar.batch;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import org.junit.jupiter.api.Test;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.transaction.PlatformTransactionManager;

class DashboardRadarBatchConfigurationTest {

    @Test
    void buildsJobAndStep() {
        DashboardRadarBatchConfiguration config = new DashboardRadarBatchConfiguration();
        JobRepository jobRepository = mock(JobRepository.class);
        PlatformTransactionManager tx = mock(PlatformTransactionManager.class);
        AuditTasklet tasklet = mock(AuditTasklet.class);

        Step step = config.auditStep(jobRepository, tx, tasklet);
        Job job = config.dashboardRadarJob(jobRepository, step);

        assertThat(step.getName()).isEqualTo("auditStep");
        assertThat(job.getName()).isEqualTo("dashboardRadarJob");
    }
}
