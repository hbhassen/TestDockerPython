package com.example.dashboardradar.service;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

class ProviderSelectionManagerTest {

    private final ProviderSelectionManager manager = new ProviderSelectionManager();

    @AfterEach
    void clear() {
        manager.clear();
    }

    @Test
    void normalizesAndStoresProviders() {
        manager.selectProviders(List.of(" GitHub ", "gitLab", "github"));

        Optional<Set<String>> selection = manager.getSelectedProviders();

        assertThat(selection).isPresent();
        assertThat(selection.get()).containsExactly("github", "gitlab");
    }

    @Test
    void clearsSelectionWhenEmptyInput() {
        manager.selectProviders(List.of());

        assertThat(manager.getSelectedProviders()).isEmpty();
    }

    @Test
    void parsesCommaSeparatedProviders() {
        manager.selectProviders("github,gitlab");

        assertThat(manager.getSelectedProviders()).contains(Set.of("github", "gitlab"));
    }
}
