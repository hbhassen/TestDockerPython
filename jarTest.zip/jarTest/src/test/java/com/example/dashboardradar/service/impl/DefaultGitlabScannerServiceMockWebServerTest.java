package com.example.dashboardradar.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.example.dashboardradar.config.GitlabProperties;
import com.example.dashboardradar.model.ProjectSnapshot;
import com.example.dashboardradar.service.MetadataAnalyzerService;
import okhttp3.mockwebserver.Dispatcher;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import java.io.IOException;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.web.reactive.function.client.WebClient;

class DefaultGitlabScannerServiceMockWebServerTest {

    private MockWebServer server;

    @BeforeEach
    void setUp() throws IOException {
        server = new MockWebServer();
        server.setDispatcher(new GitlabDispatcher());
        server.start();
    }

    @AfterEach
    void tearDown() throws IOException {
        server.shutdown();
    }

    @Test
    void fetchProjectsAggregatesGitlabData() {
        String baseUrl = server.url("/").toString();
        GitlabProperties properties = new GitlabProperties("tok", "mygroup", baseUrl.substring(0, baseUrl.length() - 1), 50, true);
        MetadataAnalyzerService analyzer = mock(MetadataAnalyzerService.class);
        when(analyzer.enrichWithStructure(org.mockito.ArgumentMatchers.any())).thenAnswer(inv -> inv.getArgument(0));

        DefaultGitlabScannerService service = new DefaultGitlabScannerService(WebClient.builder(), properties, analyzer);

        List<ProjectSnapshot> projects = service.fetchProjects();

        assertThat(projects).hasSize(1);
        ProjectSnapshot snapshot = projects.get(0);
        assertThat(snapshot.fullName()).isEqualTo("mygroup/demo");
        assertThat(snapshot.frameworks()).contains("org.springframework.boot:spring-boot-starter:3.2.0");
        assertThat(snapshot.languages()).containsEntry("Java", 100.0);
        assertThat(snapshot.repositoryFiles()).contains("src/Main.java");
    }

    private static final class GitlabDispatcher extends Dispatcher {
        @Override
        public MockResponse dispatch(RecordedRequest request) {
            String path = request.getPath();
            if (path.startsWith("/projects?")) {
                return json("""
                        [
                          {"id":1,"name":"demo","path_with_namespace":"mygroup/demo","namespace":{"full_path":"mygroup"},"archived":false,"last_activity_at":"2024-01-01T00:00:00Z","default_branch":"main"}
                        ]
                        """);
            }
            if (path.startsWith("/projects/1/repository/branches")) {
                return json("""
                        [
                          {"name":"main","protected":true,"commit":{"committed_date":"2024-01-01T00:00:00Z"}}
                        ]
                        """);
            }
            if (path.startsWith("/projects/1/merge_requests")) {
                return json("""
                        [
                          {"id":5,"title":"MR","author":{"username":"alice"},"reviewers":[{"username":"bob"}],"created_at":"2024-01-01T00:00:00Z","updated_at":"2024-01-02T00:00:00Z","state":"opened"}
                        ]
                        """);
            }
            if (path.startsWith("/projects/1/languages")) {
                return json("""
                        {"Java":100}
                        """);
            }
            if (path.startsWith("/projects/1/repository/files/pom.xml/raw")) {
                String pom = """
                        <project>
                          <dependencies>
                            <dependency>
                              <groupId>org.springframework.boot</groupId>
                              <artifactId>spring-boot-starter</artifactId>
                              <version>3.2.0</version>
                            </dependency>
                          </dependencies>
                        </project>
                        """;
                return new MockResponse().setBody(pom);
            }
            if (path.startsWith("/projects/1/repository/files/build.gradle/raw")) {
                return new MockResponse().setResponseCode(500);
            }
            if (path.startsWith("/projects/1/repository/files/package.json/raw")) {
                return new MockResponse().setBody("");
            }
            if (path.startsWith("/projects/1/repository/tree")) {
                return json("""
                        [{"path":"src/Main.java"}]
                        """);
            }
            return new MockResponse().setResponseCode(404);
        }

        private MockResponse json(String body) {
            return new MockResponse().setHeader("Content-Type", "application/json").setBody(body);
        }
    }
}
