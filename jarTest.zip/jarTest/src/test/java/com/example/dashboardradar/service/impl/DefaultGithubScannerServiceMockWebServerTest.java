package com.example.dashboardradar.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.example.dashboardradar.config.GithubProperties;
import com.example.dashboardradar.model.ProjectSnapshot;
import com.example.dashboardradar.service.MetadataAnalyzerService;
import okhttp3.mockwebserver.Dispatcher;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.web.reactive.function.client.WebClient;

class DefaultGithubScannerServiceMockWebServerTest {

    private MockWebServer server;

    @BeforeEach
    void setUp() throws IOException {
        server = new MockWebServer();
        server.setDispatcher(new GithubDispatcher());
        server.start();
    }

    @AfterEach
    void tearDown() throws IOException {
        server.shutdown();
    }

    @Test
    void fetchProjectsAggregatesGitHubData() {
        String baseUrl = server.url("/").toString();
        GithubProperties properties = new GithubProperties(null, "myorg", baseUrl.substring(0, baseUrl.length() - 1), 50);
        MetadataAnalyzerService analyzer = mock(MetadataAnalyzerService.class);
        when(analyzer.enrichWithStructure(org.mockito.ArgumentMatchers.any())).thenAnswer(inv -> inv.getArgument(0));

        DefaultGithubScannerService service = new DefaultGithubScannerService(WebClient.builder(), properties, analyzer);

        List<ProjectSnapshot> projects = service.fetchProjects();

        assertThat(projects).hasSize(1);
        ProjectSnapshot snapshot = projects.get(0);
        assertThat(snapshot.fullName()).isEqualTo("myorg/demo");
        assertThat(snapshot.frameworks()).contains("org.springframework.boot:spring-boot-starter:3.2.0");
        assertThat(snapshot.languages()).containsEntry("Java", 100.0);
        assertThat(snapshot.repositoryFiles()).contains("src/Main.java");
    }

    private static final class GithubDispatcher extends Dispatcher {
        @Override
        public MockResponse dispatch(RecordedRequest request) {
            String path = request.getPath();
            if (path.startsWith("/orgs/myorg/repos")) {
                return json("""
                        [
                          {"id":1,"name":"demo","full_name":"myorg/demo","owner":{"login":"myorg"},"archived":false,"updated_at":"2024-01-01T00:00:00Z","default_branch":"main"}
                        ]
                        """);
            }
            if (path.contains("/repos/myorg%2Fdemo/branches")) {
                return json("""
                        [
                          {"name":"main","protected":true,"commit":{"commit":{"author":{"date":"2024-01-01T00:00:00Z"}}}}
                        ]
                        """);
            }
            if (path.contains("/repos/myorg%2Fdemo/pulls")) {
                return json("""
                        [
                          {"id":10,"title":"PR","user":{"login":"alice"},"requested_reviewers":[{"login":"bob"}],"created_at":"2024-01-01T00:00:00Z","updated_at":"2024-01-02T00:00:00Z","state":"open"}
                        ]
                        """);
            }
            if (path.contains("/repos/myorg%2Fdemo/languages")) {
                return json("""
                        {"Java":100}
                        """);
            }
            if (path.contains("/repos/myorg%2Fdemo/contents/pom.xml")) {
                String pom = """
                        <project>
                          <dependencies>
                            <dependency>
                              <groupId>org.springframework.boot</groupId>
                              <artifactId>spring-boot-starter</artifactId>
                              <version>3.2.0</version>
                            </dependency>
                          </dependencies>
                        </project>
                        """;
                String encoded = Base64.getEncoder().encodeToString(pom.getBytes(StandardCharsets.UTF_8));
                return json("""
                        {"name":"pom.xml","content":"%s"}
                        """.formatted(encoded));
            }
            if (path.contains("/repos/myorg%2Fdemo/contents/build.gradle")) {
                return new MockResponse().setResponseCode(500);
            }
            if (path.contains("/repos/myorg%2Fdemo/contents/package.json")) {
                return json("""
                        {"name":"file","content":""}
                        """);
            }
            if (path.contains("/repos/myorg%2Fdemo/git/trees/")) {
                return json("""
                        {"tree":[{"path":"src/Main.java"}]}
                        """);
            }
            return new MockResponse().setResponseCode(404);
        }

        private MockResponse json(String body) {
            return new MockResponse().setHeader("Content-Type", "application/json").setBody(body);
        }
    }
}
