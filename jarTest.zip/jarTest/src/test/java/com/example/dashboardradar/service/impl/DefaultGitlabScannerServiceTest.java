package com.example.dashboardradar.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.example.dashboardradar.config.GitlabProperties;
import com.example.dashboardradar.service.MetadataAnalyzerService;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.web.reactive.function.client.WebClient;

class DefaultGitlabScannerServiceTest {

    @Test
    void skipsWhenNoGroupConfigured() {
        WebClient.Builder builder = mock(WebClient.Builder.class);
        when(builder.baseUrl(org.mockito.ArgumentMatchers.anyString())).thenReturn(builder);
        when(builder.defaultHeader("PRIVATE-TOKEN", "token")).thenReturn(builder);
        WebClient client = mock(WebClient.class);
        when(builder.build()).thenReturn(client);
        MetadataAnalyzerService analyzer = mock(MetadataAnalyzerService.class);

        GitlabProperties properties = new GitlabProperties("token", null, null, 20, true);
        DefaultGitlabScannerService service = new DefaultGitlabScannerService(builder, properties, analyzer);

        List<?> result = service.fetchProjects();

        assertThat(result).isEmpty();
    }

    @Test
    void setsPrivateTokenHeaderWhenProvided() {
        WebClient.Builder builder = mock(WebClient.Builder.class);
        when(builder.baseUrl("https://gitlab.com/api/v4")).thenReturn(builder);
        when(builder.defaultHeader("PRIVATE-TOKEN", "tok")).thenReturn(builder);
        WebClient client = mock(WebClient.class);
        when(builder.build()).thenReturn(client);
        MetadataAnalyzerService analyzer = mock(MetadataAnalyzerService.class);

        new DefaultGitlabScannerService(builder, new GitlabProperties("tok", "group", null, 10, false), analyzer);

        verify(builder).defaultHeader("PRIVATE-TOKEN", "tok");
    }
}
