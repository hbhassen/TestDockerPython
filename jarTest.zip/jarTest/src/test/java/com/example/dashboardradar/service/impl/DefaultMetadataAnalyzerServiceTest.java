package com.example.dashboardradar.service.impl;

import static org.assertj.core.api.Assertions.assertThat;

import com.example.dashboardradar.config.StructureRulesProperties;
import com.example.dashboardradar.model.BranchSnapshot;
import com.example.dashboardradar.model.MergeRequestSnapshot;
import com.example.dashboardradar.model.ProjectSnapshot;
import com.example.dashboardradar.model.RepositoryStructure;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.Test;

class DefaultMetadataAnalyzerServiceTest {

    private static ProjectSnapshot sampleSnapshot(List<String> frameworks, List<String> files) {
        return new ProjectSnapshot(
                "id",
                "demo",
                "org/demo",
                "org",
                false,
                OffsetDateTime.now(),
                List.of(new BranchSnapshot("main", true, true, OffsetDateTime.now())),
                List.of(new MergeRequestSnapshot(1, "mr", "user", List.of(), OffsetDateTime.now(), OffsetDateTime.now(), "open")),
                Map.of("Java", 100.0),
                frameworks,
                files,
                new RepositoryStructure(List.of(), List.of(), List.of())
        );
    }

    @Test
    void enrichesStructureWhenRuleMatchesLanguagesAndFrameworks() {
        StructureRulesProperties.StackRule javaRule = new StructureRulesProperties.StackRule(
                List.of("src/main/java", "src/test/java"),
                List.of(".github/workflows/build.yml"),
                List.of("forbidden-lib"),
                List.of("spring-boot"),
                List.of("java")
        );
        StructureRulesProperties properties = new StructureRulesProperties(Map.of("java-stack", javaRule));
        DefaultMetadataAnalyzerService service = new DefaultMetadataAnalyzerService(properties);

        ProjectSnapshot snapshot = sampleSnapshot(
                List.of("spring-boot"),
                List.of("src/main/java/com/example/App.java", ".github/workflows/build.yml")
        );

        ProjectSnapshot enriched = service.enrichWithStructure(snapshot);

        assertThat(enriched.structure().expectedPathsPresent()).containsExactly("src/main/java");
        assertThat(enriched.structure().missingPaths()).containsExactly("src/test/java");
        assertThat(enriched.structure().ciFiles()).containsExactly(".github/workflows/build.yml");
    }

    @Test
    void returnsSnapshotUnchangedWhenForbiddenFrameworkPresent() {
        StructureRulesProperties.StackRule rule = new StructureRulesProperties.StackRule(
                List.of("src"),
                List.of(),
                List.of("banned"),
                List.of("spring-boot"),
                List.of("java")
        );
        StructureRulesProperties properties = new StructureRulesProperties(Map.of("java-stack", rule));
        DefaultMetadataAnalyzerService service = new DefaultMetadataAnalyzerService(properties);

        ProjectSnapshot snapshot = sampleSnapshot(
                List.of("banned:lib:1.0.0"),
                List.of("src/Main.java")
        );

        ProjectSnapshot enriched = service.enrichWithStructure(snapshot);

        assertThat(enriched).isSameAs(snapshot);
    }
}
