package com.example.dashboardradar.config;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class GithubPropertiesTest {

    @Test
    void suppliesDefaultsWhenMissing() {
        GithubProperties properties = new GithubProperties(null, "org", null, 0);

        assertThat(properties.baseUrl()).isEqualTo("https://api.github.com");
        assertThat(properties.pageSize()).isEqualTo(50);
    }
}
