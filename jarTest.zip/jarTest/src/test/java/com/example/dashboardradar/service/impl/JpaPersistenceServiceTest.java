package com.example.dashboardradar.service.impl;

import static org.assertj.core.api.Assertions.assertThat;

import com.example.dashboardradar.model.BranchSnapshot;
import com.example.dashboardradar.model.ComplianceReport;
import com.example.dashboardradar.model.MergeRequestSnapshot;
import com.example.dashboardradar.model.ObsolescenceReport;
import com.example.dashboardradar.model.ProjectAudit;
import com.example.dashboardradar.model.ProjectSnapshot;
import com.example.dashboardradar.model.RepositoryStructure;
import com.example.dashboardradar.repository.ProjectRepository;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;

@DataJpaTest
@Import(JpaPersistenceService.class)
@TestPropertySource(properties = {
        "spring.jpa.hibernate.ddl-auto=create-drop",
        "spring.datasource.url=jdbc:h2:mem:db;MODE=PostgreSQL;DB_CLOSE_DELAY=-1",
        "spring.datasource.driverClassName=org.h2.Driver",
        "spring.datasource.username=sa",
        "spring.datasource.password="
})
class JpaPersistenceServiceTest {

    @Autowired
    private JpaPersistenceService persistenceService;

    @Autowired
    private ProjectRepository projectRepository;

    @Test
    void persistsFullAuditGraph() {
        ProjectSnapshot snapshot = new ProjectSnapshot(
                "id1",
                "demo",
                "group/demo",
                "group",
                false,
                OffsetDateTime.now(),
                List.of(new BranchSnapshot("main", true, true, OffsetDateTime.now())),
                List.of(new MergeRequestSnapshot(1, "mr", "author", List.of("rev"), OffsetDateTime.now(), OffsetDateTime.now(), "open")),
                Map.of("Java", 95.0),
                List.of("org.springframework.boot:spring-boot-starter:3.2.0"),
                List.of("Jenkinsfile", "Dockerfile", "src/Main.java"),
                new RepositoryStructure(List.of(), List.of(), List.of())
        );
        ComplianceReport compliance = new ComplianceReport(
                snapshot.structure(),
                List.of(),
                List.of(),
                true
        );
        ObsolescenceReport obsolescence = new ObsolescenceReport(
                List.of(new ObsolescenceReport.ComponentStatus(
                        "spring-boot",
                        "3.2.0",
                        "3.0.0",
                        null,
                        null,
                        "MINOR",
                        "COMPLIANT"
                ))
        );
        persistenceService.persist(new ProjectAudit(snapshot, compliance, obsolescence));

        var stored = projectRepository.findById("id1").orElseThrow();
        assertThat(stored.getBranches()).hasSize(1);
        assertThat(stored.getMergeRequests()).hasSize(1);
        assertThat(stored.getTechStacks()).anyMatch(ts -> "org.springframework.boot:spring-boot-starter".equals(ts.getFramework())
                && "3.2.0".equals(ts.getVersion()));
        assertThat(stored.getObsolescences()).singleElement()
                .extracting(o -> o.getComponent())
                .isEqualTo("spring-boot");
        assertThat(stored.getFileChecks()).singleElement()
                .extracting(fc -> fc.isHasCiFile())
                .isEqualTo(true);
    }
}
