package com.example.dashboardradar.service.impl;

import static org.assertj.core.api.Assertions.assertThat;

import com.example.dashboardradar.config.ObsolescenceMatrixProperties;
import com.example.dashboardradar.config.ObsolescenceMatrixProperties.ComponentRule;
import com.example.dashboardradar.config.ObsolescenceMatrixProperties.Severity;
import com.example.dashboardradar.model.ProjectSnapshot;
import com.example.dashboardradar.model.RepositoryStructure;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

class DefaultObsolescenceDetectorServiceAdditionalTest {

    private static ObsolescenceMatrixProperties propertiesForRule(ComponentRule rule) {
        ObsolescenceMatrixProperties properties = new ObsolescenceMatrixProperties();
        properties.setComponents(Map.of(rule.component(), rule));
        return properties;
    }

    private static ProjectSnapshot snapshotWithFramework(String frameworkDescriptor) {
        return new ProjectSnapshot(
                "id",
                "demo",
                "group/demo",
                "group",
                false,
                OffsetDateTime.now(),
                List.of(),
                List.of(),
                Map.of("Java", 100.0),
                frameworkDescriptor == null ? List.of() : List.of(frameworkDescriptor),
                List.of(),
                new RepositoryStructure(List.of(), List.of(), List.of())
        );
    }

    @Test
    void marksEndOfSupportWhenDatePassed() {
        LocalDate past = LocalDate.now().minusDays(1);
        ComponentRule rule = new ComponentRule("spring-boot", "3.0.0", null, past.toString(), Severity.MAJOR);
        DefaultObsolescenceDetectorService service = new DefaultObsolescenceDetectorService(propertiesForRule(rule));

        var report = service.detect(snapshotWithFramework("org.springframework.boot:spring-boot-starter:3.2.0"));

        assertThat(report.components()).singleElement()
                .extracting(c -> c.status())
                .isEqualTo("END_OF_SUPPORT");
    }

    @Test
    void marksDeprecatedWhenAfterDeprecatedBeforeDate() {
        LocalDate deprecatedDate = LocalDate.now().minusDays(1);
        LocalDate futureEnd = LocalDate.now().plusDays(10);
        ComponentRule rule = new ComponentRule("spring-boot", "3.0.0", deprecatedDate.toString(), futureEnd.toString(), Severity.MINOR);
        DefaultObsolescenceDetectorService service = new DefaultObsolescenceDetectorService(propertiesForRule(rule));

        var report = service.detect(snapshotWithFramework("org.springframework.boot:spring-boot-starter:3.2.0"));

        assertThat(report.components()).singleElement()
                .extracting(c -> c.status())
                .isEqualTo("DEPRECATED");
    }

    @Test
    void marksUnknownVersionWhenNoVersionResolvable() {
        LocalDate future = LocalDate.now().plusDays(30);
        ComponentRule rule = new ComponentRule("java", "17", null, future.toString(), Severity.MODERATE);
        DefaultObsolescenceDetectorService service = new DefaultObsolescenceDetectorService(propertiesForRule(rule));

        var report = service.detect(snapshotWithFramework("java"));

        assertThat(report.components()).singleElement()
                .extracting(c -> c.status())
                .isEqualTo("UNKNOWN_VERSION");
    }

    @Test
    void marksCompliantWhenAboveMinimumAndNotDeprecated() {
        LocalDate future = LocalDate.now().plusDays(30);
        ComponentRule rule = new ComponentRule("spring-boot", "3.0.0", future.toString(), future.toString(), Severity.MINOR);
        DefaultObsolescenceDetectorService service = new DefaultObsolescenceDetectorService(propertiesForRule(rule));

        var report = service.detect(snapshotWithFramework("org.springframework.boot:spring-boot-starter:3.2.0"));

        assertThat(report.components()).singleElement()
                .extracting(c -> c.status())
                .isEqualTo("COMPLIANT");
    }
}
