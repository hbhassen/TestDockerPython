package com.example.dashboardradar.config;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import org.junit.jupiter.api.Test;

class SourceControlPropertiesTest {

    @Test
    void defaultsToGithubWhenEmpty() {
        SourceControlProperties properties = new SourceControlProperties(null);

        assertThat(properties.enabledProviders()).containsExactly("github");
    }

    @Test
    void trimsAndFiltersBlankEntries() {
        SourceControlProperties properties = new SourceControlProperties(List.of(" github ", " ", "gitlab"));

        assertThat(properties.enabledProviders()).containsExactly("github", "gitlab");
    }
}
