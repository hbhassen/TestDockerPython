package com.example.dashboardradar.batch;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.sql.DataSource;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.boot.DefaultApplicationArguments;

class DashboardRadarJobLauncherTest {

    @Test
    void runsJobWhenSchemaIsReadyAndProvidersSpecified() throws Exception {
        DataSource dataSource = mock(DataSource.class);
        Connection connection = mock(Connection.class);
        Statement statement = mock(Statement.class);
        ResultSet resultSet = mock(ResultSet.class);
        when(dataSource.getConnection()).thenReturn(connection);
        when(connection.createStatement()).thenReturn(statement);
        when(statement.executeQuery(any())).thenReturn(resultSet);
        when(resultSet.next()).thenReturn(true);
        when(resultSet.getInt(1)).thenReturn(1);

        JobLauncher jobLauncher = mock(JobLauncher.class);
        Job job = mock(Job.class);
        DashboardRadarJobLauncher runner = new DashboardRadarJobLauncher(jobLauncher, job, dataSource);

        DefaultApplicationArguments args = new DefaultApplicationArguments("--providers=github,gitlab");

        runner.run(args);

        ArgumentCaptor<JobParameters> paramsCaptor = ArgumentCaptor.forClass(JobParameters.class);
        verify(jobLauncher).run(eq(job), paramsCaptor.capture());
        JobParameters parameters = paramsCaptor.getValue();

        assertThat(parameters.getParameters()).containsKey("timestamp");
        assertThat(parameters.getString("providers")).isEqualTo("github,gitlab");
    }
}
