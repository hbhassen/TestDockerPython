package com.example.dashboardradar.batch;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.example.dashboardradar.model.BranchSnapshot;
import com.example.dashboardradar.model.MergeRequestSnapshot;
import com.example.dashboardradar.model.ObsolescenceReport;
import com.example.dashboardradar.model.ProjectAudit;
import com.example.dashboardradar.model.ProjectSnapshot;
import com.example.dashboardradar.model.RepositoryStructure;
import com.example.dashboardradar.service.ComplianceCheckerService;
import com.example.dashboardradar.service.ObsolescenceDetectorService;
import com.example.dashboardradar.service.PersistenceService;
import com.example.dashboardradar.service.ProjectScanner;
import com.example.dashboardradar.service.ProviderSelectionManager;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.repeat.RepeatStatus;

class AuditTaskletTest {

    @Test
    void executesPipelineAndAppliesProviderSelection() throws Exception {
        ProjectScanner scanner = mock(ProjectScanner.class);
        ComplianceCheckerService compliance = mock(ComplianceCheckerService.class);
        ObsolescenceDetectorService obsolescence = mock(ObsolescenceDetectorService.class);
        PersistenceService persistence = mock(PersistenceService.class);
        ProviderSelectionManager selection = mock(ProviderSelectionManager.class);

        ProjectSnapshot snapshot = new ProjectSnapshot(
                "1",
                "demo",
                "org/demo",
                "org",
                false,
                OffsetDateTime.now(),
                List.of(new BranchSnapshot("main", true, true, OffsetDateTime.now())),
                List.of(new MergeRequestSnapshot(1, "mr", "user", List.of(), OffsetDateTime.now(), OffsetDateTime.now(), "open")),
                Map.of("Java", 100.0),
                List.of("spring-boot"),
                List.of(),
                new RepositoryStructure(List.of(), List.of(), List.of())
        );
        when(scanner.fetchProjects()).thenReturn(List.of(snapshot));
        when(obsolescence.detect(snapshot)).thenReturn(new ObsolescenceReport(List.of()));

        AuditTasklet tasklet = new AuditTasklet(scanner, compliance, obsolescence, persistence, selection);

        JobExecution jobExecution = new JobExecution(1L, new JobParametersBuilder()
                .addString("providers", "gitlab")
                .toJobParameters());
        StepExecution stepExecution = new StepExecution("step", jobExecution);
        StepContribution contribution = new StepContribution(stepExecution);
        ChunkContext chunkContext = new ChunkContext(new StepContext(stepExecution));

        RepeatStatus status = tasklet.execute(contribution, chunkContext);

        assertThat(status).isEqualTo(RepeatStatus.FINISHED);
        verify(selection).selectProviders("gitlab");
        verify(selection).clear();
        ArgumentCaptor<ProjectAudit> auditCaptor = ArgumentCaptor.forClass(ProjectAudit.class);
        verify(persistence).persist(auditCaptor.capture());
        assertThat(auditCaptor.getValue().snapshot().id()).isEqualTo("1");
    }
}
