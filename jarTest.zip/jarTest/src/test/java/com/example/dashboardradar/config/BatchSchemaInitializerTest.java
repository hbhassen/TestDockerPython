package com.example.dashboardradar.config;

import static org.assertj.core.api.Assertions.assertThat;

import javax.sql.DataSource;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

class BatchSchemaInitializerTest {

    @Test
    void initializesBatchSchemaOnH2WithPostgresMode() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("org.h2.Driver");
        dataSource.setUrl("jdbc:h2:mem:batch;MODE=PostgreSQL;DB_CLOSE_DELAY=-1");
        dataSource.setUsername("sa");
        dataSource.setPassword("");

        BatchSchemaInitializer initializer = new BatchSchemaInitializer(dataSource);
        initializer.init();

        JdbcTemplate jdbc = new JdbcTemplate(dataSource);
        Integer count = jdbc.queryForObject(
                "select count(*) from information_schema.tables where table_name = 'BATCH_JOB_INSTANCE'",
                Integer.class);
        assertThat(count).isNotNull();
        assertThat(count).isGreaterThan(0);
    }
}
