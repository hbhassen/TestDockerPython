package com.example.dashboardradar.config;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class GitlabPropertiesTest {

    @Test
    void suppliesDefaultsWhenMissing() {
        GitlabProperties properties = new GitlabProperties(null, "group", null, 0, false);

        assertThat(properties.baseUrl()).isEqualTo("https://gitlab.com/api/v4");
        assertThat(properties.pageSize()).isEqualTo(50);
    }
}
