package com.example.dashboardradar.util;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import org.junit.jupiter.api.Test;

class XmlFrameworkExtractorTest {

    @Test
    void extractsDependenciesParentAndJavaVersion() {
        String pom = """
                <project>
                  <parent>
                    <groupId>org.springframework.boot</groupId>
                    <artifactId>spring-boot-starter-parent</artifactId>
                    <version>3.2.0</version>
                  </parent>
                  <properties>
                    <java.version>17</java.version>
                  </properties>
                  <dependencies>
                    <dependency>
                      <groupId>org.springframework.boot</groupId>
                      <artifactId>spring-boot-starter-web</artifactId>
                      <version>3.2.0</version>
                    </dependency>
                    <dependency>
                      <groupId>com.fasterxml.jackson.core</groupId>
                      <artifactId>jackson-databind</artifactId>
                    </dependency>
                  </dependencies>
                </project>
                """;

        List<String> frameworks = XmlFrameworkExtractor.extractFromPom(pom);

        assertThat(frameworks).contains(
                "org.springframework.boot:spring-boot-starter-parent:3.2.0",
                "org.springframework.boot:spring-boot-starter-web:3.2.0",
                "com.fasterxml.jackson.core:jackson-databind",
                "java:17"
        );
    }
}
