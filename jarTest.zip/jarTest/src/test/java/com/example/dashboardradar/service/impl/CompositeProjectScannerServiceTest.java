package com.example.dashboardradar.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.example.dashboardradar.config.SourceControlProperties;
import com.example.dashboardradar.model.ProjectSnapshot;
import com.example.dashboardradar.service.PlatformProjectScanner;
import com.example.dashboardradar.service.ProviderSelectionManager;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import org.junit.jupiter.api.Test;

class CompositeProjectScannerServiceTest {

    private static ProjectSnapshot snapshot(String id) {
        return new ProjectSnapshot(
                id,
                "name-" + id,
                "full-" + id,
                "group",
                false,
                OffsetDateTime.now(),
                List.of(),
                List.of(),
                Map.of(),
                List.of(),
                List.of(),
                null
        );
    }

    @Test
    void usesSelectedProvidersWhenPresent() {
        PlatformProjectScanner github = mock(PlatformProjectScanner.class);
        when(github.provider()).thenReturn("github");
        when(github.fetchProjects()).thenReturn(List.of(snapshot("g1")));

        PlatformProjectScanner gitlab = mock(PlatformProjectScanner.class);
        when(gitlab.provider()).thenReturn("gitlab");
        when(gitlab.fetchProjects()).thenReturn(List.of(snapshot("l1"), snapshot("l2")));

        ProviderSelectionManager selectionManager = mock(ProviderSelectionManager.class);
        when(selectionManager.getSelectedProviders()).thenReturn(Optional.of(Set.of("gitlab")));

        CompositeProjectScannerService service = new CompositeProjectScannerService(
                List.of(github, gitlab),
                new SourceControlProperties(List.of("github", "gitlab")),
                selectionManager
        );

        List<ProjectSnapshot> result = service.fetchProjects();

        assertThat(result).extracting(ProjectSnapshot::id).containsExactly("l1", "l2");
    }

    @Test
    void fallsBackToConfiguredProvidersWhenNoSelection() {
        PlatformProjectScanner github = mock(PlatformProjectScanner.class);
        when(github.provider()).thenReturn("github");
        when(github.fetchProjects()).thenReturn(List.of(snapshot("g1")));

        ProviderSelectionManager selectionManager = mock(ProviderSelectionManager.class);
        when(selectionManager.getSelectedProviders()).thenReturn(Optional.empty());

        CompositeProjectScannerService service = new CompositeProjectScannerService(
                List.of(github),
                new SourceControlProperties(List.of("github")),
                selectionManager
        );

        List<ProjectSnapshot> result = service.fetchProjects();

        assertThat(result).extracting(ProjectSnapshot::id).containsExactly("g1");
    }
}
