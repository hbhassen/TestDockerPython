package com.example.dashboardradar.obsolescence.model;

public enum ObsolescenceSeverity {
    LOW,
    MODERATE,
    MAJOR,
    CRITICAL
}
