package com.example.dashboardradar.batch;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Component
public class DashboardRadarJobLauncher implements ApplicationRunner {

    private static final Logger LOGGER = LoggerFactory.getLogger(DashboardRadarJobLauncher.class);

    private final JobLauncher jobLauncher;
    private final Job dashboardRadarJob;
    private final DataSource dataSource;

    public DashboardRadarJobLauncher(JobLauncher jobLauncher, Job dashboardRadarJob, DataSource dataSource) {
        this.jobLauncher = jobLauncher;
        this.dashboardRadarJob = dashboardRadarJob;
        this.dataSource = dataSource;
    }

    @Override
    public void run(ApplicationArguments args) throws Exception {
        LOGGER.info("⏳ Vérification de la présence du schéma Spring Batch...");

        waitForBatchSchema();

        LOGGER.info("🚀 Lancement du batch Dashboard Radar...");
        JobParametersBuilder parametersBuilder = new JobParametersBuilder()
                .addLong("timestamp", Instant.now().toEpochMilli());
        extractProviderSelection(args).ifPresent(providers -> {
            LOGGER.info("Lancement avec les SCM providers : {}", providers);
            parametersBuilder.addString("providers", providers);
        });
        JobParameters parameters = parametersBuilder.toJobParameters();
        jobLauncher.run(dashboardRadarJob, parameters);
    }

    /** Attend jusqu'à ce que la table batch_job_instance soit créée automatiquement */
    private void waitForBatchSchema() throws InterruptedException {
        int attempts = 0;
        while (!isBatchSchemaReady()) {
            attempts++;
            LOGGER.info("🔄 Attente création du schéma Batch (tentative {})...", attempts);
            Thread.sleep(1000);
            if (attempts > 10) {
                LOGGER.warn("⚠️ Le schéma Batch n'est toujours pas présent après 10 secondes.");
                break;
            }
        }
    }

    private boolean isBatchSchemaReady() {
        try (Connection connection = dataSource.getConnection();
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(
                     "SELECT COUNT(*) FROM information_schema.tables WHERE table_name = 'batch_job_instance'")) {
            return rs.next() && rs.getInt(1) > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    private static Optional<String> extractProviderSelection(ApplicationArguments args) {
        if (args == null) {
            return Optional.empty();
        }
        for (String optionName : new String[] {"providers", "scm-providers", "scmProviders"}) {
            List<String> values = args.getOptionValues(optionName);
            if (values != null && !values.isEmpty()) {
                return Optional.ofNullable(values.get(values.size() - 1));
            }
        }
        return Optional.empty();
    }
}
