package com.example.dashboardradar.util;

import java.io.ByteArrayInputStream;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.xml.parsers.DocumentBuilderFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public final class XmlFrameworkExtractor {

    private static final Logger LOGGER = LoggerFactory.getLogger(XmlFrameworkExtractor.class);

    private XmlFrameworkExtractor() {
    }

    public static List<String> extractFromPom(String content) {
        try {
            Document document = DocumentBuilderFactory.newInstance()
                    .newDocumentBuilder()
                    .parse(new ByteArrayInputStream(content.getBytes()));
            document.getDocumentElement().normalize();

            Element root = document.getDocumentElement();

            Element parent = firstChild(root, "parent");
            String groupId = parent != null ? text(parent, "groupId") : null;
            String artifactId = parent != null ? text(parent, "artifactId") : null;
            String version = parent != null ? text(parent, "version") : null;

            Element properties = firstChild(root, "properties");
            String javaVersion = properties != null ? text(properties, "java.version") : null;
            if (javaVersion == null && properties != null) {
                javaVersion = text(properties, "maven.compiler.source");
            }
            if (javaVersion == null || javaVersion.isBlank()) {
                javaVersion = "N/A";
            }
            String parentPom = String.format("%s:%s:%s",
                    fallback(groupId, "N/A"),
                    fallback(artifactId, "N/A"),
                    fallback(version, "N/A"));
            Set<String> frameworks = new HashSet<>();
            NodeList dependencies = document.getElementsByTagName("dependency");
            for (int i = 0; i < dependencies.getLength(); i++) {
                NodeList children = dependencies.item(i).getChildNodes();
                String depGroupId = null;
                String depArtifactId = null;
                String depVersion = null;
                for (int j = 0; j < children.getLength(); j++) {
                    String nodeName = children.item(j).getNodeName();
                    if ("groupId".equals(nodeName)) {
                        depGroupId = children.item(j).getTextContent();
                    } else if ("artifactId".equals(nodeName)) {
                        depArtifactId = children.item(j).getTextContent();
                    } else if ("version".equals(nodeName)) {
                        depVersion = children.item(j).getTextContent();
                    }
                }
                if (depGroupId != null && depArtifactId != null) {
                    if (depVersion != null && !depVersion.isBlank()) {
                        frameworks.add(depGroupId + ":" + depArtifactId + ":" + depVersion);
                    } else {
                        frameworks.add(depGroupId + ":" + depArtifactId);
                    }
                }
            }
            frameworks.add("java:" + javaVersion);
            frameworks.add(parentPom);

            return List.copyOf(frameworks);
        } catch (Exception ex) {
            LOGGER.warn("Unable to parse pom.xml", ex);
            return List.of();
        }
    }

    private static Element firstChild(Element parent, String tagName) {
        if (parent == null) {
            return null;
        }
        NodeList nodes = parent.getElementsByTagName(tagName);
        if (nodes.getLength() == 0) {
            return null;
        }
        Node node = nodes.item(0);
        return node instanceof Element ? (Element) node : null;
    }

    private static String text(Element parent, String tagName) {
        Element child = firstChild(parent, tagName);
        if (child == null) {
            return null;
        }
        String value = child.getTextContent();
        return value == null ? null : value.trim();
    }

    private static String fallback(String value, String defaultValue) {
        return value == null || value.isBlank() ? defaultValue : value;
    }
}
