package com.example.dashboardradar.config;



import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;

@Component
public class BatchSchemaInitializer {

    private static final Logger LOGGER = LoggerFactory.getLogger(BatchSchemaInitializer.class);
    private final DataSource dataSource;

    public BatchSchemaInitializer(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @PostConstruct
    public void init() {
        try {
            LOGGER.info("📦 Initialisation du schéma Spring Batch PostgreSQL...");
            ResourceDatabasePopulator populator = new ResourceDatabasePopulator();
            populator.addScript(new ClassPathResource(
                    "org/springframework/batch/core/schema-postgresql.sql"));
            populator.execute(dataSource);
            LOGGER.info("✅ Schéma Spring Batch initialisé avec succès !");
        } catch (Exception e) {
            LOGGER.warn("⚠️ Impossible d'initialiser le schéma Batch (peut déjà exister) : {}", e.getMessage());
        }
    }
}
