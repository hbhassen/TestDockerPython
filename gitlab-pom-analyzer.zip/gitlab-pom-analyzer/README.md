# GitLab POM Analyzer (Spring Boot 3.5.6, Java 17)

Batch Spring Boot qui scanne un groupe GitLab et extrait, pour chaque projet :
- la dernière branche modifiée,
- le `pom.xml` le plus proche de la racine du dépôt,
- le parent Maven (`groupId`, `artifactId`, `version`),
- la version Java (`java.version` ou `maven.compiler.source`).

## Prérequis
- JDK 17
- Maven 3.9+
- Accès HTTP à GitLab + Personal Access Token avec `read_api` et `read_repository`

## Configuration
Modifie `src/main/resources/application.properties` :
```properties
gitlab.url=http://localhost:8929
gitlab.token=<TON_TOKEN>
gitlab.groupId=55
output.file=projects_with_pom_details.json
```

## Build & Run
```bash
mvn clean package -DskipTests
java -jar target/gitlab-pom-analyzer-1.0.0.jar
```

Le résultat JSON est écrit dans `projects_with_pom_details.json` à la racine du projet.

## Notes
- Le choix du `pom.xml` “racine” se fait par **profondeur de chemin** (moins de `/`) puis on favorise les chemins contenant le **nom du projet**.
- Le parsing XML est réalisé avec **dom4j** (robuste aux namespaces).

