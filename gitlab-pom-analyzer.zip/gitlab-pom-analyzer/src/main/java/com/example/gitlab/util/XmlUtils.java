package com.example.gitlab.util;

import com.example.gitlab.model.ProjectInfo;
import com.example.gitlab.model.ProjectInfo.MainBuildFile;

import java.util.ArrayList;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

public class XmlUtils {

    public static ProjectInfo extractPomInfo(Long id, String name, String branch, String path, String xml) {
        try {
            Document doc = DocumentHelper.parseText(xml);
            Element root = doc.getRootElement();

            Element parent = root.element("parent");
            String groupId = parent != null ? text(parent, "groupId") : "N/A";
            String artifactId = parent != null ? text(parent, "artifactId") : "N/A";
            String version = parent != null ? text(parent, "version") : "N/A";

            Element properties = root.element("properties");
            String javaVersion = properties != null ? text(properties, "java.version") : null;
            if (javaVersion == null && properties != null) {
                javaVersion = text(properties, "maven.compiler.source");
            }
            if (javaVersion == null) javaVersion = "N/A";
            List<MainBuildFile> mainBuildFile=new ArrayList<ProjectInfo.MainBuildFile>();
            MainBuildFile mbf = new MainBuildFile();
            mbf.setFileName(path);
            mbf.setLanguage("java");
            mbf.setLanguageVersion(javaVersion);
            mbf.setDevInfo(groupId+":"+artifactId+":"+version);
            mainBuildFile.add(mbf);
            
            
            return new ProjectInfo(id, name, branch,  mainBuildFile);
        } catch (Exception e) {
            return new ProjectInfo(id, name, branch, null);
        }
    }

    private static String text(Element parent, String tag) {
        Element el = parent.element(tag);
        return el != null ? el.getTextTrim() : null;
    }
}
