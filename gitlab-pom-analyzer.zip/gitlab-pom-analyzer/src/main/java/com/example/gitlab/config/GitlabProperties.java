package com.example.gitlab.config;



import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 * Classe de configuration typée pour GitLab.
 */
@Configuration
@ConfigurationProperties(prefix = "gitlab")
public class GitlabProperties {

    private String url;
    private String token;
    private String groupId;
    private Build build;

    public static class Build {
        private List<String> file;

        public List<String> getFile() {
            return file;
        }

        public void setFile(List<String> file) {
            this.file = file;
        }
    }

    // Getters & Setters
    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }

    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }

    public String getGroupId() { return groupId; }
    public void setGroupId(String groupId) { this.groupId = groupId; }

    public Build getBuild() { return build; }
    public void setBuild(Build build) { this.build = build; }
}

