package com.example.gitlab.service;

import com.example.gitlab.model.ProjectInfo;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public interface IGitlabService {

    /**
     * Analyse tous les projets du groupe GitLab et exporte les résultats.
     */
    void processProjects();

    /**
     * Récupère tous les projets du groupe GitLab (pagination incluse).
     * @return liste de projets sous forme de map (id, path_with_namespace, etc.)
     */
    List<Map<String, Object>> fetchAllProjects();

    /**
     * Détermine la branche la plus récemment modifiée du projet.
     * @param projectId identifiant du projet
     * @return nom de la branche la plus récente, ou null si aucune
     */
    String getLatestBranch(Long projectId);

    /**
     * Compte le nombre total de fichiers d’une branche donnée.
     * @param projectId identifiant du projet
     * @param branch nom de la branche
     * @return nombre total de fichiers (type=blob)
     */
    int countFilesInBranch(Long projectId, String branch);

   
    /**
     * Sauvegarde les résultats d’analyse dans un fichier JSON.
     * @param infos liste d’informations extraites des POMs
     */
    void exportResults(List<ProjectInfo> infos);
}

