package com.example.gitlab.service;

import com.example.gitlab.config.GitlabProperties;
import com.example.gitlab.model.ProjectInfo;
import com.example.gitlab.util.XmlUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.io.FileWriter;
import java.util.*;

/**
 * Service principal pour interagir avec l’API GitLab et analyser les fichiers de build.
 * Compatible Spring Boot 3.5.6 / Java 17.
 */
@Service
public class GitlabService implements IGitlabService {

	 private final WebClient webClient;
	    private final String groupId;
	    private final String outputFile;
	    private final List<String> buildFiles;

	    public GitlabService(
	            GitlabProperties props,
	            @Value("${output.file}") String outputFile) {

	        this.groupId = props.getGroupId();
	        this.outputFile = outputFile;
	        this.buildFiles = props.getBuild().getFile();

	        this.webClient = WebClient.builder()
	                .baseUrl(props.getUrl() + "/api/v4")
	                .defaultHeader("PRIVATE-TOKEN", props.getToken())
	                .build();
	    }

    /** Point d’entrée principal : analyse tous les projets du groupe GitLab. */
    @Override
    public void processProjects() {
        System.out.println("🔍 Analyse des projets du groupe " + groupId + " ...");

        List<Map<String, Object>> projects = fetchAllProjects();
        List<ProjectInfo> results = new ArrayList<>();

        for (Map<String, Object> project : projects) {
            Long id = ((Number) project.get("id")).longValue();
            String name = (String) project.get("path_with_namespace");
            System.out.println("➡️ Projet : " + name + "  id :" + id);

            String latestBranch = getLatestBranch(id);
            if (latestBranch == null) {
                System.out.println("⚠️ Aucune branche détectée pour " + name);
                continue;
            }

            var files = getListOfProjectFiles(id, latestBranch);
            if (files == null) {
                System.out.println("⚠️ Aucun fichier détecté pour la branche " + latestBranch);
                continue;
            }

            Map<String, String> closestBuildFiles = new HashMap<>();
            for (String buildFile : buildFiles) {
            	
                Optional<String> closest = getClosestBuildFilePath(name, buildFile, files);
                closest.ifPresent(path -> closestBuildFiles.put(buildFile, path));
            }

            if (closestBuildFiles.isEmpty()) {
                System.out.println("❌ Aucun build file trouvé pour " + name);
                continue;
            }

            for (String buildFile : buildFiles) {
                results = analyzeBuildFile(name, id, latestBranch, closestBuildFiles, buildFile, results);
            }
        }

        exportResults(results);
    }

    /** Récupère tous les projets GitLab (pagination incluse). */
    public List<Map<String, Object>> fetchAllProjects() {
        int page = 1;
        int perPage = 100;
        List<Map<String, Object>> all = new ArrayList<>();

        while (true) {
            List<Map<String, Object>> pageItems = webClient.get()
                    .uri("/projects?include_subgroups=true&per_page={per}&page={pg}", perPage, page)
                    .accept(MediaType.APPLICATION_JSON)
                    .retrieve()
                    .bodyToMono(new ParameterizedTypeReference<List<Map<String, Object>>>() {})
                    .block();

            if (pageItems == null || pageItems.isEmpty()) break;
            all.addAll(pageItems);
            if (pageItems.size() < perPage) break;
            page++;
        }
        return all;
    }

    /** Analyse un fichier de build (pom.xml, build.gradle, etc.). */
    private List<ProjectInfo> analyzeBuildFile(String name, Long id, String branch,
                                               Map<String, String> closestBuildFiles,
                                               String buildFile,
                                               List<ProjectInfo> results) {
        String path = closestBuildFiles.get(buildFile);
        if (path != null) {
            String content = getBuildFileContent(id, branch, path);
            if (content != null) {
                ProjectInfo info = XmlUtils.extractPomInfo(id, name, branch, path, content);
                results.add(info);
            } else {
                System.out.println("⚠️ Impossible de lire " + buildFile + " pour " + name);
            }
        }
        return results;
    }

    /** Détermine la branche la plus récemment modifiée du projet. */
    public String getLatestBranch(Long projectId) {
        List<Map<String, Object>> branches = webClient.get()
                .uri("/projects/{id}/repository/branches?per_page=100", projectId)
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<List<Map<String, Object>>>() {})
                .block();

        if (branches == null || branches.isEmpty()) return null;

        return branches.stream()
                .sorted((a, b) -> {
                    String da = String.valueOf(((Map<?, ?>) a.get("commit")).get("committed_date"));
                    String db = String.valueOf(((Map<?, ?>) b.get("commit")).get("committed_date"));
                    return db.compareTo(da);
                })
                .map(b -> (String) b.get("name"))
                .findFirst()
                .orElse(null);
    }

    /** Compte le nombre total de fichiers d’une branche donnée. */
    public Map<String,Object> getFilesInBranch(Long projectId, String branch) {
        int page = 1;
        int perPage = 200;
        int total = 0;
        
        List<Map<String, Object>> AllBranchElement = new ArrayList<Map<String,Object>>();
        while (true) {
            List<Map<String, Object>> treePage = webClient.get()
                    .uri("/projects/{id}/repository/tree?ref={branch}&recursive=true&per_page={per}&page={pg}",
                            projectId, branch, perPage, page)
                    .retrieve()
                    .bodyToMono(new ParameterizedTypeReference<List<Map<String, Object>>>() {})
                    .block();

            if (treePage == null || treePage.isEmpty()) break;

            total += treePage.size();
            AllBranchElement.addAll(treePage);
            if (treePage.size() < perPage) break;
            page++;
            
        }
        Map<String,Object> result = new HashMap<String, Object>();
        result.put("total", total);
        result.put("arbo", AllBranchElement);
        
        return  result ;
    }

    /** Récupère la liste des fichiers d’un projet sur une branche. */
    public List<Map<String, Object>> getListOfProjectFiles(Long projectId, String branch) {
        var branchMap = getFilesInBranch(projectId, branch);
        System.out.println("➡️ Nombre de fichiers: " +branchMap.get("total"));
        List<Map<String, Object>> files=(List<Map<String, Object>>) branchMap.get("arbo");
        return files;
       
    }

    /** Recherche le fichier de build le plus proche de la racine. */
    public Optional<String> getClosestBuildFilePath(String projectPath, String buildFile, List<Map<String, Object>> files) {
        String projectLeaf = projectPath.contains("/") ?
                projectPath.substring(projectPath.lastIndexOf('/') + 1) :
                projectPath;

        return files.stream()
                .filter(f -> "blob".equals(String.valueOf(f.get("type"))))
                .map(f -> (String) f.get("path"))
                .filter(p -> p != null && p.endsWith(buildFile))
                .sorted(Comparator.comparingInt(p -> p.split("/").length))
                .findFirst();
    }

    /** Télécharge et décode un fichier de build. */
    public String getBuildFileContent(Long projectId, String branch, String path) {
        try {
            Map<String, Object> file = webClient.get()
                    .uri(uriBuilder -> uriBuilder
                            .path("/projects/{id}/repository/files/{path}")
                            .queryParam("ref", branch)
                            .build(projectId, path))
                    .retrieve()
                    .bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {})
                    .block();

            if (file == null) return null;

            String contentBase64 = (String) file.get("content");
            return new String(Base64.getDecoder().decode(contentBase64));
        } catch (Exception e) {
            System.err.println("❌ Erreur lecture fichier : " + e.getMessage());
            return null;
        }
    }

    /** Sauvegarde les résultats au format JSON. */
    public void exportResults(List<ProjectInfo> infos) {
        try (FileWriter writer = new FileWriter(outputFile)) {
            writer.write("[\n");
            for (int i = 0; i < infos.size(); i++) {
                writer.write(infos.get(i).toJson());
                if (i < infos.size() - 1) writer.write(",\n");
            }
            writer.write("\n]");
            System.out.println("✅ Résultats enregistrés dans " + outputFile);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

	@Override
	public int countFilesInBranch(Long projectId, String branch) {
		// TODO Auto-generated method stub
		return 0;
	}
}
