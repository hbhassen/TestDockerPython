package com.example.gitlab;

import com.example.gitlab.service.GitlabService;
import com.example.gitlab.service.IGitlabService;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GitlabPomAnalyzerApplication implements CommandLineRunner {

    private final IGitlabService gitlabService;

    public GitlabPomAnalyzerApplication(GitlabService gitlabService) {
        this.gitlabService = gitlabService;
    }

    public static void main(String[] args) {
        SpringApplication.run(GitlabPomAnalyzerApplication.class, args);
    }

    @Override
    public void run(String... args) {
        gitlabService.processProjects();
    }
}
