package com.example.gitlab.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.List;

/**
 * Modèle représentant les informations d’un projet GitLab
 * compatible avec la sérialisation JSON (Jackson).
 */
public class ProjectInfo {

    @JsonProperty
    private Long id;

    @JsonProperty
    private String name;

    @JsonProperty("lastBranch")
    private String lastBranch;

    @JsonProperty("mainBuildFile")
    private List<MainBuildFile> mainBuildFile;

    // Constructeur par défaut (obligatoire pour Jackson)
    public ProjectInfo() {}

    // Constructeur complet (optionnel)
    public ProjectInfo(Long id, String name, String lastBranch, List<MainBuildFile> mainBuildFile) {
        this.id = id;
        this.name = name;
        this.lastBranch = lastBranch;
        this.mainBuildFile = mainBuildFile;
    }

    // ✅ Classe interne statique représentant un fichier de build principal
    public static class MainBuildFile {

        @JsonProperty("fileName")
        private String fileName;

        @JsonProperty("devInfo")
        private String devInfo;

        @JsonProperty("language")
        private String language;

        @JsonProperty("languageVersion")
        private String languageVersion;

        public MainBuildFile() {}

        public MainBuildFile(String fileName, String devInfo, String language, String languageVersion) {
            this.fileName = fileName;
            this.devInfo = devInfo;
            this.language = language;
            this.languageVersion = languageVersion;
        }

        // Getters / Setters
        public String getFileName() { return fileName; }
        public void setFileName(String fileName) { this.fileName = fileName; }

        public String getDevInfo() { return devInfo; }
        public void setDevInfo(String devInfo) { this.devInfo = devInfo; }

        public String getLanguage() { return language; }
        public void setLanguage(String language) { this.language = language; }

        public String getLanguageVersion() { return languageVersion; }
        public void setLanguageVersion(String languageVersion) { this.languageVersion = languageVersion; }
    }

    // Getters / Setters principaux
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getLastBranch() { return lastBranch; }
    public void setLastBranch(String lastBranch) { this.lastBranch = lastBranch; }

    public List<MainBuildFile> getMainBuildFile() { return mainBuildFile; }
    public void setMainBuildFile(List<MainBuildFile> mainBuildFile) { this.mainBuildFile = mainBuildFile; }

    // Méthode utilitaire pour afficher en JSON
    public String toJson() {
        try {
            return new ObjectMapper()
                    .writerWithDefaultPrettyPrinter()
                    .writeValueAsString(this);
        } catch (Exception e) {
            return "{}";
        }
    }
}
