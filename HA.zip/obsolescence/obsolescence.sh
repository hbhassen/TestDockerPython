#!/bin/bash
# ===========================================================
# Script : list_projects_with_pom_details_purebash_fixed.sh
# Objectif :
#   - Trouver la dernière branche modifiée
#   - Lister les pom.xml
#   - Choisir le pom racine le plus proche de la racine du dépôt
#   - Extraire parent Maven + version Java (sans jq/xmllint)
# Auteur : Hamdi Ben Hassen
# ===========================================================

# --- Paramètres utilisateur ---
GITLAB_URL="http://localhost:8929"
GROUP_ID="55"
PRIVATE_TOKEN="glpat-4qkc4gE6Ezh4NZPjin_B"
OUTPUT_FILE="projects_with_pom_details.json"
PER_PAGE=50

# --- Fonctions utilitaires ---
urlencode() { echo -n "$1" | sed 's/\//%2F/g'; }

pick_latest_branch() {
  local json="$1"
  mapfile -t names < <(echo "$json" | grep -oE '"name":"[^"]+"' | sed 's/"name":"//;s/"$//')
  mapfile -t dates < <(echo "$json" | grep -oE '"committed_date":"[^"]+"' | sed 's/"committed_date":"//;s/"$//')
  [ ${#names[@]} -eq 0 ] && { echo ""; return; }
  local max_i=0 max="${dates[0]}"
  for ((i=1;i<${#dates[@]};i++)); do
    [[ "${dates[i]}" > "$max" ]] && { max="${dates[i]}"; max_i=$i; }
  done
  echo "${names[$max_i]}"
}

compact_xml() { tr -d '\r\n' | sed 's/>[[:space:]]*</></g'; }

extract_parent_groupId()      { sed -n 's/.*<parent>.*<groupId>\([^<]*\)<\/groupId>.*/\1/p' | head -n1; }
extract_parent_artifactId()   { sed -n 's/.*<parent>.*<artifactId>\([^<]*\)<\/artifactId>.*/\1/p' | head -n1; }
extract_parent_version()      { sed -n 's/.*<parent>.*<version>\([^<]*\)<\/version>.*/\1/p' | head -n1; }
extract_java_version()        { sed -n 's/.*<properties>.*<java.version>\([^<]*\)<\/java.version>.*/\1/p' | head -n1; }
extract_maven_compiler_source(){ sed -n 's/.*<properties>.*<maven.compiler.source>\([^<]*\)<\/maven.compiler.source>.*/\1/p' | head -n1; }

write_json_entry() {
  local id="$1" name="$2" branch="$3" pom="$4" pg="$5" pa="$6" pv="$7" jv="$8"
  cat <<EOF
{
  "id": $id,
  "name": "$name",
  "last_branch": "$branch",
  "pom_main": "$pom",
  "parent": {
    "groupId": "$pg",
    "artifactId": "$pa",
    "version": "$pv"
  },
  "java_version": "$jv"
}
EOF
}

# --- Début du traitement ---
echo "[" > "$OUTPUT_FILE"
first=true
page=1
echo "🔍 Début du scan du groupe $GROUP_ID sur $GITLAB_URL ..."

while true; do
  projects_json=$(curl -s --header "PRIVATE-TOKEN: $PRIVATE_TOKEN" \
    "$GITLAB_URL/api/v4/groups/$GROUP_ID/projects?include_subgroups=true&per_page=$PER_PAGE&page=$page")
  count=$(echo "$projects_json" | grep -o '"id":' | wc -l)
  [ "$count" -eq 0 ] && break

  mapfile -t ids   < <(echo "$projects_json" | grep -oE '"id":[0-9]+' | sed 's/"id"://')
  mapfile -t names < <(echo "$projects_json" | grep -oE '"path_with_namespace":"[^"]+"' | sed 's/"path_with_namespace":"//;s/"$//')

  for ((k=0; k<${#ids[@]}; k++)); do
    project_id="${ids[$k]}"
    project_name="${names[$k]}"
    echo "➡️  Projet : $project_name"

    branches_json=$(curl -s --header "PRIVATE-TOKEN: $PRIVATE_TOKEN" \
      "$GITLAB_URL/api/v4/projects/$project_id/repository/branches?per_page=100")
    latest_branch="$(pick_latest_branch "$branches_json")"
    [ -z "$latest_branch" ] && { echo "⚠️ Aucune branche détectée."; continue; }

    echo "🕒 Dernière branche : $latest_branch"

    tree_json=$(curl -s --header "PRIVATE-TOKEN: $PRIVATE_TOKEN" \
      "$GITLAB_URL/api/v4/projects/$project_id/repository/tree?ref=$latest_branch&recursive=true&per_page=100")

    pom_paths=$(echo "$tree_json" | grep -oE '"path":"[^"]*pom\.xml"' | sed 's/"path":"//;s/"$//' )
    [ -z "$pom_paths" ] && { echo "❌ Aucun pom.xml trouvé."; continue; }

    # ✅ Nouvelle logique : choisir le pom le plus proche de la racine du projet
    # 1. Trier par profondeur (nombre de '/')
    # 2. Si égalité, prioriser celui qui contient le nom du projet
    closest_pom=$(echo "$pom_paths" | awk -F'/' -v proj="$(basename "$project_name")" '
      {
        depth=NF;
        score=depth;
        if (index($0, proj) > 0) score=score-0.5;  # favorise pom contenant le nom du projet
        print score " " $0
      }' | sort -n | head -n1 | cut -d" " -f2-)

    echo "📄 POM principal sélectionné : $closest_pom"

    encoded_path=$(urlencode "$closest_pom")
    file_json=$(curl -s --header "PRIVATE-TOKEN: $PRIVATE_TOKEN" \
      "$GITLAB_URL/api/v4/projects/$project_id/repository/files/$encoded_path?ref=$latest_branch")

    pom_content_b64=$(echo "$file_json" | grep -oE '"content":"[^"]+"' | sed 's/"content":"//;s/"$//' | tr -d '\n')
    [ -z "$pom_content_b64" ] && { echo "⚠️ Impossible de lire le pom.xml"; continue; }

    pom_xml=$(echo "$pom_content_b64" | base64 --decode 2>/dev/null | compact_xml)

    parent_groupId=$(echo "$pom_xml" | extract_parent_groupId)
    parent_artifactId=$(echo "$pom_xml" | extract_parent_artifactId)
    parent_version=$(echo "$pom_xml" | extract_parent_version)
    java_version=$(echo "$pom_xml" | extract_java_version)
    [ -z "$java_version" ] && java_version=$(echo "$pom_xml" | extract_maven_compiler_source)

    [ -z "$parent_groupId" ] && parent_groupId="N/A"
    [ -z "$parent_artifactId" ] && parent_artifactId="N/A"
    [ -z "$parent_version" ] && parent_version="N/A"
    [ -z "$java_version" ] && java_version="N/A"

    if [ "$first" = true ]; then
      first=false
    else
      echo "," >> "$OUTPUT_FILE"
    fi

    write_json_entry "$project_id" "$project_name" "$latest_branch" "$closest_pom" \
      "$parent_groupId" "$parent_artifactId" "$parent_version" "$java_version" >> "$OUTPUT_FILE"
  done
  ((page++))
done

echo "]" >> "$OUTPUT_FILE"
echo "✅ Terminé. Résultats enregistrés dans $OUTPUT_FILE"
